<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=utf-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// CORREÇÃO: caminho relativo correto
require_once __DIR__ . '/conexao.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

$acao = $_GET['acao'] ?? '';

$acoes_publicas = ['login', 'registar', 'teste', 'debug'];

if (!in_array($acao, $acoes_publicas) && !usuarioLogado()) {
    naoAutorizado();
}

/* =========================
   TESTE
========================= */
if ($acao === 'teste') {
    echo json_encode([
        'sucesso' => true,
        'mensagem' => 'API está a funcionar corretamente!',
        'php_version' => phpversion(),
        'server_time' => date('Y-m-d H:i:s'),
        'conexao_bd' => $conn ? 'OK' : 'Erro'
    ]);
    exit;
}

/* =========================
   DEBUG
========================= */
if ($acao === 'debug') {
    echo json_encode([
        'conexao' => $conn ? 'OK' : 'Erro',
        'tabelas' => $conn ? $conn->query("SHOW TABLES LIKE 'usuarios'")->num_rows > 0 ? 'usuarios existe' : 'usuarios NÃO existe' : 'Sem conexão'
    ]);
    exit;
}

/* =========================
   LOGIN
========================= */
if ($acao === 'login') {
    $email = $_POST['email'] ?? '';
    $senha = $_POST['senha'] ?? '';

    if (!$email || !$senha) {
        echo json_encode(['sucesso' => false, 'mensagem' => 'Campos obrigatórios']);
        exit;
    }

    $senha_hash = md5($senha);

    $sql = "SELECT id, nome, email, pontos, tipo, bio, streak, ultimo_login FROM usuarios WHERE email = ? AND senha = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $email, $senha_hash);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($res->num_rows === 0) {
        echo json_encode(['sucesso' => false, 'mensagem' => 'Email ou senha incorretos']);
        exit;
    }

    $user = $res->fetch_assoc();

    $_SESSION['usuario_id'] = $user['id'];
    $_SESSION['usuario_nome'] = $user['nome'];

    echo json_encode([
        'sucesso' => true,
        'mensagem' => 'Login efetuado com sucesso!',
        'dados' => $user
    ]);
    exit;
}

/* =========================
   REGISTO
========================= */
if ($acao === 'registar') {
    $nome = $_POST['nome'] ?? '';
    $email = $_POST['email'] ?? '';
    $senha = $_POST['senha'] ?? '';

    if (!$nome || !$email || !$senha) {
        echo json_encode(['sucesso' => false, 'mensagem' => 'Preenche todos os campos']);
        exit;
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['sucesso' => false, 'mensagem' => 'Email inválido']);
        exit;
    }

    if (strlen($senha) < 6) {
        echo json_encode(['sucesso' => false, 'mensagem' => 'A senha deve ter pelo menos 6 caracteres']);
        exit;
    }

    // Verificar se email já existe
    $check = $conn->prepare("SELECT id FROM usuarios WHERE email = ?");
    $check->bind_param("s", $email);
    $check->execute();
    
    if ($check->get_result()->num_rows > 0) {
        echo json_encode(['sucesso' => false, 'mensagem' => 'Este email já está registado']);
        exit;
    }

    $senha_hash = md5($senha);

    $sql = "INSERT INTO usuarios (nome, email, senha, pontos, tipo, bio, streak, ultimo_login) 
            VALUES (?, ?, ?, 0, 'user', '', 1, CURDATE())";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $nome, $email, $senha_hash);

    if ($stmt->execute()) {
        $_SESSION['usuario_id'] = $stmt->insert_id;
        $_SESSION['usuario_nome'] = $nome;

        echo json_encode([
            'sucesso' => true,
            'mensagem' => 'Conta criada com sucesso!',
            'usuario_id' => $stmt->insert_id
        ]);
    } else {
        echo json_encode([
            'sucesso' => false,
            'mensagem' => 'Erro ao criar conta: ' . $conn->error
        ]);
    }
    exit;
}

/* =========================
   VERIFICAR SESSÃO
========================= */
if ($acao === 'verificar_sessao') {
    if (usuarioLogado()) {
        $user = getUsuarioAtual($conn);
        echo json_encode([
            'sucesso' => true,
            'logado' => true,
            'dados' => $user
        ]);
    } else {
        echo json_encode([
            'sucesso' => true,
            'logado' => false
        ]);
    }
    exit;
}

/* =========================
   LOGOUT
========================= */
if ($acao === 'logout') {
    session_destroy();
    echo json_encode(['sucesso' => true, 'mensagem' => 'Sessão terminada']);
    exit;
}

/* =========================
   LEADERBOARD
========================= */
if ($acao === 'leaderboard') {
    $sql = "SELECT id, nome, pontos FROM usuarios ORDER BY pontos DESC LIMIT 10";
    $res = $conn->query($sql);

    $data = [];
    while ($row = $res->fetch_assoc()) {
        $data[] = $row;
    }

    echo json_encode(['sucesso' => true, 'dados' => $data]);
    exit;
}

/* =========================
   SALVAR QUIZ
========================= */
if ($acao === 'salvar_quiz') {
    if (!usuarioLogado()) {
        echo json_encode(['sucesso' => false, 'mensagem' => 'Não autorizado']);
        exit;
    }

    $usuario_id = $_SESSION['usuario_id'];
    $linguagem = $_POST['linguagem'] ?? '';
    $dificuldade = $_POST['dificuldade'] ?? '';
    $pontuacao = intval($_POST['pontuacao'] ?? 0);
    $total_perguntas = intval($_POST['total_perguntas'] ?? 0);

    $sql = "INSERT INTO quiz_resultados (usuario_id, linguagem, dificuldade, pontuacao, total_perguntas) 
            VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("issii", $usuario_id, $linguagem, $dificuldade, $pontuacao, $total_perguntas);

    if ($stmt->execute()) {
        // Atualizar pontos do usuário
        $update = $conn->prepare("UPDATE usuarios SET pontos = pontos + ? WHERE id = ?");
        $update->bind_param("ii", $pontuacao, $usuario_id);
        $update->execute();

        echo json_encode(['sucesso' => true, 'mensagem' => 'Quiz salvo!']);
    } else {
        echo json_encode(['sucesso' => false, 'mensagem' => 'Erro: ' . $conn->error]);
    }
    exit;
}

/* =========================
   GET HISTÓRICO
========================= */
if ($acao === 'get_historico') {
    $usuario_id = $_SESSION['usuario_id'];
    
    $sql = "SELECT * FROM quiz_resultados WHERE usuario_id = ? ORDER BY data DESC LIMIT 20";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $usuario_id);
    $stmt->execute();
    $res = $stmt->get_result();

    $data = [];
    while ($row = $res->fetch_assoc()) {
        $data[] = $row;
    }

    echo json_encode(['sucesso' => true, 'dados' => $data]);
    exit;
}

/* =========================
   GET PROGRESSO
========================= */
if ($acao === 'get_progresso') {
    $usuario_id = $_SESSION['usuario_id'];
    
    $linguagens = ['html', 'css', 'javascript', 'python', 'java'];
    $progresso = [];

    foreach ($linguagens as $lang) {
        $progresso[$lang] = 0;
        
        $sql = "SELECT porcentagem FROM progresso WHERE usuario_id = ? AND linguagem = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("is", $usuario_id, $lang);
        $stmt->execute();
        $res = $stmt->get_result();
        
        if ($row = $res->fetch_assoc()) {
            $progresso[$lang] = $row['porcentagem'];
        }
    }

    echo json_encode(['sucesso' => true, 'dados' => $progresso]);
    exit;
}

/* =========================
   PERFIL
========================= */
if ($acao === 'perfil') {
    $user = getUsuarioAtual($conn);
    echo json_encode(['sucesso' => true, 'dados' => $user]);
    exit;
}

/* =========================
   ATUALIZAR PERFIL
========================= */
if ($acao === 'atualizar_perfil') {
    $usuario_id = $_SESSION['usuario_id'];
    $nome = $_POST['nome'] ?? '';
    $bio = $_POST['bio'] ?? '';

    $sql = "UPDATE usuarios SET nome = ?, bio = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssi", $nome, $bio, $usuario_id);

    if ($stmt->execute()) {
        $_SESSION['usuario_nome'] = $nome;
        echo json_encode(['sucesso' => true, 'mensagem' => 'Perfil atualizado!']);
    } else {
        echo json_encode(['sucesso' => false, 'mensagem' => 'Erro: ' . $conn->error]);
    }
    exit;
}

echo json_encode(['sucesso' => false, 'mensagem' => 'Ação não encontrada: ' . $acao]);
$conn->close();