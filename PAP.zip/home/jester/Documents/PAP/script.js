// ===========================================
// CODEMASTER PRO - JAVASCRIPT COMPLETO
// Versão Final com Bloqueio Total de Acesso
// ===========================================

console.log('%c🚀 CodeMaster Pro - Inicializando...', 'color: #bd93f9; font-size: 16px; font-weight: bold;');

// ===========================================
// CONFIGURAÇÕES
// ===========================================
const API_URL = 'api.php';
const APP_VERSION = '2.0.0';
const MAX_QUIZ_QUESTIONS = 15;
const DEFAULT_QUIZ_COUNT = 10;
const ACHIEVEMENT_POINTS_MULTIPLIER = 1;

// Estado global da aplicação
const AppState = {
    currentUser: null,
    isLoggedIn: false,
    currentMode: 'study',
    theme: localStorage.getItem('codemaster_theme') || 'dark',
    achievements: [],
    quizHistory: [],
    codeExecutions: 0,
    totalPoints: 0,
    streak: 0
};

// ===========================================
// VERIFICAÇÃO DE SESSÃO
// ===========================================
document.addEventListener('DOMContentLoaded', function() {
    console.log('📦 Inicializando CodeMaster Pro v' + APP_VERSION);
    verificarSessao();
    
    // Configurar listeners de autenticação
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    const logoutBtn = document.getElementById('logout-btn');
    
    if (loginForm) loginForm.addEventListener('submit', fazerLogin);
    if (registerForm) registerForm.addEventListener('submit', fazerRegistro);
    if (logoutBtn) logoutBtn.addEventListener('click', fazerLogout);
    
    // Fechar modal com botão X
    const closeModal = document.querySelector('.close-modal');
    if (closeModal) {
        closeModal.addEventListener('click', () => {
            document.getElementById('auth-modal').classList.remove('active');
        });
    }
    
    // Fechar modal clicando fora
    window.addEventListener('click', (e) => {
        const modal = document.getElementById('auth-modal');
        if (e.target === modal) {
            modal.classList.remove('active');
        }
    });
    
    // Tabs de autenticação
    document.querySelectorAll('.auth-tab').forEach(tab => {
        tab.addEventListener('click', () => {
            const tabId = tab.dataset.tab;
            document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
            document.querySelectorAll('.auth-form').forEach(f => f.classList.remove('active'));
            tab.classList.add('active');
            document.getElementById(`${tabId}-form`).classList.add('active');
        });
    });
    
    // Configurar navegação
    configurarNavegacao();
    
    // Configurar avatar/dropdown
    configurarAvatar();
    
    // Configurar cards de linguagem
    configurarLanguageCards();
    
    // Configurar quiz
    configurarQuiz();
    
    // Configurar desafios
    configurarDesafios();
    
    // Configurar tema
    configurarTema();
    
    // Carregar recursos iniciais
    carregarRecursos('html');
    
    // Inicializar editor
    setTimeout(inicializarEditor, 1000);
    
    // Inicializar tooltips
    inicializarTooltips();
    
    // Verificar conexão com internet
    verificarConexao();
});

function configurarAvatar() {
    const userAvatar = document.getElementById('user-avatar');
    const userDropdown = document.getElementById('user-dropdown');
    
    if (!userAvatar) return;
    
    userAvatar.addEventListener('click', (e) => {
        e.stopPropagation();
        
        const userName = document.getElementById('user-name').textContent;
        
        if (userName === 'Convidado') {
            document.getElementById('auth-modal').classList.add('active');
        } else {
            if (userDropdown) {
                userDropdown.classList.toggle('active');
            }
        }
    });
    
    document.addEventListener('click', (e) => {
        if (userDropdown && !userDropdown.contains(e.target) && !userAvatar.contains(e.target)) {
            userDropdown.classList.remove('active');
        }
    });
    
    if (userDropdown) {
        userDropdown.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const modo = link.dataset.mode;
                if (modo) {
                    userDropdown.classList.remove('active');
                    mudarModo(modo);
                }
            });
        });
    }
}

function verificarConexao() {
    if (!navigator.onLine) {
        mostrarMensagem('Você está offline. Algumas funcionalidades podem não funcionar.', 'aviso');
    }
    
    window.addEventListener('online', () => {
        mostrarMensagem('Conexão restabelecida!', 'sucesso');
    });
    
    window.addEventListener('offline', () => {
        mostrarMensagem('Conexão perdida. Modo offline ativado.', 'aviso');
    });
}

function inicializarTooltips() {
    const tooltips = document.querySelectorAll('[data-tooltip]');
    tooltips.forEach(el => {
        el.addEventListener('mouseenter', (e) => {
            const tooltip = document.createElement('div');
            tooltip.className = 'tooltip';
            tooltip.textContent = el.dataset.tooltip;
            document.body.appendChild(tooltip);
            
            const rect = el.getBoundingClientRect();
            tooltip.style.top = rect.top - tooltip.offsetHeight - 10 + 'px';
            tooltip.style.left = rect.left + (rect.width - tooltip.offsetWidth) / 2 + 'px';
        });
        
        el.addEventListener('mouseleave', () => {
            document.querySelector('.tooltip')?.remove();
        });
    });
}

function verificarSessao() {
    fetch('api.php?acao=verificar_sessao')
        .then(response => response.json())
        .then(data => {
            if (data.sucesso && data.logado) {
                AppState.currentUser = data.dados;
                AppState.isLoggedIn = true;
                atualizarInterfaceUsuario(data.dados);
                habilitarTodosModos();
                carregarDadosPrivados();
                verificarConquistasLogin();
            } else {
                AppState.isLoggedIn = false;
                bloquearModosRestritos();
            }
        })
        .catch(error => {
            console.error('Erro ao verificar sessão:', error);
            bloquearModosRestritos();
            mostrarMensagem('Erro de conexão com o servidor', 'erro');
        });
}

function verificarConquistasLogin() {
    if (!AppState.isLoggedIn) return;
    
    // Verificar streak
    const hoje = new Date().toDateString();
    const ultimoLogin = localStorage.getItem('ultimo_login');
    
    if (ultimoLogin) {
        const ultimo = new Date(ultimoLogin);
        const diff = Math.floor((new Date() - ultimo) / (1000 * 60 * 60 * 24));
        
        if (diff === 1) {
            AppState.streak++;
            if (AppState.streak === 7) {
                desbloquearConquista('streak_7');
            } else if (AppState.streak === 30) {
                desbloquearConquista('streak_30');
            } else if (AppState.streak === 100) {
                desbloquearConquista('streak_100');
            }
        } else if (diff > 1) {
            AppState.streak = 1;
        }
    } else {
        AppState.streak = 1;
    }
    
    localStorage.setItem('ultimo_login', new Date().toString());
    localStorage.setItem('streak', AppState.streak);
}

function desbloquearConquista(conquistaId) {
    const conquista = ACHIEVEMENTS.find(a => a.id === conquistaId);
    if (!conquista) return;
    
    if (!AppState.achievements.includes(conquistaId)) {
        AppState.achievements.push(conquistaId);
        AppState.totalPoints += conquista.pontos;
        
        mostrarMensagem(`🏆 Conquista desbloqueada: ${conquista.nome}! +${conquista.pontos} pontos`, 'achievement');
        
        // Atualizar pontos na interface
        const userPoints = document.getElementById('user-points');
        const totalPoints = document.getElementById('total-points');
        if (userPoints) userPoints.textContent = AppState.totalPoints;
        if (totalPoints) totalPoints.textContent = AppState.totalPoints;
        
        // Salvar no localStorage
        localStorage.setItem('achievements', JSON.stringify(AppState.achievements));
        localStorage.setItem('totalPoints', AppState.totalPoints);
    }
}

function bloquearModosRestritos() {
    // 1. BOTÕES DE MODO NA PÁGINA PRINCIPAL
    document.querySelectorAll('.mode-btn[data-mode="quiz"], .mode-btn[data-mode="practice"], .mode-btn[data-mode="dashboard"], .mode-btn[data-mode="challenge"]').forEach(btn => {
        btn.disabled = true;
        btn.style.opacity = '0.5';
        btn.style.cursor = 'not-allowed';
        btn.title = 'Faça login para acessar';
        
        btn.removeEventListener('click', mudarModo);
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            document.getElementById('auth-modal').classList.add('active');
            mostrarMensagem('Faça login para acessar esta funcionalidade', 'info');
            return false;
        });
    });
    
    // 2. LINKS DE NAVEGAÇÃO SUPERIOR
    document.querySelectorAll('.nav-link[data-mode="quiz"], .nav-link[data-mode="practice"], .nav-link[data-mode="dashboard"], .nav-link[data-mode="challenge"]').forEach(link => {
        link.style.pointerEvents = 'none';
        link.style.opacity = '0.5';
        link.style.cursor = 'not-allowed';
        link.title = 'Faça login para acessar';
        
        link.removeEventListener('click', mudarModo);
        link.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            document.getElementById('auth-modal').classList.add('active');
            mostrarMensagem('Faça login para acessar esta funcionalidade', 'info');
            return false;
        });
    });
    
    // 3. LINKS DO DROPDOWN
    document.querySelectorAll('.dropdown-menu a[data-mode="profile"], .dropdown-menu a[data-mode="achievements"]').forEach(link => {
        link.style.pointerEvents = 'none';
        link.style.opacity = '0.5';
        link.style.cursor = 'not-allowed';
        link.title = 'Faça login para acessar';
        
        link.removeEventListener('click', mudarModo);
        link.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            document.getElementById('auth-modal').classList.add('active');
            mostrarMensagem('Faça login para acessar esta funcionalidade', 'info');
            return false;
        });
    });
    
    // 4. LINKS DO FOOTER
    document.querySelectorAll('.footer-links a[data-mode="quiz"], .footer-links a[data-mode="practice"], .footer-links a[data-mode="dashboard"]').forEach(link => {
        link.style.pointerEvents = 'none';
        link.style.opacity = '0.5';
        link.style.cursor = 'not-allowed';
        link.title = 'Faça login para acessar';
        
        link.removeEventListener('click', mudarModo);
        link.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            document.getElementById('auth-modal').classList.add('active');
            mostrarMensagem('Faça login para acessar esta funcionalidade', 'info');
            return false;
        });
    });
    
    // 5. BLOQUEAR ACESSO DIRETO POR URL
    window.addEventListener('hashchange', function(e) {
        if (window.location.hash.includes('quiz') || 
            window.location.hash.includes('practice') || 
            window.location.hash.includes('dashboard') || 
            window.location.hash.includes('challenge')) {
            window.location.hash = '#study';
            document.getElementById('auth-modal').classList.add('active');
        }
    });
    
    // Garantir que modo estudo está ativo
    mudarModo('study');
}

function habilitarTodosModos() {
    console.log('🔓 Habilitando todos os modos para usuário logado');
    
    // 1. BOTÕES DE MODO
    document.querySelectorAll('.mode-btn').forEach(btn => {
        btn.disabled = false;
        btn.style.opacity = '1';
        btn.style.cursor = 'pointer';
        btn.title = '';
        
        // CLONAR PARA REMOVER TODOS OS LISTENERS ANTERIORES
        const novoBtn = btn.cloneNode(true);
        btn.parentNode.replaceChild(novoBtn, btn);
        
        novoBtn.addEventListener('click', (e) => {
            e.preventDefault();
            const modo = novoBtn.dataset.mode;
            if (modo) mudarModo(modo);
        });
    });
    
    // 2. LINKS DE NAVEGAÇÃO
    document.querySelectorAll('.nav-link').forEach(link => {
        link.style.pointerEvents = 'auto';
        link.style.opacity = '1';
        link.style.cursor = 'pointer';
        link.title = '';
        
        const novoLink = link.cloneNode(true);
        link.parentNode.replaceChild(novoLink, link);
        
        novoLink.addEventListener('click', (e) => {
            e.preventDefault();
            const modo = novoLink.dataset.mode;
            if (modo) mudarModo(modo);
        });
    });
    
    // 3. LINKS DO DROPDOWN
    document.querySelectorAll('.dropdown-menu a').forEach(link => {
        link.style.pointerEvents = 'auto';
        link.style.opacity = '1';
        link.style.cursor = 'pointer';
        link.title = '';
        
        const novoLink = link.cloneNode(true);
        link.parentNode.replaceChild(novoLink, link);
        
        novoLink.addEventListener('click', (e) => {
            e.preventDefault();
            const modo = novoLink.dataset.mode;
            if (modo) {
                mudarModo(modo);
                document.getElementById('user-dropdown').classList.remove('active');
            }
        });
    });
    
    // 4. LINKS DO FOOTER
    document.querySelectorAll('.footer-links a').forEach(link => {
        link.style.pointerEvents = 'auto';
        link.style.opacity = '1';
        link.style.cursor = 'pointer';
        link.title = '';
        
        const novoLink = link.cloneNode(true);
        link.parentNode.replaceChild(novoLink, link);
        
        novoLink.addEventListener('click', (e) => {
            e.preventDefault();
            const modo = novoLink.dataset.mode;
            if (modo) mudarModo(modo);
        });
    });
    
    // RECONFIGURAR AVATAR
    configurarAvatar();
    
    // Carregar progresso salvo
    carregarProgressoLocal();
}

function carregarProgressoLocal() {
    const savedAchievements = localStorage.getItem('achievements');
    const savedPoints = localStorage.getItem('totalPoints');
    const savedStreak = localStorage.getItem('streak');
    
    if (savedAchievements) {
        AppState.achievements = JSON.parse(savedAchievements);
    }
    
    if (savedPoints) {
        AppState.totalPoints = parseInt(savedPoints);
    }
    
    if (savedStreak) {
        AppState.streak = parseInt(savedStreak);
    }
    
    // Atualizar interface com dados salvos
    const userPoints = document.getElementById('user-points');
    const totalPoints = document.getElementById('total-points');
    const streakDash = document.getElementById('streak-dash');
    
    if (userPoints) userPoints.textContent = AppState.totalPoints;
    if (totalPoints) totalPoints.textContent = AppState.totalPoints;
    if (streakDash) streakDash.textContent = AppState.streak;
}

// ===========================================
// FUNÇÃO DE LOGIN COM REFRESH IMEDIATO
// ===========================================
function fazerLogin(event) {
    event.preventDefault();
    
    const email = document.getElementById('login-email').value;
    const senha = document.getElementById('login-password').value;
    
    if (!email || !senha) {
        mostrarMensagem('Preencha todos os campos', 'erro');
        return;
    }
    
    const submitBtn = event.target.querySelector('button[type="submit"]');
    const originalText = submitBtn.textContent;
    submitBtn.textContent = 'A entrar...';
    submitBtn.disabled = true;
    
    const formData = new FormData();
    formData.append('email', email);
    formData.append('senha', senha);
    
    fetch('api.php?acao=login', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.sucesso) {
            // Fechar modal
            document.getElementById('auth-modal').classList.remove('active');
            
            // RECARREGAR A PÁGINA IMEDIATAMENTE
            window.location.reload();
        } else {
            mostrarMensagem(data.mensagem || 'Erro no login', 'erro');
            submitBtn.textContent = originalText;
            submitBtn.disabled = false;
        }
    })
    .catch(error => {
        console.error('Erro no login:', error);
        mostrarMensagem('Erro ao fazer login. Tente novamente.', 'erro');
        submitBtn.textContent = originalText;
        submitBtn.disabled = false;
    });
}

function validarEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

function registrarEvento(tipo, dados) {
    console.log(`📊 Evento: ${tipo}`, dados);
    // Aqui poderia enviar para analytics ou log
}

// ===========================================
// FUNÇÃO DE REGISTRO COM REFRESH IMEDIATO
// ===========================================
function fazerRegistro(event) {
    event.preventDefault();
    
    const nome = document.getElementById('register-name').value;
    const email = document.getElementById('register-email').value;
    const senha = document.getElementById('register-password').value;
    
    if (!nome || !email || !senha) {
        mostrarMensagem('Preencha todos os campos', 'erro');
        return;
    }
    
    if (senha.length < 6) {
        mostrarMensagem('A senha deve ter pelo menos 6 caracteres', 'erro');
        return;
    }
    
    const submitBtn = event.target.querySelector('button[type="submit"]');
    const originalText = submitBtn.textContent;
    submitBtn.textContent = 'A criar conta...';
    submitBtn.disabled = true;
    
    const formData = new FormData();
    formData.append('nome', nome);
    formData.append('email', email);
    formData.append('senha', senha);
    
    fetch('api.php?acao=registar', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.sucesso) {
            // Fechar modal
            document.getElementById('auth-modal').classList.remove('active');
            
            // RECARREGAR A PÁGINA IMEDIATAMENTE
            window.location.reload();
        } else {
            mostrarMensagem(data.mensagem || 'Erro no registro', 'erro');
            submitBtn.textContent = originalText;
            submitBtn.disabled = false;
        }
    })
    .catch(error => {
        console.error('Erro no registro:', error);
        mostrarMensagem('Erro ao registrar. Tente novamente.', 'erro');
        submitBtn.textContent = originalText;
        submitBtn.disabled = false;
    });
}

// ===========================================
// FUNÇÃO DE LOGOUT COM REFRESH IMEDIATO
// ===========================================
function fazerLogout(event) {
    event.preventDefault();
    
    fetch('api.php?acao=logout')
        .then(response => response.json())
        .then(data => {
            if (data.sucesso) {
                window.location.reload();
            }
        })
        .catch(error => {
            console.error('Erro no logout:', error);
            mostrarMensagem('Erro ao fazer logout', 'erro');
        });
}

function atualizarInterfaceUsuario(usuario) {
    const userName = document.getElementById('user-name');
    const userPoints = document.getElementById('user-points');
    const totalPoints = document.getElementById('total-points');
    const totalPointsDash = document.getElementById('total-points-dash');
    const quizzesCompleted = document.getElementById('quizzes-completed');
    const totalQuizzesDash = document.getElementById('total-quizzes-dash');
    const streakDash = document.getElementById('streak-dash');
    const profileName = document.getElementById('profile-name');
    const profileBio = document.getElementById('profile-bio');
    const profileEmail = document.getElementById('profile-email');
    const profileMemberSince = document.getElementById('profile-member-since');
    const editName = document.getElementById('edit-name');
    const editBio = document.getElementById('edit-bio');
    const welcomeTitle = document.getElementById('welcome-title');
    
    const pontos = usuario.pontos || AppState.totalPoints || 0;
    const quizzes = usuario.quizzes || 0;
    const streak = usuario.streak || AppState.streak || 0;
    
    if (userName) userName.textContent = usuario.nome || 'Usuário';
    if (userPoints) userPoints.textContent = pontos;
    if (totalPoints) totalPoints.textContent = pontos;
    if (totalPointsDash) totalPointsDash.textContent = pontos;
    if (quizzesCompleted) quizzesCompleted.textContent = quizzes;
    if (totalQuizzesDash) totalQuizzesDash.textContent = quizzes;
    if (streakDash) streakDash.textContent = streak;
    if (profileName) profileName.textContent = usuario.nome || 'Usuário';
    if (profileBio) profileBio.textContent = usuario.bio || 'Aprendiz de programação';
    if (profileEmail) profileEmail.textContent = usuario.email || '';
    if (profileMemberSince) {
        const data = usuario.data_criacao ? new Date(usuario.data_criacao).toLocaleDateString('pt-BR') : 'Recentemente';
        profileMemberSince.textContent = data;
    }
    if (editName) editName.value = usuario.nome || '';
    if (editBio) editBio.value = usuario.bio || '';
    if (welcomeTitle) {
        const hora = new Date().getHours();
        if (hora < 12) welcomeTitle.textContent = `Bom dia, ${usuario.nome}!`;
        else if (hora < 18) welcomeTitle.textContent = `Boa tarde, ${usuario.nome}!`;
        else welcomeTitle.textContent = `Boa noite, ${usuario.nome}!`;
    }
    
    const avatarImg = document.getElementById('profile-avatar-img');
    if (avatarImg && usuario.nome) {
        const initials = usuario.nome.split(' ').map(n => n[0]).join('').toUpperCase().substring(0, 2);
        avatarImg.src = `https://ui-avatars.com/api/?name=${encodeURIComponent(initials)}&background=6366f1&color=fff&size=128&bold=true`;
    }
    
    const userAvatar = document.getElementById('user-avatar');
    if (userAvatar && usuario.nome) {
        const initials = usuario.nome.split(' ').map(n => n[0]).join('').toUpperCase().substring(0, 2);
        userAvatar.innerHTML = `<span>${initials}</span>`;
    }
}

function carregarDadosPrivados() {
    // Carregar progresso
    fetch('api.php?acao=get_progresso')
        .then(response => response.json())
        .then(data => {
            if (data.sucesso && data.dados) {
                atualizarProgresso(data.dados);
            }
        })
        .catch(error => console.error('Erro ao carregar progresso:', error));
    
    // Carregar histórico
    fetch('api.php?acao=get_historico')
        .then(response => response.json())
        .then(data => {
            if (data.sucesso && data.dados) {
                AppState.quizHistory = data.dados;
                atualizarHistorico(data.dados);
                
                // Verificar conquistas baseadas em histórico
                if (data.dados.length >= 5) desbloquearConquista('quiz_master');
                if (data.dados.length >= 25) desbloquearConquista('quiz_legend');
                
                // Verificar conquistas por linguagem
                const htmlCount = data.dados.filter(q => q.linguagem === 'html').length;
                const cssCount = data.dados.filter(q => q.linguagem === 'css').length;
                const jsCount = data.dados.filter(q => q.linguagem === 'javascript').length;
                const pythonCount = data.dados.filter(q => q.linguagem === 'python').length;
                const javaCount = data.dados.filter(q => q.linguagem === 'java').length;
                
                if (htmlCount >= 10) desbloquearConquista('html_pro');
                if (cssCount >= 10) desbloquearConquista('css_pro');
                if (jsCount >= 10) desbloquearConquista('js_pro');
                if (pythonCount >= 10) desbloquearConquista('python_pro');
                if (javaCount >= 10) desbloquearConquista('java_pro');
            }
        })
        .catch(error => console.error('Erro ao carregar histórico:', error));
    
    // Carregar leaderboard
    fetch('api.php?acao=leaderboard')
        .then(response => response.json())
        .then(data => {
            if (data.sucesso && data.dados) {
                atualizarLeaderboard(data.dados);
            }
        })
        .catch(error => console.error('Erro ao carregar leaderboard:', error));
}

function atualizarProgresso(progresso) {
    const languages = ['html', 'css', 'javascript', 'python', 'java'];
    
    languages.forEach(lang => {
        const percent = progresso[lang] || 0;
        const percentSpan = document.getElementById(`${lang}-percent`);
        const progressFill = document.getElementById(`${lang}-progress`);
        
        if (percentSpan) percentSpan.textContent = percent + '%';
        if (progressFill) progressFill.style.width = percent + '%';
    });
}

function atualizarHistorico(historico) {
    const historyBody = document.getElementById('history-body');
    if (!historyBody) return;
    
    if (!historico || historico.length === 0) {
        historyBody.innerHTML = '<tr><td colspan="5" style="text-align: center;">Nenhum quiz realizado ainda</td></tr>';
        return;
    }
    
    historyBody.innerHTML = historico.slice(0, 10).map(item => {
        const data = new Date(item.data).toLocaleDateString('pt-BR');
        const hora = new Date(item.data).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
        const percent = Math.round((item.pontuacao / (item.total_perguntas * 10)) * 100);
        
        let resultadoClass = '';
        if (percent >= 80) resultadoClass = 'resultado-bom';
        else if (percent >= 50) resultadoClass = 'resultado-medio';
        else resultadoClass = 'resultado-ruim';
        
        return `
            <tr>
                <td>${data} ${hora}</td>
                <td>${item.linguagem.toUpperCase()}</td>
                <td><span class="difficulty-badge ${item.dificuldade}">${item.dificuldade}</span></td>
                <td>${item.pontuacao}</td>
                <td class="${resultadoClass}">${percent}%</td>
            </tr>
        `;
    }).join('');
}

function atualizarLeaderboard(leaderboard) {
    const leaderboardBody = document.getElementById('leaderboard-body');
    if (!leaderboardBody) return;
    
    if (!leaderboard || leaderboard.length === 0) {
        leaderboardBody.innerHTML = '<tr><td colspan="3" style="text-align: center;">Nenhum dado disponível</td></tr>';
        return;
    }
    
    leaderboardBody.innerHTML = leaderboard.map((item, index) => {
        const posicao = index + 1;
        let medalha = '';
        let classe = '';
        
        if (posicao === 1) {
            medalha = '🥇';
            classe = 'gold';
        } else if (posicao === 2) {
            medalha = '🥈';
            classe = 'silver';
        } else if (posicao === 3) {
            medalha = '🥉';
            classe = 'bronze';
        }
        
        return `
            <tr class="${classe}">
                <td>${medalha} #${posicao}</td>
                <td>${item.nome}</td>
                <td>${item.pontos}</td>
            </tr>
        `;
    }).join('');
}

function mostrarMensagem(mensagem, tipo = 'sucesso') {
    let msgContainer = document.querySelector('.mensagem-container');
    
    if (!msgContainer) {
        msgContainer = document.createElement('div');
        msgContainer.className = 'mensagem-container';
        document.body.appendChild(msgContainer);
    }
    
    const msg = document.createElement('div');
    msg.className = `mensagem mensagem-${tipo}`;
    msg.textContent = mensagem;
    
    // Adicionar ícone
    const icon = document.createElement('i');
    if (tipo === 'sucesso') icon.className = 'bx bx-check-circle';
    else if (tipo === 'erro') icon.className = 'bx bx-error-circle';
    else if (tipo === 'info') icon.className = 'bx bx-info-circle';
    else if (tipo === 'aviso') icon.className = 'bx bx-error';
    else if (tipo === 'achievement') icon.className = 'bx bx-trophy';
    
    msg.prepend(icon);
    
    msgContainer.appendChild(msg);
    
    // Animação de entrada
    setTimeout(() => {
        msg.style.opacity = '1';
        msg.style.transform = 'translateX(0)';
    }, 10);
    
    setTimeout(() => {
        msg.style.opacity = '0';
        msg.style.transform = 'translateX(100%)';
        setTimeout(() => msg.remove(), 300);
    }, 3000);
}

// ===========================================
// SISTEMA DE NAVEGAÇÃO
// ===========================================
function configurarNavegacao() {
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const modo = link.dataset.mode;
            if (modo) mudarModo(modo);
        });
    });
    
    document.querySelectorAll('.mode-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const modo = btn.dataset.mode;
            if (modo) mudarModo(modo);
        });
    });
    
    document.querySelectorAll('.footer-links a').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const modo = link.dataset.mode;
            if (modo) mudarModo(modo);
        });
    });
}

function mudarModo(modo) {
    const modosRestritos = ['quiz', 'practice', 'dashboard', 'challenge', 'profile', 'achievements'];
    const userName = document.getElementById('user-name').textContent;
    
    if (modosRestritos.includes(modo) && userName === 'Convidado') {
        document.getElementById('auth-modal').classList.add('active');
        mostrarMensagem('Faça login para acessar esta funcionalidade', 'info');
        return;
    }
    
    AppState.currentMode = modo;
    
    document.querySelectorAll('.mode-btn').forEach(btn => {
        btn.classList.toggle('active', btn.dataset.mode === modo);
    });
    
    document.querySelectorAll('.study-mode, .quiz-mode, .practice-mode, .dashboard-mode, .challenge-mode, .profile-mode, .achievements-mode').forEach(section => {
        section.classList.remove('active');
    });
    
    const modoSection = document.querySelector(`.${modo}-mode`);
    if (modoSection) {
        modoSection.classList.add('active');
    }
    
    switch(modo) {
        case 'study':
            carregarRecursos('html');
            break;
        case 'quiz':
            resetarQuiz();
            break;
        case 'achievements':
            carregarConquistas();
            break;
        case 'practice':
            setTimeout(() => {
                if (codeEditor) {
                    codeEditor.refresh();
                }
            }, 100);
            break;
        case 'profile':
            carregarPerfil();
            break;
        case 'dashboard':
            carregarDashboard();
            break;
    }
    
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function carregarPerfil() {
    // Já atualizado pelo atualizarInterfaceUsuario
    const editName = document.getElementById('edit-name');
    const editBio = document.getElementById('edit-bio');
    
    if (editName && AppState.currentUser) {
        editName.value = AppState.currentUser.nome || '';
    }
    
    if (editBio && AppState.currentUser) {
        editBio.value = AppState.currentUser.bio || '';
    }
}

function carregarDashboard() {
    // Atualizar estatísticas
    const totalPointsDash = document.getElementById('total-points-dash');
    const totalQuizzesDash = document.getElementById('total-quizzes-dash');
    const streakDash = document.getElementById('streak-dash');
    const studyTime = document.getElementById('study-time');
    
    if (totalPointsDash) totalPointsDash.textContent = AppState.totalPoints;
    if (totalQuizzesDash) totalQuizzesDash.textContent = AppState.quizHistory.length;
    if (streakDash) streakDash.textContent = AppState.streak;
    if (studyTime) studyTime.textContent = Math.floor(AppState.quizHistory.length * 5); // 5 min por quiz
    
    // Atualizar histórico
    atualizarHistorico(AppState.quizHistory);
}

// ===========================================
// DADOS DOS RECURSOS DE ESTUDO (75 recursos)
// ===========================================
const RESOURCES = {
    html: [
        { title: "MDN Web Docs - HTML", url: "https://developer.mozilla.org/pt-BR/docs/Web/HTML", descricao: "Documentação oficial e completa sobre HTML", dificuldade: "Iniciante", tempo: "30 min", icone: "bxl-html5" },
        { title: "W3Schools - HTML Tutorial", url: "https://www.w3schools.com/html/", descricao: "Tutorial interativo com exemplos práticos", dificuldade: "Iniciante", tempo: "2 horas", icone: "bxl-html5" },
        { title: "HTML.com Tutorial", url: "https://html.com/", descricao: "Guia completo para iniciantes", dificuldade: "Iniciante", tempo: "1 hora", icone: "bxl-html5" },
        { title: "FreeCodeCamp - HTML", url: "https://www.freecodecamp.org/learn/responsive-web-design/", descricao: "Curso gratuito com certificado", dificuldade: "Iniciante", tempo: "5 horas", icone: "bxl-free-code-camp" },
        { title: "Codecademy - Learn HTML", url: "https://www.codecademy.com/learn/learn-html", descricao: "Curso interativo com exercícios", dificuldade: "Iniciante", tempo: "3 horas", icone: "bx-code-curly" },
        { title: "HTML5 Doctor", url: "http://html5doctor.com/", descricao: "Artigos e dicas sobre HTML5", dificuldade: "Intermediário", tempo: "30 min", icone: "bx-book-open" },
        { title: "Rafaella Ballerini - HTML", url: "https://www.youtube.com/watch?v=3oSIqIqzN3M", descricao: "Tutorial em vídeo para iniciantes", dificuldade: "Iniciante", tempo: "1 hora", icone: "bxl-youtube" },
        { title: "Curso em Vídeo - HTML5", url: "https://www.youtube.com/watch?v=epDCjksKMok", descricao: "Curso completo de HTML5 em português", dificuldade: "Iniciante", tempo: "5 horas", icone: "bxl-youtube" },
        { title: "DevMedia - HTML", url: "https://www.devmedia.com.br/html/", descricao: "Tutoriais e artigos em português", dificuldade: "Iniciante", tempo: "2 horas", icone: "bx-code-block" },
        { title: "Tableless - HTML", url: "https://tableless.com.br/categories/html/", descricao: "Artigos sobre HTML e desenvolvimento web", dificuldade: "Intermediário", tempo: "1 hora", icone: "bx-news" },
        { title: "HTML Reference", url: "https://htmlreference.io/", descricao: "Guia visual de referência HTML", dificuldade: "Iniciante", tempo: "30 min", icone: "bx-book-content" },
        { title: "MarkSheet", url: "https://marksheet.io/", descricao: "Tutorial gratuito de HTML e CSS", dificuldade: "Iniciante", tempo: "2 horas", icone: "bx-file" },
        { title: "Interneting Is Hard", url: "https://www.internetingishard.com/html-and-css/", descricao: "Tutorial amigável para iniciantes", dificuldade: "Iniciante", tempo: "3 horas", icone: "bx-code-alt" },
        { title: "Learn HTML - web.dev", url: "https://web.dev/learn/html/", descricao: "Curso do Google sobre HTML", dificuldade: "Iniciante", tempo: "2 horas", icone: "bxl-google" },
        { title: "HTML Dog", url: "https://htmldog.com/guides/html/", descricao: "Tutoriais de HTML para todos os níveis", dificuldade: "Todos", tempo: "4 horas", icone: "bx-dog" }
    ],
    css: [
        { title: "MDN Web Docs - CSS", url: "https://developer.mozilla.org/pt-BR/docs/Web/CSS", descricao: "Documentação oficial sobre CSS", dificuldade: "Todos", tempo: "30 min", icone: "bxl-css3" },
        { title: "W3Schools - CSS Tutorial", url: "https://www.w3schools.com/css/", descricao: "Tutorial interativo com exemplos", dificuldade: "Iniciante", tempo: "2 horas", icone: "bxl-css3" },
        { title: "CSS-Tricks", url: "https://css-tricks.com/", descricao: "Dicas, truques e tutoriais avançados", dificuldade: "Avançado", tempo: "1 hora", icone: "bx-code-curly" },
        { title: "FreeCodeCamp - CSS", url: "https://www.freecodecamp.org/learn/responsive-web-design/", descricao: "Curso gratuito com certificado", dificuldade: "Iniciante", tempo: "5 horas", icone: "bxl-free-code-camp" },
        { title: "Flexbox Froggy", url: "https://flexboxfroggy.com/", descricao: "Jogo interativo para aprender Flexbox", dificuldade: "Iniciante", tempo: "30 min", icone: "bx-frog" },
        { title: "Grid Garden", url: "https://cssgridgarden.com/", descricao: "Jogo interativo para aprender CSS Grid", dificuldade: "Iniciante", tempo: "30 min", icone: "bx-grid" },
        { title: "Origamid - CSS", url: "https://www.origamid.com/cursos/css-completo/", descricao: "Curso completo de CSS em português", dificuldade: "Todos", tempo: "10 horas", icone: "bx-leaf" },
        { title: "Rafaella Ballerini - CSS", url: "https://www.youtube.com/watch?v=vwbegraDXDY", descricao: "Tutorial de CSS para iniciantes", dificuldade: "Iniciante", tempo: "1 hora", icone: "bxl-youtube" },
        { title: "CSS Layout", url: "https://csslayout.io/", descricao: "Padrões e layouts CSS prontos", dificuldade: "Intermediário", tempo: "30 min", icone: "bx-layout" },
        { title: "Neumorphism.io", url: "https://neumorphism.io/", descricao: "Gerador de CSS para neomorfismo", dificuldade: "Intermediário", tempo: "15 min", icone: "bx-shape-circle" },
        { title: "CSS Diner", url: "https://flukeout.github.io/", descricao: "Jogo para aprender seletores CSS", dificuldade: "Iniciante", tempo: "30 min", icone: "bx-restaurant" },
        { title: "100 Days CSS", url: "https://100dayscss.com/", descricao: "Desafio de 100 dias de CSS", dificuldade: "Todos", tempo: "20 min/dia", icone: "bx-calendar" },
        { title: "CSS Pro", url: "https://csspro.com/", descricao: "Tutoriais avançados de CSS", dificuldade: "Avançado", tempo: "2 horas", icone: "bx-code-block" },
        { title: "Smashing Magazine", url: "https://www.smashingmagazine.com/category/css/", descricao: "Artigos sobre CSS e design", dificuldade: "Todos", tempo: "30 min", icone: "bx-magazine" },
        { title: "CSS Wizardry", url: "https://csswizardry.com/", descricao: "Blog sobre arquitetura CSS", dificuldade: "Avançado", tempo: "30 min", icone: "bx-magic" }
    ],
    javascript: [
        { title: "MDN Web Docs - JavaScript", url: "https://developer.mozilla.org/pt-BR/docs/Web/JavaScript", descricao: "Documentação oficial e completa", dificuldade: "Todos", tempo: "30 min", icone: "bxl-javascript" },
        { title: "W3Schools - JavaScript Tutorial", url: "https://www.w3schools.com/js/", descricao: "Tutorial interativo com exemplos", dificuldade: "Iniciante", tempo: "2 horas", icone: "bxl-javascript" },
        { title: "JavaScript.info", url: "https://javascript.info/", descricao: "Tutorial moderno e completo", dificuldade: "Todos", tempo: "5 horas", icone: "bx-info-circle" },
        { title: "FreeCodeCamp - JavaScript", url: "https://www.freecodecamp.org/learn/javascript-algorithms-and-data-structures/", descricao: "Curso gratuito com certificado", dificuldade: "Iniciante", tempo: "10 horas", icone: "bxl-free-code-camp" },
        { title: "Curso em Vídeo - JavaScript", url: "https://www.youtube.com/watch?v=BXqUH86F-kA", descricao: "Curso completo em português", dificuldade: "Iniciante", tempo: "6 horas", icone: "bxl-youtube" },
        { title: "30 Days of JavaScript", url: "https://github.com/Asabeneh/30-Days-Of-JavaScript", descricao: "Desafio de 30 dias", dificuldade: "Todos", tempo: "30 dias", icone: "bx-calendar" },
        { title: "Eloquent JavaScript", url: "https://eloquentjavascript.net/", descricao: "Livro online gratuito", dificuldade: "Intermediário", tempo: "8 horas", icone: "bx-book" },
        { title: "You Don't Know JS", url: "https://github.com/getify/You-Dont-Know-JS", descricao: "Série de livros avançados", dificuldade: "Avançado", tempo: "10 horas", icone: "bx-book-open" },
        { title: "JSFiddle", url: "https://jsfiddle.net/", descricao: "Editor online para testar código", dificuldade: "Todos", tempo: "15 min", icone: "bx-code" },
        { title: "CodePen", url: "https://codepen.io/", descricao: "Comunidade de exemplos e projetos", dificuldade: "Todos", tempo: "30 min", icone: "bx-pen" },
        { title: "JavaScript30", url: "https://javascript30.com/", descricao: "30 projetos em 30 dias", dificuldade: "Intermediário", tempo: "30 dias", icone: "bx-code-block" },
        { title: "Exercism", url: "https://exercism.org/tracks/javascript", descricao: "Exercícios práticos de JavaScript", dificuldade: "Todos", tempo: "2 horas", icone: "bx-dumbbell" },
        { title: "Codewars", url: "https://www.codewars.com/?language=javascript", descricao: "Desafios de código", dificuldade: "Todos", tempo: "1 hora", icone: "bx-code-curly" },
        { title: "JavaScript Questions", url: "https://github.com/lydiahallie/javascript-questions", descricao: "Perguntas avançadas de JavaScript", dificuldade: "Avançado", tempo: "2 horas", icone: "bx-question-mark" },
        { title: "Exploring JS", url: "https://exploringjs.com/", descricao: "Livros sobre JavaScript", dificuldade: "Todos", tempo: "5 horas", icone: "bx-compass" }
    ],
    python: [
        { title: "Python.org Documentation", url: "https://docs.python.org/3/", descricao: "Documentação oficial", dificuldade: "Todos", tempo: "30 min", icone: "bxl-python" },
        { title: "W3Schools - Python Tutorial", url: "https://www.w3schools.com/python/", descricao: "Tutorial interativo", dificuldade: "Iniciante", tempo: "2 horas", icone: "bxl-python" },
        { title: "Real Python", url: "https://realpython.com/", descricao: "Tutoriais e artigos práticos", dificuldade: "Todos", tempo: "1 hora", icone: "bx-code-block" },
        { title: "FreeCodeCamp - Python", url: "https://www.freecodecamp.org/learn/scientific-computing-with-python/", descricao: "Curso gratuito", dificuldade: "Iniciante", tempo: "8 horas", icone: "bxl-free-code-camp" },
        { title: "Curso em Vídeo - Python", url: "https://www.youtube.com/watch?v=S9uPNppGsGo", descricao: "Curso completo em português", dificuldade: "Iniciante", tempo: "6 horas", icone: "bxl-youtube" },
        { title: "Python Brasil", url: "https://python.org.br/", descricao: "Comunidade brasileira de Python", dificuldade: "Todos", tempo: "30 min", icone: "bx-group" },
        { title: "Automate the Boring Stuff", url: "https://automatetheboringstuff.com/", descricao: "Livro prático gratuito", dificuldade: "Iniciante", tempo: "5 horas", icone: "bx-book" },
        { title: "PyBrasil", url: "https://pybrasil.com.br/", descricao: "Conteúdo em português", dificuldade: "Todos", tempo: "30 min", icone: "bx-world" },
        { title: "Python Tutor", url: "http://pythontutor.com/", descricao: "Visualizador de execução de código", dificuldade: "Iniciante", tempo: "15 min", icone: "bx-chalkboard" },
        { title: "Django Girls", url: "https://tutorial.djangogirls.org/pt/", descricao: "Tutorial de Django em português", dificuldade: "Intermediário", tempo: "3 horas", icone: "bx-female" },
        { title: "Python for Everybody", url: "https://www.py4e.com/", descricao: "Curso gratuito para todos", dificuldade: "Iniciante", tempo: "5 horas", icone: "bx-group" },
        { title: "Learn Python", url: "https://www.learnpython.org/", descricao: "Tutorial interativo", dificuldade: "Iniciante", tempo: "2 horas", icone: "bx-code" },
        { title: "Python Crash Course", url: "https://ehmatthes.github.io/pcc/", descricao: "Livro de exercícios", dificuldade: "Iniciante", tempo: "4 horas", icone: "bx-book-open" },
        { title: "Pythontips", url: "https://book.pythontips.com/", descricao: "Dicas e truques de Python", dificuldade: "Intermediário", tempo: "1 hora", icone: "bx-bulb" },
        { title: "Full Stack Python", url: "https://www.fullstackpython.com/", descricao: "Guia para desenvolvimento completo", dificuldade: "Avançado", tempo: "3 horas", icone: "bx-layer" }
    ],
    java: [
        { title: "Oracle Java Documentation", url: "https://docs.oracle.com/javase/tutorial/", descricao: "Documentação oficial", dificuldade: "Todos", tempo: "30 min", icone: "bxl-java" },
        { title: "W3Schools - Java Tutorial", url: "https://www.w3schools.com/java/", descricao: "Tutorial interativo", dificuldade: "Iniciante", tempo: "2 horas", icone: "bxl-java" },
        { title: "JavaTpoint", url: "https://www.javatpoint.com/java-tutorial", descricao: "Tutoriais completos", dificuldade: "Iniciante", tempo: "3 horas", icone: "bx-code-block" },
        { title: "GeeksforGeeks - Java", url: "https://www.geeksforgeeks.org/java/", descricao: "Artigos e exemplos", dificuldade: "Todos", tempo: "2 horas", icone: "bx-code-curly" },
        { title: "Curso em Vídeo - Java", url: "https://www.youtube.com/watch?v=sTX0UEplF54", descricao: "Curso completo em português", dificuldade: "Iniciante", tempo: "6 horas", icone: "bxl-youtube" },
        { title: "Loiane Groner - Java", url: "https://loiane.training/curso/java-basico", descricao: "Curso gratuito em português", dificuldade: "Iniciante", tempo: "4 horas", icone: "bx-video" },
        { title: "Baeldung", url: "https://www.baeldung.com/", descricao: "Tutoriais avançados", dificuldade: "Avançado", tempo: "1 hora", icone: "bx-code-alt" },
        { title: "Java Code Geeks", url: "https://www.javacodegeeks.com/", descricao: "Exemplos e artigos", dificuldade: "Todos", tempo: "1 hora", icone: "bx-code" },
        { title: "DevMedia - Java", url: "https://www.devmedia.com.br/java/", descricao: "Tutoriais em português", dificuldade: "Iniciante", tempo: "2 horas", icone: "bx-news" },
        { title: "Mkyong", url: "https://mkyong.com/", descricao: "Exemplos práticos de Java", dificuldade: "Intermediário", tempo: "1 hora", icone: "bx-code-block" },
        { title: "Java Brains", url: "https://javabrains.io/", descricao: "Cursos em vídeo gratuitos", dificuldade: "Todos", tempo: "3 horas", icone: "bx-brain" },
        { title: "JournalDev", url: "https://www.journaldev.com/java", descricao: "Tutoriais e exemplos", dificuldade: "Intermediário", tempo: "2 horas", icone: "bx-notepad" },
        { title: "Programiz", url: "https://www.programiz.com/java-programming", descricao: "Tutoriais simples e diretos", dificuldade: "Iniciante", tempo: "2 horas", icone: "bx-code" },
        { title: "Java World", url: "https://www.javaworld.com/", descricao: "Notícias e artigos", dificuldade: "Todos", tempo: "30 min", icone: "bx-globe" },
        { title: "InfoQ Java", url: "https://www.infoq.com/java/", descricao: "Artigos e apresentações", dificuldade: "Avançado", tempo: "1 hora", icone: "bx-slideshow" }
    ]
};

function configurarLanguageCards() {
    document.querySelectorAll('.language-card').forEach(card => {
        card.addEventListener('click', () => {
            const lang = card.dataset.lang;
            if (lang) {
                carregarRecursos(lang);
                card.style.transform = 'scale(0.95)';
                setTimeout(() => card.style.transform = 'scale(1)', 150);
            }
        });
    });
}

function carregarRecursos(linguagem) {
    const selectedLang = document.getElementById('selected-language');
    const resourceList = document.getElementById('resource-list');
    const resourcesCount = document.getElementById('resources-count');
    
    if (!selectedLang || !resourceList) return;
    
    selectedLang.textContent = linguagem.toUpperCase();
    
    const recursos = RESOURCES[linguagem] || [];
    if (resourcesCount) {
        resourcesCount.textContent = `${recursos.length} recursos disponíveis`;
    }
    
    resourceList.innerHTML = recursos.map(r => `
        <div class="resource-item">
            <div class="resource-icon"><i class='bx ${r.icone}'></i></div>
            <div class="resource-content">
                <h3>${r.title}</h3>
                <p>${r.descricao}</p>
                <div class="resource-meta">
                    <span class="resource-difficulty ${r.dificuldade.toLowerCase()}">${r.dificuldade}</span>
                    <span class="resource-time"><i class='bx bx-time'></i> ${r.tempo}</span>
                </div>
                <a href="${r.url}" target="_blank" rel="noopener noreferrer" class="resource-link">
                    <i class='bx bx-link-external'></i> Acessar recurso
                </a>
            </div>
        </div>
    `).join('');
}

// ===========================================
// PERFIL
// ===========================================
window.salvarPerfil = function() {
    const nome = document.getElementById('edit-name').value.trim();
    const bio = document.getElementById('edit-bio').value.trim();
    
    if (!nome) {
        mostrarMensagem('O nome não pode estar vazio', 'erro');
        return;
    }
    
    const formData = new FormData();
    formData.append('nome', nome);
    formData.append('bio', bio);
    
    fetch('api.php?acao=atualizar_perfil', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.sucesso) {
            mostrarMensagem('Perfil atualizado com sucesso!', 'sucesso');
            
            const userName = document.getElementById('user-name');
            const profileName = document.getElementById('profile-name');
            const profileBio = document.getElementById('profile-bio');
            
            if (userName) userName.textContent = nome;
            if (profileName) profileName.textContent = nome;
            if (profileBio) profileBio.textContent = bio || 'Aprendiz de programação';
            
            if (AppState.currentUser) {
                AppState.currentUser.nome = nome;
                AppState.currentUser.bio = bio;
            }
        } else {
            mostrarMensagem(data.mensagem || 'Erro ao atualizar perfil', 'erro');
        }
    })
    .catch(error => {
        console.error('Erro ao atualizar perfil:', error);
        mostrarMensagem('Erro ao atualizar perfil. Tente novamente.', 'erro');
    });
};

// ===========================================
// CONQUISTAS (21 conquistas com ícones)
// ===========================================
const ACHIEVEMENTS = [
    { id: 'first_quiz', nome: 'Primeiro Quiz', descricao: 'Complete seu primeiro quiz', icone: 'bx-flag', pontos: 10, categoria: 'quiz' },
    { id: 'quiz_master', nome: 'Mestre dos Quizzes', descricao: 'Complete 5 quizzes', icone: 'bx-brain', pontos: 50, categoria: 'quiz' },
    { id: 'quiz_legend', nome: 'Lenda dos Quizzes', descricao: 'Complete 25 quizzes', icone: 'bx-crown', pontos: 250, categoria: 'quiz' },
    { id: 'points_100', nome: '100 Pontos', descricao: 'Acumule 100 pontos', icone: 'bx-star', pontos: 20, categoria: 'pontos' },
    { id: 'points_500', nome: '500 Pontos', descricao: 'Acumule 500 pontos', icone: 'bx-star', pontos: 50, categoria: 'pontos' },
    { id: 'points_1000', nome: '1000 Pontos', descricao: 'Acumule 1000 pontos', icone: 'bx-star', pontos: 100, categoria: 'pontos' },
    { id: 'points_5000', nome: '5000 Pontos', descricao: 'Acumule 5000 pontos', icone: 'bx-star', pontos: 500, categoria: 'pontos' },
    { id: 'streak_7', nome: 'Semana de Fogo', descricao: 'Mantenha streak por 7 dias', icone: 'bx-flame', pontos: 100, categoria: 'streak' },
    { id: 'streak_30', nome: 'Mês Dedicado', descricao: 'Mantenha streak por 30 dias', icone: 'bx-hot', pontos: 300, categoria: 'streak' },
    { id: 'streak_100', nome: 'Centenário', descricao: 'Mantenha streak por 100 dias', icone: 'bx-calendar-star', pontos: 1000, categoria: 'streak' },
    { id: 'html_pro', nome: 'HTML Pro', descricao: 'Complete 10 quizzes de HTML', icone: 'bxl-html5', pontos: 75, categoria: 'linguagem' },
    { id: 'css_pro', nome: 'CSS Pro', descricao: 'Complete 10 quizzes de CSS', icone: 'bxl-css3', pontos: 75, categoria: 'linguagem' },
    { id: 'js_pro', nome: 'JavaScript Pro', descricao: 'Complete 10 quizzes de JavaScript', icone: 'bxl-javascript', pontos: 75, categoria: 'linguagem' },
    { id: 'python_pro', nome: 'Python Pro', descricao: 'Complete 10 quizzes de Python', icone: 'bxl-python', pontos: 75, categoria: 'linguagem' },
    { id: 'java_pro', nome: 'Java Pro', descricao: 'Complete 10 quizzes de Java', icone: 'bxl-java', pontos: 75, categoria: 'linguagem' },
    { id: 'perfect_score', nome: 'Perfeição', descricao: 'Acerte 100% em um quiz', icone: 'bx-check-double', pontos: 100, categoria: 'quiz' },
    { id: 'speed_demon', nome: 'Demônio da Velocidade', descricao: 'Complete um quiz cronometrado', icone: 'bx-timer', pontos: 50, categoria: 'quiz' },
    { id: 'marathon', nome: 'Maratonista', descricao: 'Complete 15 perguntas em um quiz', icone: 'bx-run', pontos: 75, categoria: 'quiz' },
    { id: 'code_master', nome: 'Mestre do Código', descricao: 'Execute 50 códigos no editor', icone: 'bx-code-alt', pontos: 200, categoria: 'editor' },
    { id: 'debugger', nome: 'Caçador de Bugs', descricao: 'Corrija 10 erros no editor', icone: 'bx-bug-alt', pontos: 150, categoria: 'editor' },
    { id: 'social', nome: 'Compartilhador', descricao: 'Compartilhe 5 resultados', icone: 'bx-share-alt', pontos: 50, categoria: 'social' }
];

function carregarConquistas() {
    const container = document.getElementById('achievements-grid');
    if (!container) return;
    
    const conquistasDesbloqueadas = AppState.achievements || [];
    
    // Agrupar por categoria
    const categorias = {
        quiz: '📚 Quizzes',
        pontos: '⭐ Pontuação',
        streak: '🔥 Streak',
        linguagem: '💻 Linguagens',
        editor: '✏️ Editor',
        social: '🤝 Social'
    };
    
    let html = '';
    
    for (const [categoria, titulo] of Object.entries(categorias)) {
        const conquistasCategoria = ACHIEVEMENTS.filter(a => a.categoria === categoria);
        if (conquistasCategoria.length === 0) continue;
        
        html += `<h3 class="categoria-titulo">${titulo}</h3>`;
        html += '<div class="categoria-grid">';
        
        conquistasCategoria.forEach(ach => {
            const desbloqueada = conquistasDesbloqueadas.includes(ach.id);
            
            html += `
                <div class="achievement-card ${desbloqueada ? 'unlocked' : 'locked'}">
                    <div class="achievement-icon-large">
                        <i class='bx ${ach.icone}'></i>
                    </div>
                    <h4>${ach.nome}</h4>
                    <p>${ach.descricao}</p>
                    <div class="achievement-points">+${ach.pontos} ⭐</div>
                    ${desbloqueada ? '<div class="achievement-badge">✔️ Desbloqueado</div>' : ''}
                </div>
            `;
        });
        
        html += '</div>';
    }
    
    container.innerHTML = html;
    
    const unlockedEl = document.getElementById('achievements-unlocked');
    const totalEl = document.getElementById('achievements-total');
    
    if (unlockedEl) unlockedEl.textContent = conquistasDesbloqueadas.length;
    if (totalEl) totalEl.textContent = ACHIEVEMENTS.length;
}

// ===========================================
// PERGUNTAS DO QUIZ (75 perguntas)
// ===========================================
const QUESTIONS = {
    html: {
        easy: [
            { question: "O que significa HTML?", options: ["HyperText Markup Language", "HighTech Modern Language", "HyperTransfer Markup Language", "Home Tool Markup Language"], correct: 0, points: 10 },
            { question: "Qual tag é usada para criar um link?", options: ["<link>", "<a>", "<href>", "<url>"], correct: 1, points: 10 },
            { question: "Qual tag define o título principal?", options: ["<h1>", "<head>", "<title>", "<header>"], correct: 0, points: 10 },
            { question: "Qual atributo é usado para imagens?", options: ["src", "href", "link", "url"], correct: 0, points: 10 },
            { question: "Qual tag cria lista não ordenada?", options: ["<ul>", "<ol>", "<li>", "<list>"], correct: 0, points: 10 }
        ],
        medium: [
            { question: "Qual atributo especifica uma classe CSS?", options: ["class", "css", "style", "id"], correct: 0, points: 20 },
            { question: "Qual elemento é para conteúdo principal?", options: ["<main>", "<body>", "<content>", "<section>"], correct: 0, points: 20 },
            { question: "Qual tag é semanticamente correta para navegação?", options: ["<nav>", "<menu>", "<navigation>", "<navbar>"], correct: 0, points: 20 },
            { question: "Qual elemento é usado para rodapé?", options: ["<footer>", "<bottom>", "<end>", "<foot>"], correct: 0, points: 20 },
            { question: "Qual elemento define um artigo independente?", options: ["<article>", "<post>", "<entry>", "<story>"], correct: 0, points: 20 }
        ],
        hard: [
            { question: "Qual elemento HTML5 é para conteúdo independente?", options: ["<article>", "<section>", "<aside>", "<div>"], correct: 0, points: 30 },
            { question: "Diferença entre <div> e <span>?", options: ["<div> é inline, <span> é block", "<div> é block, <span> é inline", "Ambos são block", "Ambos são inline"], correct: 1, points: 30 },
            { question: "Qual atributo melhora acessibilidade em imagens?", options: ["alt", "title", "aria-label", "description"], correct: 0, points: 30 },
            { question: "O que é Web Semântica?", options: ["Usar elementos que descrevem significado", "Adicionar semântica CSS", "Usar JavaScript semântico", "Implementar SEO"], correct: 0, points: 30 },
            { question: "Qual elemento é melhor para conteúdo relacionado?", options: ["<aside>", "<section>", "<div>", "<related>"], correct: 0, points: 30 }
        ]
    },
    css: {
        easy: [
            { question: "O que significa CSS?", options: ["Cascading Style Sheets", "Computer Style Sheets", "Creative Style System", "Colorful Style Sheets"], correct: 0, points: 10 },
            { question: "Qual propriedade muda cor do texto?", options: ["color", "text-color", "font-color", "text-style"], correct: 0, points: 10 },
            { question: "Como comentar em CSS?", options: ["/* comentário */", "// comentário", "<!-- comentário -->", "# comentário"], correct: 0, points: 10 },
            { question: "Qual propriedade controla o fundo?", options: ["background", "bg-color", "color-background", "background-color"], correct: 3, points: 10 },
            { question: "Como centralizar texto?", options: ["text-align: center;", "align: center;", "text-center: true;", "center: text;"], correct: 0, points: 10 }
        ],
        medium: [
            { question: "Qual propriedade cria espaço ENTRE elementos?", options: ["margin", "padding", "spacing", "gap"], correct: 0, points: 20 },
            { question: "Qual propriedade cria espaço DENTRO de elementos?", options: ["padding", "margin", "spacing", "gap"], correct: 0, points: 20 },
            { question: "Como centralizar um elemento horizontalmente?", options: ["margin: 0 auto;", "text-align: center;", "align: center;", "position: center;"], correct: 0, points: 20 },
            { question: "O que faz z-index?", options: ["Controla ordem de empilhamento", "Controla tamanho", "Controla transparência", "Controla rotação"], correct: 0, points: 20 },
            { question: "Qual unidade é relativa ao elemento pai?", options: ["em", "rem", "px", "vw"], correct: 0, points: 20 }
        ],
        hard: [
            { question: "Diferença entre display:none e visibility:hidden?", options: ["display:none remove do fluxo, visibility:hidden apenas esconde", "Ambos removem do fluxo", "visibility:hidden remove do fluxo", "Ambos apenas escondem"], correct: 0, points: 30 },
            { question: "O que é Flexbox?", options: ["Método de layout unidimensional", "Método de layout bidimensional", "Tipo de display para imagens", "Propriedade para flexibilidade"], correct: 0, points: 30 },
            { question: "O que é CSS Grid?", options: ["Método de layout bidimensional", "Método de layout unidimensional", "Framework CSS", "Sistema de templates"], correct: 0, points: 30 },
            { question: "O que faz @media query?", options: ["Aplica estilos baseado em condições", "Importa media files", "Cria animações", "Define variáveis CSS"], correct: 0, points: 30 },
            { question: "Qual pseudo-classe seleciona o primeiro filho?", options: [":first-child", ":first", ":first-of-type", ":nth-child(1)"], correct: 0, points: 30 }
        ]
    },
    javascript: {
        easy: [
            { question: "Como declarar variável em JavaScript?", options: ["let x;", "variable x;", "v x;", "declare x;"], correct: 0, points: 10 },
            { question: "Como imprimir no console?", options: ["console.log()", "print()", "log()", "display()"], correct: 0, points: 10 },
            { question: "Como criar uma função?", options: ["function myFunc() {}", "func myFunc() {}", "def myFunc() {}", "method myFunc() {}"], correct: 0, points: 10 },
            { question: "Qual operador verifica igualdade (valor e tipo)?", options: ["===", "==", "=", "!="], correct: 0, points: 10 },
            { question: "Qual operador verifica igualdade (apenas valor)?", options: ["==", "===", "=", "!="], correct: 0, points: 10 }
        ],
        medium: [
            { question: "O que é uma função de callback?", options: ["Função passada como argumento", "Função que retorna valor", "Função que chama a si mesma", "Função anônima"], correct: 0, points: 20 },
            { question: "O que é JSON?", options: ["JavaScript Object Notation", "JavaScript Online Network", "Java Standard Object Notation", "JavaScript Organized Nodes"], correct: 0, points: 20 },
            { question: "Como converter objeto para JSON?", options: ["JSON.stringify()", "JSON.parse()", "obj.toJSON()", "JSON.encode()"], correct: 0, points: 20 },
            { question: "Como converter JSON para objeto?", options: ["JSON.parse()", "JSON.stringify()", "JSON.toObj()", "JSON.decode()"], correct: 0, points: 20 },
            { question: "O que é DOM?", options: ["Document Object Model", "Data Object Management", "Digital Object Model", "Document Online Model"], correct: 0, points: 20 }
        ],
        hard: [
            { question: "O que é hoisting?", options: ["Elevação de variáveis/funções ao topo", "Técnica de otimização", "Tipo de loop", "Método de ordenação"], correct: 0, points: 30 },
            { question: "Diferença entre == e ===?", options: ["== compara valor, === compara valor e tipo", "== compara tipo, === compara valor", "== é mais rápido", "=== é mais rápido"], correct: 0, points: 30 },
            { question: "O que é closure?", options: ["Função que acessa escopo externo", "Função anônima", "Função autoexecutável", "Função assíncrona"], correct: 0, points: 30 },
            { question: "O que é this em JavaScript?", options: ["Refere-se ao contexto de execução", "Refere-se à função atual", "Refere-se ao objeto global", "Refere-se ao protótipo"], correct: 0, points: 30 },
            { question: "O que é protótipo (prototype)?", options: ["Mecanismo de herança", "Objeto base", "Função construtora", "Classe"], correct: 0, points: 30 }
        ]
    },
    python: {
        easy: [
            { question: "Como imprimir texto em Python?", options: ["print()", "console.log()", "echo()", "System.out.println()"], correct: 0, points: 10 },
            { question: "Como declarar variável em Python?", options: ["x = 5", "var x = 5", "let x = 5", "int x = 5"], correct: 0, points: 10 },
            { question: "Operador para potência?", options: ["**", "^", "pow()", "//"], correct: 0, points: 10 },
            { question: "Como criar uma lista?", options: ["[]", "{}", "()", "<>"], correct: 0, points: 10 },
            { question: "Como criar um comentário?", options: ["# comentário", "// comentário", "/* comentário */", "<!-- comentário -->"], correct: 0, points: 10 }
        ],
        medium: [
            { question: "O que é uma lista?", options: ["Coleção ordenada e mutável", "Coleção não ordenada", "Coleção imutável", "Estrutura chave-valor"], correct: 0, points: 20 },
            { question: "O que é uma tupla?", options: ["Coleção ordenada e imutável", "Coleção mutável", "Coleção não ordenada", "Estrutura chave-valor"], correct: 0, points: 20 },
            { question: "O que é um dicionário?", options: ["Estrutura chave-valor", "Lista ordenada", "Conjunto não ordenado", "Array multidimensional"], correct: 0, points: 20 },
            { question: "Como adicionar item à lista?", options: ["append()", "add()", "push()", "insert()"], correct: 0, points: 20 },
            { question: "Como remover item da lista?", options: ["remove()", "delete()", "pop()", "del()"], correct: 0, points: 20 }
        ],
        hard: [
            { question: "O que é um decorador?", options: ["Função que modifica outra função", "Tipo de loop", "Método de formatação", "Classe especial"], correct: 0, points: 30 },
            { question: "O que é list comprehension?", options: ["Forma concisa de criar listas", "Método de filtragem", "Tipo de loop", "Estrutura de dados"], correct: 0, points: 30 },
            { question: "O que é o GIL?", options: ["Global Interpreter Lock", "General Interface Layer", "Global Import Library", "General Input Loader"], correct: 0, points: 30 },
            { question: "O que é lambda?", options: ["Função anônima", "Expressão", "Tipo de dado", "Operador"], correct: 0, points: 30 },
            { question: "O que é orientação a objetos?", options: ["Paradigma com classes/objetos", "Programação", "Design", "Estrutura"], correct: 0, points: 30 }
        ]
    },
    java: {
        easy: [
            { question: "Como imprimir texto em Java?", options: ["System.out.println()", "print()", "console.log()", "echo()"], correct: 0, points: 10 },
            { question: "Como declarar variável inteira?", options: ["int x = 5;", "integer x = 5;", "Int x = 5;", "var x = 5;"], correct: 0, points: 10 },
            { question: "Palavra-chave para classe?", options: ["class", "Class", "type", "struct"], correct: 0, points: 10 },
            { question: "Qual o método principal?", options: ["public static void main(String[] args)", "main()", "public void main()", "static void main()"], correct: 0, points: 10 },
            { question: "Como criar um array?", options: ["int[] array = new int[10];", "int array[];", "new int[10];", "array int[];"], correct: 0, points: 10 }
        ],
        medium: [
            { question: "O que é uma classe?", options: ["Modelo para criar objetos", "Tipo de variável", "Método especial", "Estrutura de dados"], correct: 0, points: 20 },
            { question: "O que é herança?", options: ["extends", "inherits", "implements", "derives"], correct: 0, points: 20 },
            { question: "O que é um construtor?", options: ["Método que inicializa objetos", "Tipo de variável", "Classe abstrata", "Interface"], correct: 0, points: 20 },
            { question: "O que é encapsulamento?", options: ["Ocultar dados com private", "Encapsular", "Proteger", "Esconder"], correct: 0, points: 20 },
            { question: "O que é modificador private?", options: ["Acesso apenas na classe", "Acesso em qualquer lugar", "Acesso no pacote", "Acesso na subclasse"], correct: 0, points: 20 }
        ],
        hard: [
            { question: "O que é polimorfismo?", options: ["Métodos com mesmo nome em classes diferentes", "Herança múltipla", "Encapsulamento", "Sobrecarga de operadores"], correct: 0, points: 30 },
            { question: "O que são interfaces?", options: ["Contrato que classes implementam", "Classes abstratas", "Métodos estáticos", "Construtores"], correct: 0, points: 30 },
            { question: "O que é classe abstrata?", options: ["Classe que não pode ser instanciada", "Classe abstrata", "Classe base", "Classe pai"], correct: 0, points: 30 },
            { question: "O que é sobrescrita (override)?", options: ["Reescrever método da superclasse", "Sobrescrever", "Override", "Redefinir"], correct: 0, points: 30 },
            { question: "O que é sobrecarga (overload)?", options: ["Métodos com mesmo nome e parâmetros diferentes", "Sobrecarregar", "Overload", "Múltiplos métodos"], correct: 0, points: 30 }
        ]
    }
};

// ===========================================
// SISTEMA DE QUIZ
// ===========================================
let quizAtual = [];
let quizIndex = 0;
let quizScore = 0;
let quizRespostas = [];
let quizTimer = null;
let quizTimeLeft = 60;
let quizMode = 'normal';
let quizLinguagem = 'html';
let quizDificuldade = 'easy';

function configurarQuiz() {
    document.querySelectorAll('.quiz-mode-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.quiz-mode-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            quizMode = btn.dataset.mode;
            
            const timerDisplay = document.getElementById('timer-display');
            if (timerDisplay) {
                timerDisplay.style.display = quizMode === 'timed' ? 'flex' : 'none';
            }
        });
    });
    
    const startQuiz = document.getElementById('start-quiz');
    if (startQuiz) {
        startQuiz.addEventListener('click', iniciarQuiz);
    }
    
    const nextBtn = document.getElementById('next-btn');
    const prevBtn = document.getElementById('prev-btn');
    const submitBtn = document.getElementById('submit-btn');
    const restartBtn = document.getElementById('restart-btn');
    const shareBtn = document.getElementById('share-btn');
    
    if (nextBtn) nextBtn.addEventListener('click', proximaPergunta);
    if (prevBtn) prevBtn.addEventListener('click', perguntaAnterior);
    if (submitBtn) submitBtn.addEventListener('click', finalizarQuiz);
    if (restartBtn) restartBtn.addEventListener('click', resetarQuiz);
    if (shareBtn) shareBtn.addEventListener('click', compartilharResultado);
}

function resetarQuiz() {
    document.querySelector('.quiz-setup').style.display = 'block';
    document.getElementById('quiz-container').style.display = 'none';
    document.getElementById('results').style.display = 'none';
    
    if (quizTimer) {
        clearInterval(quizTimer);
        quizTimer = null;
    }
}

function iniciarQuiz() {
    const userName = document.getElementById('user-name').textContent;
    if (userName === 'Convidado') {
        mostrarMensagem('Faça login para fazer o quiz', 'erro');
        document.getElementById('auth-modal').classList.add('active');
        return;
    }
    
    quizLinguagem = document.getElementById('language-select').value;
    quizDificuldade = document.getElementById('difficulty-select').value;
    const count = parseInt(document.getElementById('question-count').value);
    
    const allQuestions = QUESTIONS[quizLinguagem]?.[quizDificuldade] || [];
    if (allQuestions.length === 0) {
        mostrarMensagem('Nenhuma pergunta disponível para esta combinação', 'erro');
        return;
    }
    
    quizAtual = [...allQuestions].sort(() => 0.5 - Math.random()).slice(0, Math.min(count, allQuestions.length));
    quizIndex = 0;
    quizScore = 0;
    quizRespostas = new Array(quizAtual.length).fill(null);
    quizTimeLeft = 60;
    
    document.getElementById('total-questions').textContent = quizAtual.length;
    document.getElementById('current-score').textContent = quizScore;
    document.getElementById('timer').textContent = quizTimeLeft;
    
    document.querySelector('.quiz-setup').style.display = 'none';
    document.getElementById('quiz-container').style.display = 'block';
    document.getElementById('results').style.display = 'none';
    
    const timerDisplay = document.getElementById('timer-display');
    if (timerDisplay) {
        timerDisplay.style.display = quizMode === 'timed' ? 'flex' : 'none';
    }
    
    if (quizMode === 'timed') {
        iniciarTimer();
    }
    
    carregarPergunta();
    
    // Desbloquear conquista speed_demon se for modo cronometrado
    if (quizMode === 'timed') {
        desbloquearConquista('speed_demon');
    }
    
    // Desbloquear conquista marathon se for 15 perguntas
    if (count >= 15) {
        desbloquearConquista('marathon');
    }
}

function iniciarTimer() {
    if (quizTimer) clearInterval(quizTimer);
    
    quizTimer = setInterval(() => {
        quizTimeLeft--;
        document.getElementById('timer').textContent = quizTimeLeft;
        
        if (quizTimeLeft <= 0) {
            finalizarQuiz();
        }
    }, 1000);
}

function carregarPergunta() {
    const pergunta = quizAtual[quizIndex];
    
    document.getElementById('current-question').textContent = quizIndex + 1;
    document.getElementById('question-text').textContent = pergunta.question;
    
    const difficultyBadge = document.getElementById('difficulty-badge');
    difficultyBadge.textContent = quizDificuldade === 'easy' ? 'Fácil' : quizDificuldade === 'medium' ? 'Médio' : 'Difícil';
    difficultyBadge.className = `difficulty-badge ${quizDificuldade}`;
    
    document.getElementById('points-badge').textContent = `${pergunta.points} pts`;
    
    const progress = ((quizIndex + 1) / quizAtual.length) * 100;
    document.getElementById('progress-fill').style.width = `${progress}%`;
    
    const optionsContainer = document.getElementById('options-container');
    optionsContainer.innerHTML = '';
    
    pergunta.options.forEach((option, index) => {
        const optionEl = document.createElement('div');
        optionEl.className = 'option';
        if (quizRespostas[quizIndex] === index) {
            optionEl.classList.add('selected');
        }
        optionEl.textContent = option;
        optionEl.dataset.index = index;
        optionEl.addEventListener('click', selecionarOpcao);
        optionsContainer.appendChild(optionEl);
    });
    
    document.getElementById('prev-btn').disabled = quizIndex === 0;
    
    const nextBtn = document.getElementById('next-btn');
    const submitBtn = document.getElementById('submit-btn');
    
    if (quizIndex === quizAtual.length - 1) {
        nextBtn.style.display = 'none';
        submitBtn.style.display = 'flex';
    } else {
        nextBtn.style.display = 'flex';
        submitBtn.style.display = 'none';
    }
}

function selecionarOpcao(e) {
    const index = parseInt(e.target.dataset.index);
    quizRespostas[quizIndex] = index;
    
    document.querySelectorAll('.option').forEach(opt => opt.classList.remove('selected'));
    e.target.classList.add('selected');
}

function proximaPergunta() {
    if (quizIndex < quizAtual.length - 1) {
        quizIndex++;
        carregarPergunta();
    }
}

function perguntaAnterior() {
    if (quizIndex > 0) {
        quizIndex--;
        carregarPergunta();
    }
}

function finalizarQuiz() {
    if (quizTimer) {
        clearInterval(quizTimer);
        quizTimer = null;
    }
    
    let corretas = 0;
    
    quizAtual.forEach((pergunta, index) => {
        if (quizRespostas[index] === pergunta.correct) {
            corretas++;
            quizScore += pergunta.points;
        }
    });
    
    if (quizMode === 'timed' && quizTimeLeft > 0) {
        quizScore += quizTimeLeft * 2;
    }
    
    const percentual = Math.round((corretas / quizAtual.length) * 100);
    
    document.getElementById('final-score').textContent = quizScore;
    document.getElementById('correct-answers').textContent = corretas;
    document.getElementById('total-questions-result').textContent = quizAtual.length;
    document.getElementById('percentage').textContent = `${percentual}%`;
    
    const feedback = document.getElementById('feedback');
    if (percentual >= 80) {
        feedback.textContent = '🎉 Excelente! Você domina este assunto!';
        feedback.className = 'feedback good';
    } else if (percentual >= 50) {
        feedback.textContent = '👍 Bom trabalho! Continue praticando!';
        feedback.className = 'feedback average';
    } else {
        feedback.textContent = '💡 Estude um pouco mais este tópico!';
        feedback.className = 'feedback poor';
    }
    
    document.getElementById('quiz-container').style.display = 'none';
    document.getElementById('results').style.display = 'block';
    
    salvarResultadoQuiz(corretas, percentual);
    
    // Verificar conquista de perfect score
    if (percentual === 100) {
        desbloquearConquista('perfect_score');
    }
}

function salvarResultadoQuiz(corretas, percentual) {
    if (corretas === 0) return;
    
    const formData = new FormData();
    formData.append('linguagem', quizLinguagem);
    formData.append('dificuldade', quizDificuldade);
    formData.append('pontuacao', quizScore);
    formData.append('total_perguntas', quizAtual.length);
    
    fetch('api.php?acao=salvar_quiz', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.sucesso) {
            const userPoints = document.getElementById('user-points');
            const totalPoints = document.getElementById('total-points');
            const currentPoints = parseInt(userPoints.textContent) || 0;
            const newPoints = currentPoints + quizScore;
            
            if (userPoints) userPoints.textContent = newPoints;
            if (totalPoints) totalPoints.textContent = newPoints;
            
            AppState.totalPoints = newPoints;
            localStorage.setItem('totalPoints', newPoints);
            
            const quizzesCompleted = document.getElementById('quizzes-completed');
            const totalQuizzesDash = document.getElementById('total-quizzes-dash');
            const currentQuizzes = parseInt(quizzesCompleted.textContent) || 0;
            
            if (quizzesCompleted) quizzesCompleted.textContent = currentQuizzes + 1;
            if (totalQuizzesDash) totalQuizzesDash.textContent = currentQuizzes + 1;
            
            // Verificar conquistas de pontos
            if (newPoints >= 100) desbloquearConquista('points_100');
            if (newPoints >= 500) desbloquearConquista('points_500');
            if (newPoints >= 1000) desbloquearConquista('points_1000');
            if (newPoints >= 5000) desbloquearConquista('points_5000');
            
            // Verificar conquista first_quiz
            if (currentQuizzes === 0) {
                desbloquearConquista('first_quiz');
            }
            
            // Verificar conquistas por linguagem
            if (quizLinguagem === 'html') {
                const htmlCount = AppState.quizHistory.filter(q => q.linguagem === 'html').length + 1;
                if (htmlCount >= 10) desbloquearConquista('html_pro');
            } else if (quizLinguagem === 'css') {
                const cssCount = AppState.quizHistory.filter(q => q.linguagem === 'css').length + 1;
                if (cssCount >= 10) desbloquearConquista('css_pro');
            } else if (quizLinguagem === 'javascript') {
                const jsCount = AppState.quizHistory.filter(q => q.linguagem === 'javascript').length + 1;
                if (jsCount >= 10) desbloquearConquista('js_pro');
            } else if (quizLinguagem === 'python') {
                const pythonCount = AppState.quizHistory.filter(q => q.linguagem === 'python').length + 1;
                if (pythonCount >= 10) desbloquearConquista('python_pro');
            } else if (quizLinguagem === 'java') {
                const javaCount = AppState.quizHistory.filter(q => q.linguagem === 'java').length + 1;
                if (javaCount >= 10) desbloquearConquista('java_pro');
            }
            
            const progressIncrease = Math.min(5, 100 - (parseInt(document.getElementById(`${quizLinguagem}-percent`).textContent) || 0));
            const newProgress = Math.min(100, (parseInt(document.getElementById(`${quizLinguagem}-percent`).textContent) || 0) + progressIncrease);
            
            document.getElementById(`${quizLinguagem}-percent`).textContent = newProgress + '%';
            document.getElementById(`${quizLinguagem}-progress`).style.width = newProgress + '%';
            
            mostrarMensagem(`Quiz salvo! +${quizScore} pontos`, 'sucesso');
        }
    })
    .catch(error => console.error('Erro ao salvar quiz:', error));
}

function compartilharResultado() {
    const score = document.getElementById('final-score').textContent;
    const percent = document.getElementById('percentage').textContent;
    const linguagem = quizLinguagem.toUpperCase();
    
    const texto = `🎯 Fiz ${percent} de acertos no quiz de ${linguagem} no CodeMaster Pro!`;
    
    if (navigator.share) {
        navigator.share({
            title: 'CodeMaster Pro - Resultado do Quiz',
            text: texto,
            url: window.location.href
        }).catch(() => {
            navigator.clipboard.writeText(texto);
            mostrarMensagem('Resultado copiado!', 'sucesso');
            
            // Contar compartilhamentos
            const shareCount = parseInt(localStorage.getItem('share_count') || '0') + 1;
            localStorage.setItem('share_count', shareCount);
            
            if (shareCount >= 5) {
                desbloquearConquista('social');
            }
        });
    } else {
        navigator.clipboard.writeText(texto);
        mostrarMensagem('Resultado copiado!', 'sucesso');
        
        const shareCount = parseInt(localStorage.getItem('share_count') || '0') + 1;
        localStorage.setItem('share_count', shareCount);
        
        if (shareCount >= 5) {
            desbloquearConquista('social');
        }
    }
}

// ===========================================
// DESAFIOS
// ===========================================
function configurarDesafios() {
    document.querySelectorAll('.challenge-start').forEach(btn => {
        btn.addEventListener('click', () => {
            const userName = document.getElementById('user-name').textContent;
            if (userName === 'Convidado') {
                mostrarMensagem('Faça login para fazer desafios', 'erro');
                document.getElementById('auth-modal').classList.add('active');
                return;
            }
            
            const type = btn.dataset.type;
            
            if (type === 'speed') {
                document.querySelector('.quiz-mode-btn[data-mode="timed"]').click();
                document.getElementById('question-count').value = '10';
                document.getElementById('difficulty-select').value = 'medium';
                mostrarMensagem('Desafio Rápido: 10 perguntas em 60 segundos!', 'info');
            } else if (type === 'marathon') {
                document.querySelector('.quiz-mode-btn[data-mode="normal"]').click();
                document.getElementById('question-count').value = '15';
                document.getElementById('difficulty-select').value = 'hard';
                mostrarMensagem('Maratona: 15 perguntas de dificuldade alta!', 'info');
            }
            
            iniciarQuiz();
        });
    });
    
    document.querySelectorAll('.challenge-start-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const userName = document.getElementById('user-name').textContent;
            if (userName === 'Convidado') {
                mostrarMensagem('Faça login para fazer desafios', 'erro');
                document.getElementById('auth-modal').classList.add('active');
                return;
            }
            
            const card = btn.closest('.challenge-card');
            const challengeId = card?.dataset.challenge;
            carregarDesafioEditor(challengeId);
        });
    });
}

function carregarDesafioEditor(challengeId) {
    if (!codeEditor) return;
    
    const desafios = {
        '1': `<!DOCTYPE html>
<html>
<head>
    <title>Calculadora Simples</title>
    <style>
        .calculator {
            max-width: 300px;
            margin: 50px auto;
            padding: 20px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            border-radius: 15px;
            box-shadow: 0 10px 20px rgba(0,0,0,0.2);
        }
        .display {
            background: white;
            padding: 15px;
            text-align: right;
            font-size: 2rem;
            margin-bottom: 15px;
            border-radius: 8px;
        }
        .buttons {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 10px;
        }
        button {
            padding: 15px;
            font-size: 1.2rem;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            background: white;
            transition: 0.2s;
        }
        button:hover { transform: scale(1.05); }
        .operator { background: #ffb347; }
        .equals { background: #4caf50; color: white; }
        .clear { background: #f44336; color: white; }
    </style>
</head>
<body>
    <div class="calculator">
        <div class="display" id="display">0</div>
        <div class="buttons">
            <button onclick="append('7')">7</button>
            <button onclick="append('8')">8</button>
            <button onclick="append('9')">9</button>
            <button class="operator" onclick="append('/')">/</button>
            <button onclick="append('4')">4</button>
            <button onclick="append('5')">5</button>
            <button onclick="append('6')">6</button>
            <button class="operator" onclick="append('*')">*</button>
            <button onclick="append('1')">1</button>
            <button onclick="append('2')">2</button>
            <button onclick="append('3')">3</button>
            <button class="operator" onclick="append('-')">-</button>
            <button class="clear" onclick="clearDisplay()">C</button>
            <button onclick="append('0')">0</button>
            <button class="equals" onclick="calculate()">=</button>
            <button class="operator" onclick="append('+')">+</button>
        </div>
    </div>

    <script>
        let display = document.getElementById('display');
        
        function append(value) {
            if (display.textContent === '0') {
                display.textContent = value;
            } else {
                display.textContent += value;
            }
        }
        
        function clearDisplay() {
            display.textContent = '0';
        }
        
        function calculate() {
            try {
                display.textContent = eval(display.textContent);
            } catch(e) {
                display.textContent = 'Erro';
            }
        }
    <\/script>
</body>
</html>`,
        '2': `<!DOCTYPE html>
<html>
<head>
    <title>Lista de Tarefas</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 500px;
            margin: 50px auto;
            padding: 20px;
            background: #f5f5f5;
        }
        .container {
            background: white;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
        }
        h1 {
            text-align: center;
            color: #667eea;
        }
        .input-group {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
        }
        input {
            flex: 1;
            padding: 10px;
            border: 2px solid #e0e0e0;
            border-radius: 5px;
            font-size: 16px;
        }
        button {
            padding: 10px 20px;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background: #764ba2;
        }
        ul {
            list-style: none;
            padding: 0;
        }
        li {
            background: #f9f9f9;
            padding: 10px;
            margin-bottom: 5px;
            border-radius: 5px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .delete {
            background: #f44336;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 3px;
            cursor: pointer;
        }
        .delete:hover {
            background: #d32f2f;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Lista de Tarefas</h1>
        <div class="input-group">
            <input type="text" id="taskInput" placeholder="Digite uma nova tarefa...">
            <button onclick="addTask()">Adicionar</button>
        </div>
        <ul id="taskList"></ul>
    </div>

    <script>
        function addTask() {
            const input = document.getElementById('taskInput');
            const text = input.value.trim();
            
            if (text) {
                const li = document.createElement('li');
                li.innerHTML = \`
                    <span>\${text}</span>
                    <button class="delete" onclick="this.parentElement.remove()">X</button>
                \`;
                
                document.getElementById('taskList').appendChild(li);
                input.value = '';
            }
        }
        
        document.getElementById('taskInput').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                addTask();
            }
        });
    <\/script>
</body>
</html>`
    };
    
    const desafio = desafios[challengeId];
    if (desafio) {
        codeEditor.setValue(desafio);
        mudarModo('practice');
        mostrarMensagem('Desafio carregado!', 'sucesso');
    }
}

// ===========================================
// EDITOR DE CÓDIGO - FUNCIONAL
// ===========================================
let codeEditor = null;

function inicializarEditor() {
    const textarea = document.getElementById('code-editor');
    if (!textarea) {
        console.error('Elemento textarea não encontrado');
        return;
    }
    
    // Verificar se CodeMirror está carregado
    if (typeof CodeMirror === 'undefined') {
        console.error('CodeMirror não está carregado. Aguardando...');
        setTimeout(inicializarEditor, 500);
        return;
    }
    
    try {
        const savedTheme = localStorage.getItem('codemaster_theme') || 'dark';
        const editorTheme = savedTheme === 'light' ? 'eclipse' : 'dracula';
        
        // Inicializar CodeMirror
        codeEditor = CodeMirror.fromTextArea(textarea, {
            lineNumbers: true,
            mode: 'htmlmixed',
            theme: editorTheme,
            autoCloseBrackets: true,
            matchBrackets: true,
            indentUnit: 4,
            tabSize: 4,
            lineWrapping: true,
            extraKeys: {
                "Ctrl-Space": "autocomplete",
                "Ctrl-Enter": function(cm) {
                    executarCodigo();
                },
                "F5": function(cm) {
                    executarCodigo();
                }
            }
        });
        
        // Definir código inicial
        codeEditor.setValue(`<!DOCTYPE html>
<html>
<head>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
        }
        h1 { text-align: center; }
        button {
            background: white;
            color: #667eea;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <h1>Olá, CodeMaster!</h1>
    <button onclick="alert('Funcionou!')">Clique aqui</button>
</body>
</html>`);
        
        console.log('✅ Editor de código inicializado');
        
        // Configurar botões do editor
        configurarBotoesEditor();
        
    } catch (error) {
        console.error('Erro ao inicializar editor:', error);
    }
}

function configurarBotoesEditor() {
    // Botão Executar
    const runBtn = document.getElementById('run-code');
    if (runBtn) {
        runBtn.addEventListener('click', executarCodigo);
    }
    
    // Botão Salvar
    const saveBtn = document.getElementById('save-code');
    if (saveBtn) {
        saveBtn.addEventListener('click', salvarCodigo);
    }
    
    // Botão Resetar
    const resetBtn = document.getElementById('reset-code');
    if (resetBtn) {
        resetBtn.addEventListener('click', resetarCodigo);
    }
    
    // Botão Limpar Saída
    const clearBtn = document.getElementById('clear-output');
    if (clearBtn) {
        clearBtn.addEventListener('click', limparSaida);
    }
    
    // Seletor de linguagem
    const langSelect = document.getElementById('editor-language');
    if (langSelect && codeEditor) {
        langSelect.addEventListener('change', () => {
            const mode = {
                'html': 'htmlmixed',
                'css': 'css',
                'javascript': 'javascript'
            }[langSelect.value] || 'htmlmixed';
            
            codeEditor.setOption('mode', mode);
        });
    }
    
    // Botão tema do editor
    const themeToggle = document.getElementById('theme-toggle-editor');
    if (themeToggle && codeEditor) {
        themeToggle.addEventListener('click', () => {
            const current = codeEditor.getOption('theme');
            const next = current === 'dracula' ? 'eclipse' : 'dracula';
            codeEditor.setOption('theme', next);
        });
    }
}

function executarCodigo() {
    // Verificar se usuário está logado
    const userName = document.getElementById('user-name').textContent;
    if (userName === 'Convidado') {
        mostrarMensagem('Faça login para usar o editor', 'erro');
        document.getElementById('auth-modal').classList.add('active');
        return;
    }
    
    if (!codeEditor) return;
    
    const code = codeEditor.getValue();
    const language = document.getElementById('editor-language').value;
    const output = document.getElementById('code-output');
    if (!output) return;
    
    try {
        let content = '';
        
        if (language === 'html') {
            // HTML direto
            content = code;
            
        } else if (language === 'css') {
            // CSS com preview
            content = `<!DOCTYPE html>
<html>
<head><style>${code}</style></head>
<body>
    <div style="padding:20px;">
        <h1>Preview CSS</h1>
        <p>Seu CSS foi aplicado a este exemplo.</p>
        <div class="box" style="padding:20px; background:#f0f0f0; border-radius:8px;">
            <h2>Exemplo</h2>
            <button>Botão</button>
        </div>
    </div>
</body>
</html>`;
            
        } else if (language === 'javascript') {
            // JavaScript com console
            content = `<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: Arial; padding: 20px; background: #1a1a2e; color: white; }
        #output { background: #16213e; padding: 15px; border-radius: 8px; border-left: 4px solid #e94560; }
        .log { color: #0ff; }
        .error { color: #ff6b6b; }
    </style>
</head>
<body>
    <h2>Output JavaScript</h2>
    <div id="output"></div>
    <script>
        const outputDiv = document.getElementById('output');
        const originalLog = console.log;
        const originalError = console.error;
        
        console.log = (...args) => {
            outputDiv.innerHTML += '<div class="log">📌 ' + args.join(' ') + '</div>';
            originalLog.apply(console, args);
        };
        
        console.error = (...args) => {
            outputDiv.innerHTML += '<div class="error">❌ ' + args.join(' ') + '</div>';
            originalError.apply(console, args);
        };
        
        try {
            ${code}
        } catch(e) {
            console.error('Erro: ' + e.message);
        }
    <\/script>
</body>
</html>`;
        }
        
        output.srcdoc = content;
        mostrarMensagem('✅ Código executado!', 'sucesso');
        
    } catch (error) {
        console.error('Erro:', error);
        mostrarMensagem('❌ Erro ao executar código', 'erro');
    }
}

function salvarCodigo() {
    if (!codeEditor) return;
    
    const code = codeEditor.getValue();
    const language = document.getElementById('editor-language').value;
    const ext = { 'html': 'html', 'css': 'css', 'javascript': 'js' }[language] || 'txt';
    const filename = `codemaster_${Date.now()}.${ext}`;
    
    const blob = new Blob([code], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
    
    mostrarMensagem('💾 Código salvo!', 'sucesso');
}

function resetarCodigo() {
    if (!codeEditor) return;
    
    codeEditor.setValue(`<!DOCTYPE html>
<html>
<head>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
        }
        h1 { text-align: center; }
        button {
            background: white;
            color: #667eea;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <h1>Olá, CodeMaster!</h1>
    <button onclick="alert('Funcionou!')">Clique aqui</button>
</body>
</html>`);
    
    mostrarMensagem('🔄 Editor resetado!', 'info');
}

function limparSaida() {
    const output = document.getElementById('code-output');
    if (output) {
        output.srcdoc = '<html><body style="background:#1a1a2e; color:white; padding:20px;">Saída limpa</body></html>';
        mostrarMensagem('🧹 Saída limpa!', 'info');
    }
}

// ===========================================
// TEMA
// ===========================================
function configurarTema() {
    const themeToggle = document.getElementById('theme-toggle');
    if (themeToggle) {
        themeToggle.addEventListener('click', toggleTema);
    }
    
    carregarTema();
}

function toggleTema() {
    const html = document.documentElement;
    const current = html.getAttribute('data-theme') || 'dark';
    const next = current === 'dark' ? 'light' : 'dark';
    
    html.setAttribute('data-theme', next);
    localStorage.setItem('codemaster_theme', next);
    AppState.theme = next;
    
    const sunIcon = document.querySelector('.theme-btn .bx-sun');
    const moonIcon = document.querySelector('.theme-btn .bx-moon');
    
    if (sunIcon && moonIcon) {
        sunIcon.style.display = next === 'light' ? 'inline-block' : 'none';
        moonIcon.style.display = next === 'dark' ? 'inline-block' : 'none';
    }
    
    if (codeEditor) {
        const editorTheme = next === 'light' ? 'eclipse' : 'dracula';
        codeEditor.setOption('theme', editorTheme);
        localStorage.setItem('editor_theme', editorTheme);
    }
    
    mostrarMensagem(`Tema ${next === 'dark' ? 'escuro' : 'claro'} ativado`, 'info');
}

function carregarTema() {
    const saved = localStorage.getItem('codemaster_theme') || 'dark';
    document.documentElement.setAttribute('data-theme', saved);
    AppState.theme = saved;
    
    const sunIcon = document.querySelector('.theme-btn .bx-sun');
    const moonIcon = document.querySelector('.theme-btn .bx-moon');
    
    if (sunIcon && moonIcon) {
        sunIcon.style.display = saved === 'light' ? 'inline-block' : 'none';
        moonIcon.style.display = saved === 'dark' ? 'inline-block' : 'none';
    }
}

// ===========================================
// FUNÇÕES AUXILIARES
// ===========================================
window.continuarComoConvidado = function() {
    document.getElementById('auth-modal').classList.add('active');
    mostrarMensagem('Faça login para acessar todas as funcionalidades!', 'info');
};

window.mudarAvatar = function() {
    const userName = document.getElementById('user-name').textContent;
    if (userName === 'Convidado') {
        mostrarMensagem('Faça login para alterar o avatar', 'erro');
        document.getElementById('auth-modal').classList.add('active');
        return;
    }
    mostrarMensagem('Funcionalidade de avatar em breve!', 'info');
};

window.fecharModal = function(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) modal.classList.remove('active');
};

window.togglePassword = function(inputId, icon) {
    const input = document.getElementById(inputId);
    if (input) {
        input.type = input.type === 'password' ? 'text' : 'password';
        icon.classList.toggle('bx-show');
        icon.classList.toggle('bx-hide');
    }
};

// ===========================================
// INICIALIZAÇÃO FINAL
// ===========================================
console.log('✅ CodeMaster Pro inicializado com sucesso!');
console.log('📊 Recursos de estudo: 75');
console.log('📊 Perguntas de quiz: 75');
console.log('📊 Conquistas: 21');
console.log('📊 Desafios: 2');
console.log('📊 Editor de código: 100% Funcional');
console.log('📊 Total aproximado de linhas: 5500');