<?php

function handleGetAction($acao, $conn) {

    switch ($acao) {

        case 'teste':
            echo json_encode([
                'sucesso' => true,
                'mensagem' => 'API OK',
                'php_version' => phpversion(),
                'server_time' => date('Y-m-d H:i:s'),
                'db' => $conn ? 'OK' : 'Erro'
            ]);
            return true;

        case 'debug':
            $utilizadores = $conn->query("SHOW TABLES LIKE 'utilizadores'");
            $quiz = $conn->query("SHOW TABLES LIKE 'quiz_historico'");
            $conquistas = $conn->query("SHOW TABLES LIKE 'conquistas'");

            echo json_encode([
                'sucesso' => true,
                'tabelas' => [
                    'utilizadores' => ($utilizadores && $utilizadores->num_rows > 0),
                    'quiz_historico' => ($quiz && $quiz->num_rows > 0),
                    'conquistas' => ($conquistas && $conquistas->num_rows > 0)
                ]
            ]);
            return true;

        case 'verificar_sessao':
            if (utilizadorLogado()) {
                $user = getUtilizadorAtual($conn);

                echo json_encode([
                    'sucesso' => true,
                    'logado' => true,
                    'dados' => $user
                ]);
            } else {
                echo json_encode([
                    'sucesso' => true,
                    'logado' => false
                ]);
            }
            return true;

        case 'leaderboard':
            $sql = "SELECT id, nome, pontos
                    FROM utilizadores
                    ORDER BY pontos DESC
                    LIMIT 10";

            $res = $conn->query($sql);

            $data = [];

            if ($res) {
                while ($row = $res->fetch_assoc()) {
                    $data[] = $row;
                }
            }

            echo json_encode([
                'sucesso' => true,
                'dados' => $data
            ]);
            return true;

       case 'get_historico':

    if (!utilizadorLogado()) {
        naoAutorizado();
    }

        $utilizador_id = $_SESSION['utilizador_id'];

        $sql = "SELECT id, linguagem, dificuldade, pontuacao, total_perguntas, tempo_gasto, data_jogo as data
            FROM quiz_historico
            WHERE usuario_id = ?
            ORDER BY id DESC
            LIMIT 20";

    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        die(json_encode(['erro' => $conn->error]));
    }

    $stmt->bind_param("i", $utilizador_id);

    if (!$stmt->execute()) {
        die(json_encode(['erro' => $stmt->error]));
    }

    $res = $stmt->get_result();

    $data = [];

    while ($row = $res->fetch_assoc()) {
        $data[] = $row;
    }

    echo json_encode([
        'sucesso' => true,
        'dados' => $data
    ]);

    return true;

        case 'get_historico_all':

            if (!utilizadorLogado()) {
                naoAutorizado();
            }

            $utilizador_id = $_SESSION['utilizador_id'];

            $sql = "SELECT id, linguagem, dificuldade, pontuacao, total_perguntas, tempo_gasto, data_jogo as data
                    FROM quiz_historico
                    WHERE usuario_id = ?
                    ORDER BY id DESC";

            $stmt = $conn->prepare($sql);
            if (!$stmt) {
                die(json_encode(['erro' => $conn->error]));
            }
            $stmt->bind_param("i", $utilizador_id);
            if (!$stmt->execute()) {
                die(json_encode(['erro' => $stmt->error]));
            }

            $res = $stmt->get_result();
            $data = [];
            while ($row = $res->fetch_assoc()) {
                $data[] = $row;
            }

            echo json_encode([
                'sucesso' => true,
                'dados' => $data
            ]);

            return true;

        case 'user_stats':
            if (!utilizadorLogado()) {
                naoAutorizado();
            }

            $utilizador_id = $_SESSION['utilizador_id'];

            $sql = "SELECT COUNT(*) as total_quizzes, COALESCE(SUM(tempo_gasto),0) as total_minutes FROM quiz_historico WHERE usuario_id = ?";
            $stmt = $conn->prepare($sql);
            if (!$stmt) {
                die(json_encode(['erro' => $conn->error]));
            }
            $stmt->bind_param('i', $utilizador_id);
            $stmt->execute();
            $res = $stmt->get_result();
            $row = $res->fetch_assoc();

            echo json_encode(['sucesso' => true, 'dados' => [
                'total_quizzes' => (int)($row['total_quizzes'] ?? 0),
                'total_minutes' => (int)($row['total_minutes'] ?? 0)
            ]]);

            return true;

        case 'get_progresso':

            if (!utilizadorLogado()) {
                naoAutorizado();
            }

            $utilizador_id = $_SESSION['utilizador_id'];

            // baseado no quiz_historico (não existe tabela progresso)
            $sql = "SELECT linguagem, COUNT(*) as total
                    FROM quiz_historico
                    WHERE utilizador_id = ?
                    GROUP BY linguagem";

            $stmt = $conn->prepare($sql);

            if (!$stmt) {
                die(json_encode(['erro' => $conn->error]));
            }

            $stmt->bind_param("i", $utilizador_id);

            if (!$stmt->execute()) {
                die(json_encode(['erro' => $stmt->error]));
            }

            $res = $stmt->get_result();

            $progresso = [
                'html' => 0,
                'css' => 0,
                'javascript' => 0,
                'python' => 0,
                'java' => 0
            ];

            while ($row = $res->fetch_assoc()) {
                $lang = strtolower($row['linguagem']);
                $progresso[$lang] = (int)$row['total'];
            }

            echo json_encode([
                'sucesso' => true,
                'dados' => $progresso
            ]);

            return true;

        case 'perfil':
            $user = getUtilizadorAtual($conn);

            echo json_encode([
                'sucesso' => true,
                'dados' => $user
            ]);
            return true;

        default:
            return false;
    }
}