<?php
// testar.php - Arquivo simples para testar a conexão com o banco de dados
// Acesse: http://localhost/codemaster/testar.php

require_once 'config/conexao.php';

header('Content-Type: text/html; charset=utf-8');
echo "<h1>Teste de Conexão - CodeMaster Pro (Modo Demo)</h1>";
echo "<p style='color: orange; font-weight: bold;'>⚠️ Sistema de autenticação DESABILITADO - Use phpMyAdmin para gerenciar usuários</p>";

try {
    // Testar conexão
    if ($conn->connect_error) {
        throw new Exception("Erro de conexão: " . $conn->connect_error);
    }

    echo "<p style='color: green;'>✅ Conexão com banco de dados estabelecida com sucesso!</p>";

    // Testar se as tabelas existem
    $tables = ['utilizadores', 'conquistas', 'quiz_historico', 'recursos_estudo'];
    echo "<h2>Verificação de Tabelas:</h2>";

    foreach ($tables as $table) {
        $result = $conn->query("SHOW TABLES LIKE '$table'");
        if ($result->num_rows > 0) {
            echo "<p style='color: green;'>✅ Tabela '$table' existe</p>";
        } else {
            echo "<p style='color: red;'>❌ Tabela '$table' não encontrada</p>";
        }
    }

    // Contar usuários
    $result = $conn->query("SELECT COUNT(*) as total FROM utilizadores");
    $row = $result->fetch_assoc();
    echo "<p>Total de usuários cadastrados: <strong>" . $row['total'] . "</strong></p>";
    echo "<p style='color: blue;'>💡 <strong>Modo Demo:</strong> Gerencie usuários via phpMyAdmin</p>";
    echo "<p><a href='http://localhost/phpmyadmin' target='_blank'>Abrir phpMyAdmin →</a></p>";

    // Testar API
    echo "<h2>Teste da API:</h2>";
    echo "<p><a href='api/api.php?acao=teste' target='_blank'>Testar API (ação: teste)</a></p>";
    echo "<p><a href='api/api.php?acao=leaderboard' target='_blank'>Ver Leaderboard</a></p>";

} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Erro: " . $e->getMessage() . "</p>";
}

echo "<hr>";
echo "<p><a href='public/'>← Voltar para a aplicação</a></p>";
?>