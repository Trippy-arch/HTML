# 📚 CodeMaster Pro - Manual do Utilizador

Bem-vindo ao **CodeMaster Pro**, a sua plataforma interativa de aprendizagem de programação!

---

## 📋 Índice

1. [Início Rápido](#início-rápido)
2. [Funcionalidades Principais](#funcionalidades-principais)
3. [Modos de Utilização](#modos-de-utilização)
4. [Sistema de Troféus](#sistema-de-troféus)
5. [Dicas e Boas Práticas](#dicas-e-boas-práticas)
6. [Resolução de Problemas](#resolução-de-problemas)

---

## 🚀 Início Rápido

### Como Aceder à Plataforma

1. Abra o seu navegador web (Chrome, Firefox, Edge, Safari)
2. Aceda a: `http://localhost/codemaster/`
3. A página principal carrega automaticamente

### Primeiro Passos

1. **Explore o Menu de Navegação** (canto superior esquerdo):
   - 📚 **Estudo** - Aprenda novos conteúdos
   - 🧪 **Testes** - Avalie os seus conhecimentos
   - 💻 **Prática** - Escreva e execute código
   - 📊 **Painel de Controlo** - Veja as suas estatísticas
   - ⏱️ **Desafio** - Competições cronometradas

2. **Selecione uma Linguagem**:
   - HTML5
   - CSS3
   - JavaScript
   - Python
   - Java

3. **Comece a Aprender!**

---

## 🎯 Funcionalidades Principais

### 1. Modo Estudo (📚)

Aceda a recursos educacionais organizados por linguagem de programação.

**Como Usar:**
- Selecione a linguagem que deseja aprender
- Leia os conteúdos educacionais
- Veja exemplos de código
- Compreenda os conceitos fundamentais

**Tipos de Recursos:**
- Guias teóricos
- Exemplos de código
- Explicações detalhadas
- Boas práticas

---

### 2. Modo Teste (🧪)

Teste os seus conhecimentos com testes interativos e ganhe pontos.

**Como Usar:**
1. Aceda a **Modo Teste** no menu
2. Selecione a dificuldade:
   - ⭐ **Fácil** (10 pontos por pergunta)
   - ⭐⭐ **Médio** (20 pontos por pergunta)
   - ⭐⭐⭐ **Difícil** (30 pontos por pergunta)
3. Selecione a linguagem
4. Responda às perguntas
5. Veja o resultado no final

**Pontuação:**
- Resposta correta: Ganha pontos
- Resposta errada: Sem penalização
- Conclusão de teste: Bónus de 50 pontos

---

### 3. Modo Prática (💻)

Escreva e execute código em tempo real com o editor integrado.

**Como Usar:**
1. Aceda a **Modo Prática**
2. Selecione a linguagem:
   - HTML
   - CSS
   - JavaScript
   - Python (simulado)
   - Java (simulado)
3. Escreva o seu código
4. Clique em **Executar** para ver o resultado
5. O resultado aparece no painel à direita

**Funcionalidades:**
- Colorfação de sintaxe
- Indentação automática
- Execução em tempo real
- Mensagens de erro claras

---

### 4. Painel de Controlo (📊)

Acompanhe o seu progresso e estatísticas de aprendizagem.

**Informações Disponíveis:**
- **Pontos Totais**: Soma de todos os pontos ganhos
- **Testes Completos**: Número de testes realizados
- **Minutos de Estudo**: Tempo total na plataforma
- **Dias Consecutivos**: Seqüência de dias com atividade
- **Troféus Desbloqueados**: Conquistas atingidas
- **Histórico Recente**: Últimas atividades

---

### 5. Modo Desafio (⏱️)

Participe em competições cronometradas e ganhe troféus especiais.

**Tipos de Desafio:**

**Quiz Rápido**
- 10 perguntas em 60 segundos
- Requer resposta rápida
- Pontos multiplicados por 1,5x

**Maratona**
- 15 perguntas sem tempo limite
- Foca na precisão
- Pontos multiplicados por 1,2x

**Como Participar:**
1. Aceda a **Modo Desafio**
2. Escolha o tipo de desafio
3. Selecione a linguagem
4. Clique em **Começar**
5. Responda as perguntas
6. Veja a sua classificação

---

## 🏆 Sistema de Troféus

Os troféus são conquistas desbloqueadas através de atividades na plataforma. Existem **21 troféus** distribuídos em 6 categorias:

### 📚 Testes (5 troféus)

| Troféu | Requisito | Pontos |
|--------|-----------|--------|
| 🧠 **Mestre dos Testes** | Completa 5 testes | 50 |
| 👑 **Lenda dos Testes** | Completa 25 testes | 250 |
| ✅ **Perfeição** | Acerta 100% num teste | 100 |
| ⚡ **Demónio da Velocidade** | Completa um teste cronometrado | 50 |
| 🏃 **Maratonista** | Completa 15 perguntas num teste | 75 |

### ⭐ Pontuação (4 troféus)

| Troféu | Requisito | Pontos |
|--------|-----------|--------|
| ⭐ **100 Pontos** | Acumula 100 pontos | 20 |
| ⭐⭐ **500 Pontos** | Acumula 500 pontos | 50 |
| 🏆 **1000 Pontos** | Acumula 1000 pontos | 100 |
| 🏆🏆 **5000 Pontos** | Acumula 5000 pontos | 500 |

### 🔥 Seqüência (3 troféus)

| Troféu | Requisito | Pontos |
|--------|-----------|--------|
| 🔥 **Semana de Fogo** | Mantém seqüência por 7 dias | 100 |
| 🔥🔥 **Mês Dedicado** | Mantém seqüência por 30 dias | 300 |
| 🔥🔥🔥 **Centenário** | Mantém seqüência por 100 dias | 1000 |

### 💻 Linguagens (5 troféus)

| Troféu | Requisito | Pontos |
|--------|-----------|--------|
| 🔷 **HTML Pro** | Completa 10 testes de HTML | 75 |
| 🟡 **CSS Pro** | Completa 10 testes de CSS | 75 |
| 🟨 **JavaScript Pro** | Completa 10 testes de JavaScript | 75 |
| 🐍 **Python Pro** | Completa 10 testes de Python | 75 |
| ☕ **Java Pro** | Completa 10 testes de Java | 75 |

### ✏️ Editor (2 troféus)

| Troféu | Requisito | Pontos |
|--------|-----------|--------|
| 💻 **Mestre do Código** | Executa 50 códigos no editor | 200 |
| 🐛 **Caçador de Bugs** | Corrige 10 erros no editor | 150 |

### 🤝 Social (1 troféu)

| Troféu | Requisito | Pontos |
|--------|-----------|--------|
| 📤 **Partilhador** | Partilha 5 resultados | 50 |

---

## 💡 Dicas e Boas Práticas

### Para Aprender Eficientemente

1. **Comece pelo Modo Estudo**
   - Leia os conteúdos teóricos
   - Compreenda os conceitos
   - Execute exemplos no editor

2. **Pratique Regularmente**
   - Use o Modo Prática diariamente
   - Escreva código todos os dias
   - Mantenha a sua seqüência

3. **Teste os Seus Conhecimentos**
   - Faça testes regularmente
   - Comece com dificuldade fácil
   - Suba a dificuldade gradualmente

4. **Acompanhe o Seu Progresso**
   - Veja o seu painel de controlo
   - Celebre os seus troféus
   - Defina objetivos pessoais

### Estratégias de Teste

- **Para o 100%**: Leia as respostas com cuidado, sem pressa
- **Para mais pontos**: Complete testes de dificuldade elevada
- **Para ganhar troféus**: Foque em categorias específicas
- **Para competir**: Participe no Modo Desafio

### Gerenciamento de Tempo

- Estude 30-60 minutos por dia
- Faça pausas a cada 25 minutos
- Revise o material aprendido
- Pratique código frequentemente

---

## 🔧 Resolução de Problemas

### O Editor de Código Não Funciona

**Solução:**
1. Verifique se o JavaScript está ativado no navegador
2. Recarregue a página (F5 ou Ctrl+R)
3. Tente outro navegador
4. Limpe a cache do navegador

### Os Testes Não Carregam

**Solução:**
1. Verifique a sua ligação de internet
2. Aguarde alguns segundos
3. Recarregue a página
4. Contacte o administrador se o problema persistir

### Não Consigo Ver os Meus Troféus

**Solução:**
1. Aceda ao Painel de Controlo
2. Clique em **Troféus**
3. Os troféus desbloqueados aparecerão lá
4. Filtro por categoria se necessário

### A Página Está Lenta

**Solução:**
1. Feche outros separadores
2. Desative as extensões do navegador
3. Limpe a cache
4. Use um navegador mais recente

### Não Consigo Aceder à Plataforma

**Solução:**
1. Verifique se está a usar o URL correto
2. Certifique-se que o servidor está a funcionar
3. Tente `http://localhost/codemaster/` ou `http://127.0.0.1/codemaster/`
4. Contacte o administrador do sistema

---

## 📞 Suporte e Ajuda

Se tiver dúvidas ou problemas:

1. **Consulte a Documentação**: Veja os ficheiros `README.md` e `TUTORIAL_SETUP.txt`
2. **Contacte o Administrador**: Para problemas técnicos
3. **Releia o Manual**: Verifique se a sua dúvida está respondida aqui

---

## 🎓 Objetivos de Aprendizagem

### Nível Iniciante
- [ ] Completa 5 testes
- [ ] Acumula 100 pontos
- [ ] Desbloquia 1 troféu
- [ ] Pratica em 3 linguagens

### Nível Intermédio
- [ ] Completa 15 testes
- [ ] Acumula 500 pontos
- [ ] Desbloquia 5 troféus
- [ ] Pratica em todas as linguagens

### Nível Avançado
- [ ] Completa 25 testes
- [ ] Acumula 5000 pontos
- [ ] Desbloquia 15+ troféus
- [ ] Atinge 100 dias de seqüência

---

## 🌟 Conclusão

Parabéns por escolher CodeMaster Pro para a sua jornada de aprendizagem de programação!

**Lembre-se:**
- A consistência é mais importante que a velocidade
- Erros são oportunidades de aprender
- Cada troféu é um marco no seu progresso
- O seu dedicação irá pagar-se

**Boa sorte e bom estudo! 🚀**

---

*Última atualização: 15 de Junho de 2026*
*Manual do Utilizador - CodeMaster Pro v2.0*
