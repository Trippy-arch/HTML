<?php
// utils.php - helpers para respostas JSON e CORS

function jsonResponse($data, $code = 200) {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function allowCORS() {
    if (isset($_SERVER['HTTP_ORIGIN'])) {
        // Echo origin to allow credentials; in production replace with a whitelist
        header('Access-Control-Allow-Origin: ' . $_SERVER['HTTP_ORIGIN']);
        header('Access-Control-Allow-Credentials: true');
    } else {
        header('Access-Control-Allow-Origin: *');
    }
    header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, X-Requested-With');
}

function logError($message, $context = []) {
    $dir = __DIR__ . '/storage/logs';
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }

    $file = $dir . '/server_errors.log';
    $time = date('Y-m-d H:i:s');
    $entry = "[{$time}] " . $message;
    if (!empty($context)) {
        $entry .= ' | ' . json_encode($context, JSON_UNESCAPED_UNICODE);
    }
    $entry .= PHP_EOL;
    @file_put_contents($file, $entry, FILE_APPEND | LOCK_EX);
}


?>