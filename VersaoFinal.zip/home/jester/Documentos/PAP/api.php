<?php
require_once __DIR__ . '/utils.php';
allowCORS();

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once __DIR__ . '/conexao.php';

// Em produção, desative display_errors e use logs.
error_reporting(E_ALL);
ini_set('display_errors', 0);

// Registro de handlers para erros e exceções — envia 500 e grava log
set_error_handler(function($severity, $message, $file, $line) {
    throw new ErrorException($message, 0, $severity, $file, $line);
});

set_exception_handler(function($e) {
    logError($e->getMessage(), ['file' => $e->getFile(), 'line' => $e->getLine()]);
    if (!headers_sent()) {
        jsonResponse(['sucesso' => false, 'mensagem' => 'Erro interno no servidor'], 500);
    }
});

register_shutdown_function(function() {
    $err = error_get_last();
    if ($err && in_array($err['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
        logError('Shutdown fatal: ' . $err['message'], $err);
        if (!headers_sent()) {
            jsonResponse(['sucesso' => false, 'mensagem' => 'Erro fatal no servidor'], 500);
        }
    }
});

$acao = $_GET['acao'] ?? '';

$acoes_publicas = ['login', 'registar', 'teste', 'debug', 'logout'];

require_once __DIR__ . '/get_actions.php';
require_once __DIR__ . '/set_actions.php';

if (!in_array($acao, $acoes_publicas) && !utilizadorLogado()) {
    naoAutorizado();
}

if (handleGetAction($acao, $conn) || handleSetAction($acao, $conn)) {
    $conn->close();
    exit();
}

jsonResponse([
    'sucesso' => false,
    'mensagem' => 'Ação não encontrada: ' . $acao
], 404);

$conn->close();
?>