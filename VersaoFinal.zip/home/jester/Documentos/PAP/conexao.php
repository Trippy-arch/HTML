<?php
// conexao.php

$host = 'localhost';
$user = 'root';
$password = '';
$database = 'codemaster_db';

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode([
        'sucesso' => false,
        'mensagem' => 'Erro de conexão: ' . $conn->connect_error
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$conn->set_charset("utf8mb4");

// Sessão
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Verificar login
function utilizadorLogado() {
    return isset($_SESSION['utilizador_id']);
}

// Bloqueio
function naoAutorizado() {
    http_response_code(401);
    echo json_encode([
        'sucesso' => false,
        'mensagem' => 'Não autorizado'
    ]);
    exit;
}

// Utilizador atual
function getUtilizadorAtual($conn) {
    if (!utilizadorLogado()) return null;

    $id = $_SESSION['utilizador_id'];

    $sql = "SELECT id, nome, email, pontos, tipo, bio, streak, ultimo_login 
            FROM utilizadores WHERE id = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();

    $result = $stmt->get_result();
    return $result->fetch_assoc();
}
?>