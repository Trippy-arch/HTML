-- CodeMaster Pro - Script de Setup do Banco de Dados
-- Execute este script no phpMyAdmin para configurar o banco
-- MODO DEMO: Sistema de autenticação desabilitado na interface

-- Criar banco de dados (se não existir)
CREATE DATABASE IF NOT EXISTS codemaster_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE codemaster_db;

-- Tabela de usuários
CREATE TABLE IF NOT EXISTS utilizadores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    senha VARCHAR(255) NOT NULL,
    pontos INT DEFAULT 0,
    tipo ENUM('aluno', 'admin') DEFAULT 'aluno',
    bio TEXT,
    streak INT DEFAULT 0,
    ultimo_login DATETIME DEFAULT CURRENT_TIMESTAMP,
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    data_atualizacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabela de conquistas
CREATE TABLE IF NOT EXISTS conquistas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(100) NOT NULL,
    descricao TEXT,
    icone VARCHAR(50),
    pontos_requeridos INT DEFAULT 0,
    categoria VARCHAR(50)
);

-- Tabela de conquistas desbloqueadas pelos usuários
CREATE TABLE IF NOT EXISTS utilizador_conquistas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    utilizador_id INT NOT NULL,
    conquista_id INT NOT NULL,
    data_desbloqueada TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (utilizador_id) REFERENCES utilizadores(id) ON DELETE CASCADE,
    FOREIGN KEY (conquista_id) REFERENCES conquistas(id) ON DELETE CASCADE,
    UNIQUE KEY unique_utilizador_conquista (utilizador_id, conquista_id)
);

-- Tabela de histórico de quizzes
CREATE TABLE IF NOT EXISTS quiz_historico (
    id INT AUTO_INCREMENT PRIMARY KEY,
    utilizador_id INT NOT NULL,
    linguagem VARCHAR(50) NOT NULL,
    dificuldade VARCHAR(20) NOT NULL,
    pontuacao INT NOT NULL,
    total_perguntas INT NOT NULL,
    tempo_gasto INT, -- em segundos
    data_jogo TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (utilizador_id) REFERENCES utilizadores(id) ON DELETE CASCADE
);

-- Tabela de recursos de estudo
CREATE TABLE IF NOT EXISTS recursos_estudo (
    id INT AUTO_INCREMENT PRIMARY KEY,
    linguagem VARCHAR(50) NOT NULL,
    titulo VARCHAR(200) NOT NULL,
    descricao TEXT,
    tipo ENUM('artigo', 'video', 'exercicio', 'tutorial') DEFAULT 'artigo',
    url VARCHAR(500),
    dificuldade VARCHAR(20) DEFAULT 'iniciante',
    ordem INT DEFAULT 0,
    ativo BOOLEAN DEFAULT TRUE
);

-- Tabela de execuções de código
CREATE TABLE IF NOT EXISTS codigo_execucoes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    utilizador_id INT,
    linguagem VARCHAR(50) NOT NULL,
    codigo TEXT,
    resultado TEXT,
    sucesso BOOLEAN DEFAULT FALSE,
    data_execucao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (utilizador_id) REFERENCES utilizadores(id) ON DELETE SET NULL
);

-- Inserir algumas conquistas básicas
INSERT INTO conquistas (titulo, descricao, icone, pontos_requeridos, categoria) VALUES
('Primeiro Login', 'Fez login pela primeira vez', 'bx-log-in', 0, 'geral'),
('HTML Básico', 'Completou todos os recursos de HTML', 'bx-code-alt', 50, 'aprendizado'),
('CSS Básico', 'Completou todos os recursos de CSS', 'bx-palette', 50, 'aprendizado'),
('JavaScript Básico', 'Completou todos os recursos de JavaScript', 'bx-code-curly', 50, 'aprendizado'),
('Sequência de 7 Dias', 'Estudou por 7 dias consecutivos', 'bx-flame', 70, 'dedicacao'),
('Mestre do Quiz', 'Pontuação perfeita em um quiz difícil', 'bx-star', 100, 'quiz'),
('Programador Iniciante', 'Executou 10 códigos no editor', 'bx-terminal', 25, 'pratica');

-- Inserir alguns recursos de estudo básicos
INSERT INTO recursos_estudo (linguagem, titulo, descricao, tipo, url, dificuldade, ordem) VALUES
('html', 'Introdução ao HTML', 'Aprenda os conceitos básicos de HTML5', 'tutorial', '#', 'iniciante', 1),
('html', 'Estrutura de uma Página', 'Entenda como estruturar uma página HTML', 'artigo', '#', 'iniciante', 2),
('html', 'Elementos e Atributos', 'Conheça os principais elementos HTML', 'exercicio', '#', 'iniciante', 3),
('html', 'Formulários HTML', 'Crie formulários interativos', 'tutorial', '#', 'intermediario', 4),
('css', 'Introdução ao CSS', 'Estilize suas páginas web', 'tutorial', '#', 'iniciante', 1),
('css', 'Seletores CSS', 'Aprenda a selecionar elementos', 'artigo', '#', 'iniciante', 2),
('css', 'Layout com Flexbox', 'Crie layouts modernos', 'tutorial', '#', 'intermediario', 3),
('javascript', 'Sintaxe Básica', 'Fundamentos da linguagem JavaScript', 'tutorial', '#', 'iniciante', 1),
('javascript', 'DOM Manipulation', 'Interaja com elementos da página', 'exercicio', '#', 'intermediario', 2),
('javascript', 'Eventos', 'Trate eventos do usuário', 'tutorial', '#', 'intermediario', 3);

-- Criar usuário admin de exemplo (senha: admin123)
INSERT INTO utilizadores (nome, email, senha, tipo) VALUES
('Administrador', 'admin@codemaster.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');

-- Índices para melhor performance
CREATE INDEX idx_utilizador_pontos ON utilizadores(pontos);
CREATE INDEX idx_quiz_utilizador ON quiz_historico(utilizador_id);
CREATE INDEX idx_conquista_utilizador ON utilizador_conquistas(utilizador_id);
CREATE INDEX idx_recurso_linguagem ON recursos_estudo(linguagem, ordem);