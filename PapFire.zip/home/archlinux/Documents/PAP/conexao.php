<?php
// conexao.php
$host = 'localhost';
$user = 'root'; // Altere para seu usuário do MySQL
$password = ''; // Altere para sua senha do MySQL
$database = 'codemaster_db';

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die(json_encode([
        'sucesso' => false,
        'mensagem' => 'Erro de conexão: ' . $conn->connect_error
    ]));
}

// Garantir que a codificação está correta
$conn->set_charset("utf8mb4");
?>