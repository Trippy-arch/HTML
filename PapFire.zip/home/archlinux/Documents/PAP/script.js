// ===========================================
// CODEMASTER PRO - JAVASCRIPT COMPLETO
// Versão Final com Conquistas Unificadas
// ===========================================

console.log('%c🚀 CodeMaster Pro - Inicializando...', 'color: #bd93f9; font-size: 16px; font-weight: bold;');

// ===========================================
// CONFIGURAÇÕES
// ===========================================
const API_URL = 'api.php';

// ===========================================
// DADOS DOS RECURSOS DE ESTUDO
// ===========================================
const RESOURCES = {
    html: [
        { title: "MDN Web Docs - HTML", url: "https://developer.mozilla.org/pt-BR/docs/Web/HTML" },
        { title: "W3Schools - HTML Tutorial", url: "https://www.w3schools.com/html/" },
        { title: "HTML.com Tutorial", url: "https://html.com/" },
        { title: "FreeCodeCamp - HTML", url: "https://www.freecodecamp.org/learn/responsive-web-design/" }
    ],
    css: [
        { title: "MDN Web Docs - CSS", url: "https://developer.mozilla.org/pt-BR/docs/Web/CSS" },
        { title: "W3Schools - CSS Tutorial", url: "https://www.w3schools.com/css/" },
        { title: "CSS-Tricks", url: "https://css-tricks.com/" },
        { title: "FreeCodeCamp - CSS", url: "https://www.freecodecamp.org/learn/responsive-web-design/" }
    ],
    javascript: [
        { title: "MDN Web Docs - JavaScript", url: "https://developer.mozilla.org/pt-BR/docs/Web/JavaScript" },
        { title: "W3Schools - JavaScript Tutorial", url: "https://www.w3schools.com/js/" },
        { title: "JavaScript.info", url: "https://javascript.info/" },
        { title: "FreeCodeCamp - JavaScript", url: "https://www.freecodecamp.org/learn/javascript-algorithms-and-data-structures/" }
    ],
    python: [
        { title: "Python.org Documentation", url: "https://docs.python.org/3/" },
        { title: "W3Schools - Python Tutorial", url: "https://www.w3schools.com/python/" },
        { title: "Real Python", url: "https://realpython.com/" },
        { title: "FreeCodeCamp - Python", url: "https://www.freecodecamp.org/learn/scientific-computing-with-python/" }
    ],
    java: [
        { title: "Oracle Java Documentation", url: "https://docs.oracle.com/javase/tutorial/" },
        { title: "W3Schools - Java Tutorial", url: "https://www.w3schools.com/java/" },
        { title: "JavaTpoint", url: "https://www.javatpoint.com/java-tutorial" },
        { title: "GeeksforGeeks - Java", url: "https://www.geeksforgeeks.org/java/" }
    ]
};

// ===========================================
// PERGUNTAS DO QUIZ
// ===========================================
const QUESTIONS = {
    html: {
        easy: [
            { question: "O que significa HTML?", options: ["HyperText Markup Language", "HighTech Modern Language", "HyperTransfer Markup Language", "Home Tool Markup Language"], correct: 0, points: 10 },
            { question: "Qual tag é usada para criar um link?", options: ["<link>", "<a>", "<href>", "<url>"], correct: 1, points: 10 },
            { question: "Qual tag define o título principal?", options: ["<h1>", "<head>", "<title>", "<header>"], correct: 0, points: 10 },
            { question: "Qual atributo é usado para imagens?", options: ["src", "href", "link", "url"], correct: 0, points: 10 },
            { question: "Qual tag cria lista não ordenada?", options: ["<ul>", "<ol>", "<li>", "<list>"], correct: 0, points: 10 }
        ],
        medium: [
            { question: "Qual atributo especifica uma classe CSS?", options: ["class", "css", "style", "id"], correct: 0, points: 20 },
            { question: "Qual elemento é para conteúdo principal?", options: ["<main>", "<body>", "<content>", "<section>"], correct: 0, points: 20 },
            { question: "Qual tag é semanticamente correta para navegação?", options: ["<nav>", "<menu>", "<navigation>", "<navbar>"], correct: 0, points: 20 },
            { question: "Qual elemento é usado para rodapé?", options: ["<footer>", "<bottom>", "<end>", "<foot>"], correct: 0, points: 20 },
            { question: "Qual meta tag é importante para responsividade?", options: ["viewport", "responsive", "mobile", "scale"], correct: 0, points: 20 }
        ],
        hard: [
            { question: "Qual elemento HTML5 é para conteúdo independente?", options: ["<article>", "<section>", "<aside>", "<div>"], correct: 0, points: 30 },
            { question: "Diferença entre <div> e <span>?", options: ["<div> é inline, <span> é block", "<div> é block, <span> é inline", "Ambos são block", "Ambos são inline"], correct: 1, points: 30 },
            { question: "Qual atributo melhora acessibilidade em imagens?", options: ["alt", "title", "aria-label", "description"], correct: 0, points: 30 },
            { question: "O que é Web Semântica?", options: ["Usar elementos que descrevem significado", "Adicionar semântica CSS", "Usar JavaScript semântico", "Implementar SEO"], correct: 0, points: 30 },
            { question: "Qual elemento é melhor para conteúdo relacionado?", options: ["<aside>", "<section>", "<div>", "<related>"], correct: 0, points: 30 }
        ]
    },
    css: {
        easy: [
            { question: "O que significa CSS?", options: ["Cascading Style Sheets", "Computer Style Sheets", "Creative Style System", "Colorful Style Sheets"], correct: 0, points: 10 },
            { question: "Qual propriedade muda cor do texto?", options: ["color", "text-color", "font-color", "text-style"], correct: 0, points: 10 },
            { question: "Como comentar em CSS?", options: ["/* comentário */", "// comentário", "<!-- comentário -->", "# comentário"], correct: 0, points: 10 },
            { question: "Qual propriedade controla o fundo?", options: ["background", "bg-color", "color-background", "background-color"], correct: 3, points: 10 },
            { question: "Como centralizar texto?", options: ["text-align: center;", "align: center;", "text-center: true;", "center: text;"], correct: 0, points: 10 }
        ],
        medium: [
            { question: "Qual propriedade cria espaço ENTRE elementos?", options: ["margin", "padding", "spacing", "gap"], correct: 0, points: 20 },
            { question: "Qual propriedade cria espaço DENTRO de elementos?", options: ["padding", "margin", "spacing", "gap"], correct: 0, points: 20 },
            { question: "Como centralizar um elemento horizontalmente?", options: ["margin: 0 auto;", "text-align: center;", "align: center;", "position: center;"], correct: 0, points: 20 },
            { question: "O que faz z-index?", options: ["Controla ordem de empilhamento", "Controla tamanho", "Controla transparência", "Controla rotação"], correct: 0, points: 20 },
            { question: "Qual unidade é relativa ao elemento pai?", options: ["em", "rem", "px", "vw"], correct: 0, points: 20 }
        ],
        hard: [
            { question: "Diferença entre display:none e visibility:hidden?", options: ["display:none remove do fluxo, visibility:hidden apenas esconde", "Ambos removem do fluxo", "visibility:hidden remove do fluxo", "Ambos apenas escondem"], correct: 0, points: 30 },
            { question: "O que é Flexbox?", options: ["Método de layout unidimensional", "Método de layout bidimensional", "Tipo de display para imagens", "Propriedade para flexibilidade"], correct: 0, points: 30 },
            { question: "O que é CSS Grid?", options: ["Método de layout bidimensional", "Método de layout unidimensional", "Framework CSS", "Sistema de templates"], correct: 0, points: 30 },
            { question: "O que faz @media query?", options: ["Aplica estilos baseado em condições", "Importa media files", "Cria animações", "Define variáveis CSS"], correct: 0, points: 30 },
            { question: "Qual pseudo-classe seleciona o primeiro filho?", options: [":first-child", ":first", ":first-of-type", ":nth-child(1)"], correct: 0, points: 30 }
        ]
    },
    javascript: {
        easy: [
            { question: "Como declarar variável em JavaScript?", options: ["let x;", "variable x;", "v x;", "declare x;"], correct: 0, points: 10 },
            { question: "Como imprimir no console?", options: ["console.log()", "print()", "log()", "display()"], correct: 0, points: 10 },
            { question: "Como criar uma função?", options: ["function myFunc() {}", "func myFunc() {}", "def myFunc() {}", "method myFunc() {}"], correct: 0, points: 10 },
            { question: "Qual operador verifica igualdade (valor e tipo)?", options: ["===", "==", "=", "!="], correct: 0, points: 10 },
            { question: "Qual operador verifica igualdade (apenas valor)?", options: ["==", "===", "=", "!="], correct: 0, points: 10 }
        ],
        medium: [
            { question: "O que é uma função de callback?", options: ["Função passada como argumento", "Função que retorna valor", "Função que chama a si mesma", "Função anônima"], correct: 0, points: 20 },
            { question: "O que é JSON?", options: ["JavaScript Object Notation", "JavaScript Online Network", "Java Standard Object Notation", "JavaScript Organized Nodes"], correct: 0, points: 20 },
            { question: "Como converter objeto para JSON?", options: ["JSON.stringify()", "JSON.parse()", "obj.toJSON()", "JSON.encode()"], correct: 0, points: 20 },
            { question: "Como converter JSON para objeto?", options: ["JSON.parse()", "JSON.stringify()", "JSON.toObj()", "JSON.decode()"], correct: 0, points: 20 },
            { question: "O que é DOM?", options: ["Document Object Model", "Data Object Management", "Digital Object Model", "Document Online Model"], correct: 0, points: 20 }
        ],
        hard: [
            { question: "O que é hoisting?", options: ["Elevação de variáveis/funções ao topo", "Técnica de otimização", "Tipo de loop", "Método de ordenação"], correct: 0, points: 30 },
            { question: "Diferença entre == e ===?", options: ["== compara valor, === compara valor e tipo", "== compara tipo, === compara valor", "== é mais rápido", "=== é mais rápido"], correct: 0, points: 30 },
            { question: "O que é closure?", options: ["Função que acessa escopo externo", "Função anônima", "Função autoexecutável", "Função assíncrona"], correct: 0, points: 30 },
            { question: "O que é this em JavaScript?", options: ["Refere-se ao contexto de execução", "Refere-se à função atual", "Refere-se ao objeto global", "Refere-se ao protótipo"], correct: 0, points: 30 },
            { question: "O que é protótipo (prototype)?", options: ["Mecanismo de herança", "Objeto base", "Função construtora", "Classe"], correct: 0, points: 30 }
        ]
    },
    python: {
        easy: [
            { question: "Como imprimir texto em Python?", options: ["print()", "console.log()", "echo()", "System.out.println()"], correct: 0, points: 10 },
            { question: "Como declarar variável em Python?", options: ["x = 5", "var x = 5", "let x = 5", "int x = 5"], correct: 0, points: 10 },
            { question: "Operador para potência?", options: ["**", "^", "pow()", "//"], correct: 0, points: 10 },
            { question: "Como criar uma lista?", options: ["[]", "{}", "()", "<>"], correct: 0, points: 10 },
            { question: "Como criar um comentário?", options: ["# comentário", "// comentário", "/* comentário */", "<!-- comentário -->"], correct: 0, points: 10 }
        ],
        medium: [
            { question: "O que é uma lista?", options: ["Coleção ordenada e mutável", "Coleção não ordenada", "Coleção imutável", "Estrutura chave-valor"], correct: 0, points: 20 },
            { question: "O que é uma tupla?", options: ["Coleção ordenada e imutável", "Coleção mutável", "Coleção não ordenada", "Estrutura chave-valor"], correct: 0, points: 20 },
            { question: "O que é um dicionário?", options: ["Estrutura chave-valor", "Lista ordenada", "Conjunto não ordenado", "Array multidimensional"], correct: 0, points: 20 },
            { question: "Como adicionar item à lista?", options: ["append()", "add()", "push()", "insert()"], correct: 0, points: 20 },
            { question: "Como remover item da lista?", options: ["remove()", "delete()", "pop()", "del()"], correct: 0, points: 20 }
        ],
        hard: [
            { question: "O que é um decorador?", options: ["Função que modifica outra função", "Tipo de loop", "Método de formatação", "Classe especial"], correct: 0, points: 30 },
            { question: "O que é list comprehension?", options: ["Forma concisa de criar listas", "Método de filtragem", "Tipo de loop", "Estrutura de dados"], correct: 0, points: 30 },
            { question: "O que é o GIL?", options: ["Global Interpreter Lock", "General Interface Layer", "Global Import Library", "General Input Loader"], correct: 0, points: 30 },
            { question: "O que é lambda?", options: ["Função anônima", "Expressão", "Tipo de dado", "Operador"], correct: 0, points: 30 },
            { question: "O que é orientação a objetos?", options: ["Paradigma com classes/objetos", "Programação", "Design", "Estrutura"], correct: 0, points: 30 }
        ]
    },
    java: {
        easy: [
            { question: "Como imprimir texto em Java?", options: ["System.out.println()", "print()", "console.log()", "echo()"], correct: 0, points: 10 },
            { question: "Como declarar variável inteira?", options: ["int x = 5;", "integer x = 5;", "Int x = 5;", "var x = 5;"], correct: 0, points: 10 },
            { question: "Palavra-chave para classe?", options: ["class", "Class", "type", "struct"], correct: 0, points: 10 },
            { question: "Qual o método principal?", options: ["public static void main(String[] args)", "main()", "public void main()", "static void main()"], correct: 0, points: 10 },
            { question: "Como criar um array?", options: ["int[] array = new int[10];", "int array[];", "new int[10];", "array int[];"], correct: 0, points: 10 }
        ],
        medium: [
            { question: "O que é uma classe?", options: ["Modelo para criar objetos", "Tipo de variável", "Método especial", "Estrutura de dados"], correct: 0, points: 20 },
            { question: "O que é herança?", options: ["extends", "inherits", "implements", "derives"], correct: 0, points: 20 },
            { question: "O que é um construtor?", options: ["Método que inicializa objetos", "Tipo de variável", "Classe abstrata", "Interface"], correct: 0, points: 20 },
            { question: "O que é encapsulamento?", options: ["Ocultar dados com private", "Encapsular", "Proteger", "Esconder"], correct: 0, points: 20 },
            { question: "O que é modificador private?", options: ["Acesso apenas na classe", "Acesso em qualquer lugar", "Acesso no pacote", "Acesso na subclasse"], correct: 0, points: 20 }
        ],
        hard: [
            { question: "O que é polimorfismo?", options: ["Métodos com mesmo nome em classes diferentes", "Herança múltipla", "Encapsulamento", "Sobrecarga de operadores"], correct: 0, points: 30 },
            { question: "O que são interfaces?", options: ["Contrato que classes implementam", "Classes abstratas", "Métodos estáticos", "Construtores"], correct: 0, points: 30 },
            { question: "O que é classe abstrata?", options: ["Classe que não pode ser instanciada", "Classe abstrata", "Classe base", "Classe pai"], correct: 0, points: 30 },
            { question: "O que é sobrescrita (override)?", options: ["Reescrever método da superclasse", "Sobrescrever", "Override", "Redefinir"], correct: 0, points: 30 },
            { question: "O que é sobrecarga (overload)?", options: ["Métodos com mesmo nome e parâmetros diferentes", "Sobrecarregar", "Overload", "Múltiplos métodos"], correct: 0, points: 30 }
        ]
    }
};

// ===========================================
// DADOS DE CONQUISTAS (Versão Unificada)
// ===========================================
const ACHIEVEMENTS = [
    { id: 'first_quiz', nome: 'Primeiro Quiz', descricao: 'Complete seu primeiro quiz', icone: 'bx-flag', pontos: 10 },
    { id: 'quiz_master', nome: 'Mestre dos Quizzes', descricao: 'Complete 5 quizzes', icone: 'bx-brain', pontos: 50 },
    { id: 'points_100', nome: '100 Pontos', descricao: 'Acumule 100 pontos', icone: 'bx-star', pontos: 20 },
    { id: 'points_500', nome: '500 Pontos', descricao: 'Acumule 500 pontos', icone: 'bx-star', pontos: 50 },
    { id: 'streak_7', nome: 'Semana de Fogo', descricao: 'Mantenha streak por 7 dias', icone: 'bx-flame', pontos: 100 },
    { id: 'streak_30', nome: 'Mês Dedicado', descricao: 'Mantenha streak por 30 dias', icone: 'bx-hot', pontos: 300 },
    { id: 'html_pro', nome: 'HTML Pro', descricao: 'Complete 10 quizzes de HTML', icone: 'bxl-html5', pontos: 75 },
    { id: 'css_pro', nome: 'CSS Pro', descricao: 'Complete 10 quizzes de CSS', icone: 'bxl-css3', pontos: 75 },
    { id: 'js_pro', nome: 'JavaScript Pro', descricao: 'Complete 10 quizzes de JavaScript', icone: 'bxl-javascript', pontos: 75 },
    { id: 'python_pro', nome: 'Python Pro', descricao: 'Complete 10 quizzes de Python', icone: 'bxl-python', pontos: 75 },
    { id: 'java_pro', nome: 'Java Pro', descricao: 'Complete 10 quizzes de Java', icone: 'bxl-java', pontos: 75 },
    { id: 'perfect_score', nome: 'Perfeição', descricao: 'Acerte 100% em um quiz', icone: 'bx-check-double', pontos: 100 },
    { id: 'speed_demon', nome: 'Demônio da Velocidade', descricao: 'Complete um quiz cronometrado', icone: 'bx-timer', pontos: 50 },
    { id: 'marathon', nome: 'Maratonista', descricao: 'Complete 15 perguntas em um quiz', icone: 'bx-run', pontos: 75 }
];

// ===========================================
// SISTEMA DE UTILIZADOR
// ===========================================
const UserSystem = {
    currentUser: {
        id: 'guest',
        nome: 'Convidado',
        email: '',
        pontos: 0,
        quizzes: 0,
        streak: 0,
        bio: 'Aprendiz de programação',
        nivel: 1,
        xp: 0,
        progresso: { html: 0, css: 0, javascript: 0, python: 0, java: 0 },
        conquistas: [],
        historico: []
    },

    async init() {
        await this.checkLoginStatus();
        this.setupEventListeners();
        this.loadTheme();
        this.updateUI();
    },

    async checkLoginStatus() {
        const saved = localStorage.getItem('codemaster_user');
        if (saved) {
            try {
                this.currentUser = JSON.parse(saved);
                if (this.currentUser.id !== 'guest') {
                    await this.loadUserProgress();
                }
            } catch (e) {
                console.error('Erro ao carregar utilizador:', e);
            }
        }
    },

    async loadUserProgress() {
        if (this.currentUser.id === 'guest') return;
        
        try {
            // Carregar histórico
            const historyRes = await fetch(`${API_URL}?acao=historico&user_id=${this.currentUser.id}`);
            const historyData = await historyRes.json();
            if (historyData.sucesso) {
                this.currentUser.historico = historyData.dados || [];
                this.currentUser.quizzes = this.currentUser.historico.length;
                this.currentUser.pontos = this.currentUser.historico.reduce((sum, q) => sum + q.pontuacao, 0);
            }
            
            // Carregar progresso
            const progRes = await fetch(`${API_URL}?acao=progresso&user_id=${this.currentUser.id}`);
            const progData = await progRes.json();
            if (progData.sucesso && progData.dados) {
                progData.dados.forEach(p => {
                    this.currentUser.progresso[p.linguagem] = p.porcentagem;
                });
            }
            
            // Calcular nível
            this.currentUser.nivel = Math.floor(this.currentUser.pontos / 100) + 1;
            this.currentUser.xp = this.currentUser.pontos % 100;
            
            localStorage.setItem('codemaster_user', JSON.stringify(this.currentUser));
        } catch (error) {
            console.error('Erro ao carregar progresso:', error);
        }
    },

    async login(email, password) {
        try {
            const formData = new FormData();
            formData.append('email', email);
            formData.append('senha', password);

            const response = await fetch(`${API_URL}?acao=login`, {
                method: 'POST',
                body: formData
            });

            const data = await response.json();

            if (data.sucesso) {
                this.currentUser = {
                    id: data.dados.id,
                    nome: data.dados.nome,
                    email: data.dados.email,
                    pontos: parseInt(data.dados.pontos) || 0,
                    quizzes: 0,
                    streak: parseInt(data.dados.streak) || 0,
                    bio: data.dados.bio || 'Aprendiz de programação',
                    nivel: 1,
                    xp: 0,
                    progresso: { html: 0, css: 0, javascript: 0, python: 0, java: 0 },
                    conquistas: [],
                    historico: []
                };

                await this.loadUserProgress();
                this.checkAchievements();
                this.updateUI();
                this.showNotification(`Bem-vindo, ${this.currentUser.nome}!`, 'success');
                this.hideAuthModal();
                return true;
            } else {
                this.showNotification(data.mensagem || 'Erro no login', 'error');
                return false;
            }
        } catch (error) {
            console.error('Erro no login:', error);
            this.showNotification('Erro de ligação ao servidor', 'error');
            return false;
        }
    },

    async register(nome, email, senha) {
        try {
            const formData = new FormData();
            formData.append('nome', nome);
            formData.append('email', email);
            formData.append('senha', senha);

            const response = await fetch(`${API_URL}?acao=registar`, {
                method: 'POST',
                body: formData
            });

            const data = await response.json();

            if (data.sucesso) {
                this.showNotification('Registo realizado com sucesso! Faça login.', 'success');
                this.switchAuthTab('login');
                return true;
            } else {
                this.showNotification(data.mensagem || 'Erro no registo', 'error');
                return false;
            }
        } catch (error) {
            console.error('Erro no registo:', error);
            this.showNotification('Erro de ligação ao servidor', 'error');
            return false;
        }
    },

    async saveQuizResult(quizData) {
        if (this.currentUser.id === 'guest') {
            this.showNotification('Faça login para guardar o progresso', 'info');
            return;
        }

        try {
            const formData = new FormData();
            formData.append('user_id', this.currentUser.id);
            formData.append('linguagem', quizData.language);
            formData.append('dificuldade', quizData.difficulty);
            formData.append('pontuacao', quizData.score);
            formData.append('total_perguntas', quizData.totalQuestions);
            formData.append('perfeito', quizData.percentage === 100 ? '1' : '0');
            formData.append('veloz', quizData.mode === 'timed' && quizData.timeLeft > 0 ? '1' : '0');
            formData.append('maratona', quizData.totalQuestions >= 15 ? '1' : '0');

            const response = await fetch(`${API_URL}?acao=salvar_resultado`, {
                method: 'POST',
                body: formData
            });

            const data = await response.json();

            if (data.sucesso) {
                // Atualizar progresso da linguagem
                const progressIncrease = Math.min(5, 100 - (this.currentUser.progresso[quizData.language] || 0));
                this.currentUser.progresso[quizData.language] = (this.currentUser.progresso[quizData.language] || 0) + progressIncrease;
                
                // Atualizar pontos e histórico
                this.currentUser.pontos += quizData.score;
                this.currentUser.quizzes++;
                
                // Verificar conquistas especiais
                if (quizData.percentage === 100 && !this.currentUser.conquistas.includes('perfect_score')) {
                    this.currentUser.conquistas.push('perfect_score');
                    this.currentUser.pontos += 100;
                    this.showNotification('🏆 Perfeição! +100 pontos', 'achievement');
                }
                
                // Calcular novo nível
                this.currentUser.nivel = Math.floor(this.currentUser.pontos / 100) + 1;
                this.currentUser.xp = this.currentUser.pontos % 100;
                
                this.currentUser.historico.unshift({
                    data: new Date().toISOString(),
                    linguagem: quizData.language,
                    dificuldade: quizData.difficulty,
                    pontuacao: quizData.score,
                    total_perguntas: quizData.totalQuestions,
                    percentage: quizData.percentage
                });

                if (this.currentUser.historico.length > 10) {
                    this.currentUser.historico = this.currentUser.historico.slice(0, 10);
                }

                localStorage.setItem('codemaster_user', JSON.stringify(this.currentUser));
                this.checkAchievements();
                this.updateUI();
                this.updateDashboard();
                
                this.showNotification(`+${quizData.score} pontos!`, 'success');
            }
        } catch (error) {
            console.error('Erro ao salvar resultado:', error);
        }
    },

    checkAchievements() {
        if (this.currentUser.id === 'guest') return;

        let novasConquistas = [];

        ACHIEVEMENTS.forEach(ach => {
            if (!this.currentUser.conquistas.includes(ach.id)) {
                let earned = false;
                
                if (ach.id === 'first_quiz' && this.currentUser.quizzes >= 1) earned = true;
                if (ach.id === 'quiz_master' && this.currentUser.quizzes >= 5) earned = true;
                if (ach.id === 'points_100' && this.currentUser.pontos >= 100) earned = true;
                if (ach.id === 'points_500' && this.currentUser.pontos >= 500) earned = true;
                if (ach.id === 'streak_7' && this.currentUser.streak >= 7) earned = true;
                if (ach.id === 'streak_30' && this.currentUser.streak >= 30) earned = true;
                if (ach.id === 'html_pro' && (this.currentUser.progresso.html || 0) >= 50) earned = true;
                if (ach.id === 'css_pro' && (this.currentUser.progresso.css || 0) >= 50) earned = true;
                if (ach.id === 'js_pro' && (this.currentUser.progresso.javascript || 0) >= 50) earned = true;
                if (ach.id === 'python_pro' && (this.currentUser.progresso.python || 0) >= 50) earned = true;
                if (ach.id === 'java_pro' && (this.currentUser.progresso.java || 0) >= 50) earned = true;
                if (ach.id === 'perfect_score' && this.currentUser.conquistas.includes('perfect_score')) earned = true;
                
                if (earned) {
                    this.currentUser.conquistas.push(ach.id);
                    this.currentUser.pontos += ach.pontos;
                    novasConquistas.push(ach);
                    this.showNotification(`🏆 ${ach.nome}! +${ach.pontos} pontos`, 'achievement');
                }
            }
        });

        if (novasConquistas.length > 0) {
            localStorage.setItem('codemaster_user', JSON.stringify(this.currentUser));
        }
    },

    logout() {
        this.currentUser = {
            id: 'guest',
            nome: 'Convidado',
            email: '',
            pontos: 0,
            quizzes: 0,
            streak: 0,
            bio: 'Aprendiz de programação',
            nivel: 1,
            xp: 0,
            progresso: { html: 0, css: 0, javascript: 0, python: 0, java: 0 },
            conquistas: [],
            historico: []
        };
        localStorage.removeItem('codemaster_user');
        this.updateUI();
        this.showNotification('Logout realizado', 'info');
        this.showAuthModal();
    },

    updateUI() {
        // Elementos do header
        const userName = document.getElementById('user-name');
        const userPoints = document.getElementById('user-points');
        const totalPoints = document.getElementById('total-points');
        const totalPointsDash = document.getElementById('total-points-dash');
        const quizzesCompleted = document.getElementById('quizzes-completed');
        const totalQuizzesDash = document.getElementById('total-quizzes-dash');
        const streakCount = document.getElementById('streak-count');
        const streakDash = document.getElementById('streak-dash');
        
        if (userName) userName.textContent = this.currentUser.nome;
        if (userPoints) userPoints.textContent = this.currentUser.pontos;
        if (totalPoints) totalPoints.textContent = this.currentUser.pontos;
        if (totalPointsDash) totalPointsDash.textContent = this.currentUser.pontos;
        if (quizzesCompleted) quizzesCompleted.textContent = this.currentUser.quizzes;
        if (totalQuizzesDash) totalQuizzesDash.textContent = this.currentUser.quizzes;
        if (streakCount) streakCount.textContent = this.currentUser.streak;
        if (streakDash) streakDash.textContent = this.currentUser.streak;

        // Tipo de usuário
        const userTypeBadge = document.getElementById('user-type-badge');
        if (userTypeBadge) {
            userTypeBadge.textContent = this.currentUser.id === 'guest' ? 'Convidado' : 'Aluno';
        }

        // Avatar
        const avatar = document.getElementById('user-avatar');
        if (avatar) {
            if (this.currentUser.id === 'guest') {
                avatar.innerHTML = '<i class="bx bx-user"></i>';
            } else {
                const initials = this.currentUser.nome.split(' ').map(n => n[0]).join('').toUpperCase().substring(0, 2);
                avatar.innerHTML = `<span>${initials}</span>`;
            }
        }

        // Atualizar barras de progresso
        this.updateProgressBars();
        
        // Atualizar dashboard
        this.updateDashboard();
        
        // Atualizar perfil
        this.updateProfilePage();
        
        // Atualizar conquistas
        this.updateAchievementsPage();
    },

    updateProgressBars() {
        const languages = ['html', 'css', 'javascript', 'python', 'java'];
        
        languages.forEach(lang => {
            const progress = this.currentUser.progresso[lang] || 0;
            const fill = document.getElementById(`${lang}-progress`);
            const percentSpan = document.getElementById(`${lang}-percent`);
            const progressContainer = fill?.parentElement;
            
            // Atualizar porcentagem
            if (percentSpan) {
                percentSpan.textContent = `${Math.round(progress)}%`;
            }
            
            // Só mostrar a barra de progresso se houver progresso > 0
            if (fill) {
                if (progress > 0) {
                    fill.style.width = `${progress}%`;
                    if (progressContainer) {
                        progressContainer.style.display = 'block';
                    }
                } else {
                    fill.style.width = '0%';
                    if (progressContainer) {
                        progressContainer.style.display = 'none';
                    }
                }
            }
        });
    },

    updateDashboard() {
        // Histórico de quizzes
        const historyBody = document.getElementById('history-body');
        if (historyBody) {
            if (this.currentUser.historico.length === 0) {
                historyBody.innerHTML = '<tr><td colspan="5" style="text-align: center;">Nenhum quiz realizado ainda</td></tr>';
            } else {
                historyBody.innerHTML = this.currentUser.historico.map(q => {
                    const date = new Date(q.data).toLocaleDateString('pt-BR');
                    return `
                        <tr>
                            <td>${date}</td>
                            <td>${q.linguagem.toUpperCase()}</td>
                            <td><span class="difficulty-badge ${q.dificuldade}">${q.dificuldade}</span></td>
                            <td>${q.pontuacao}</td>
                            <td>${q.percentage || Math.round((q.pontuacao / (q.total_perguntas * 10)) * 100)}%</td>
                        </tr>
                    `;
                }).join('');
            }
        }

        // Conquistas (apenas 5 no dashboard)
        const achievementsList = document.getElementById('achievements-list');
        if (achievementsList) {
            const recentAchievements = ACHIEVEMENTS.slice(0, 5);

            achievementsList.innerHTML = recentAchievements.map(ach => {
                const achieved = this.currentUser.conquistas.includes(ach.id);
                return `
                    <div class="achievement-item ${achieved ? 'achieved' : 'locked'}">
                        <div class="achievement-icon">
                            <i class='bx ${ach.icone}'></i>
                        </div>
                        <div class="achievement-info">
                            <h4>${ach.nome}</h4>
                            <p>${ach.descricao}</p>
                        </div>
                        <div class="achievement-status">
                            ${achieved ? '<i class="bx bx-check"></i>' : '<i class="bx bx-lock-alt"></i>'}
                        </div>
                    </div>
                `;
            }).join('');
        }

        // Leaderboard
        fetch(`${API_URL}?acao=leaderboard`)
            .then(r => r.json())
            .then(data => {
                if (data.sucesso) {
                    const lb = document.getElementById('leaderboard-body');
                    if (lb) {
                        lb.innerHTML = data.dados.map(u => `
                            <tr>
                                <td>#${u.posicao}</td>
                                <td>${u.nome}</td>
                                <td>${u.pontos}</td>
                            </tr>
                        `).join('');
                    }
                }
            })
            .catch(err => console.error('Erro ao carregar leaderboard:', err));
    },

    updateProfilePage() {
        const profileName = document.getElementById('profile-name');
        const profileBio = document.getElementById('profile-bio');
        const profileType = document.getElementById('profile-type');
        const editName = document.getElementById('edit-name');
        const editBio = document.getElementById('edit-bio');
        const profileAvatar = document.getElementById('profile-avatar-img');
        
        if (profileName) profileName.textContent = this.currentUser.nome;
        if (profileBio) profileBio.textContent = this.currentUser.bio || 'Aprendiz de programação';
        if (profileType) profileType.textContent = this.currentUser.id === 'guest' ? 'Convidado' : 'Aluno';
        if (editName) editName.value = this.currentUser.nome;
        if (editBio) editBio.value = this.currentUser.bio || '';
        
        if (profileAvatar) {
            const initials = this.currentUser.nome.split(' ').map(n => n[0]).join('').toUpperCase();
            profileAvatar.src = `https://ui-avatars.com/api/?name=${initials}&background=6366f1&color=fff&size=128`;
        }
    },

    updateAchievementsPage() {
        const container = document.getElementById('achievements-grid');
        if (!container) return;

        const unlockedCount = this.currentUser.conquistas.length;
        const totalCount = ACHIEVEMENTS.length;
        const totalPoints = ACHIEVEMENTS
            .filter(ach => this.currentUser.conquistas.includes(ach.id))
            .reduce((sum, ach) => sum + ach.pontos, 0);

        // Atualizar estatísticas
        const unlockedEl = document.getElementById('achievements-unlocked');
        const totalEl = document.getElementById('achievements-total');
        const pointsEl = document.getElementById('achievement-points-total');
        
        if (unlockedEl) unlockedEl.textContent = unlockedCount;
        if (totalEl) totalEl.textContent = totalCount;
        if (pointsEl) pointsEl.textContent = totalPoints;

        // Renderizar conquistas no mesmo formato do dashboard
        container.innerHTML = ACHIEVEMENTS.map(ach => {
            const achieved = this.currentUser.conquistas.includes(ach.id);
            return `
                <div class="achievement-card ${achieved ? 'unlocked' : 'locked'}">
                    <div class="achievement-icon-large">
                        <i class='bx ${ach.icone}'></i>
                    </div>
                    <h4>${ach.nome}</h4>
                    <p>${ach.descricao}</p>
                    <div class="achievement-points">+${ach.pontos} ⭐</div>
                    ${achieved ? '<div class="achievement-badge">✔️ Desbloqueado</div>' : ''}
                </div>
            `;
        }).join('');
    },

    setupEventListeners() {
        // Login form
        const loginForm = document.getElementById('login-form');
        if (loginForm) {
            loginForm.addEventListener('submit', (e) => {
                e.preventDefault();
                const email = document.getElementById('login-email').value;
                const password = document.getElementById('login-password').value;
                this.login(email, password);
            });
        }

        // Register form
        const registerForm = document.getElementById('register-form');
        if (registerForm) {
            registerForm.addEventListener('submit', (e) => {
                e.preventDefault();
                const name = document.getElementById('register-name').value;
                const email = document.getElementById('register-email').value;
                const password = document.getElementById('register-password').value;
                this.register(name, email, password);
            });
        }

        // Logout button
        const logoutBtn = document.getElementById('logout-btn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.logout();
            });
        }

        // Profile edit
        const saveProfileBtn = document.querySelector('.profile-edit-form .btn-primary');
        if (saveProfileBtn) {
            saveProfileBtn.addEventListener('click', () => this.saveProfile());
        }

        // Theme toggle
        const themeToggle = document.getElementById('theme-toggle');
        if (themeToggle) {
            themeToggle.addEventListener('click', () => this.toggleTheme());
        }

        // Auth tabs
        document.querySelectorAll('.auth-tab').forEach(tab => {
            tab.addEventListener('click', () => {
                this.switchAuthTab(tab.dataset.tab);
            });
        });

        // Close modal
        const closeModal = document.querySelector('.close-modal');
        if (closeModal) {
            closeModal.addEventListener('click', () => this.hideAuthModal());
        }

        window.addEventListener('click', (e) => {
            const modal = document.getElementById('auth-modal');
            if (e.target === modal) this.hideAuthModal();
        });

        // Avatar click para login
        const userAvatar = document.getElementById('user-avatar');
        if (userAvatar) {
            userAvatar.addEventListener('click', () => {
                if (this.currentUser.id === 'guest') {
                    this.showAuthModal();
                } else {
                    Navigation.switchMode('profile');
                }
            });
        }

        // Dropdown links - Perfil
        const profileLink = document.querySelector('.dropdown-menu a[data-mode="profile"]');
        if (profileLink) {
            profileLink.addEventListener('click', (e) => {
                e.preventDefault();
                if (this.currentUser.id === 'guest') {
                    this.showAuthModal();
                } else {
                    Navigation.switchMode('profile');
                }
            });
        }

        // Dropdown links - Conquistas
        const achievementsLink = document.querySelector('.dropdown-menu a[data-mode="achievements"]');
        if (achievementsLink) {
            achievementsLink.addEventListener('click', (e) => {
                e.preventDefault();
                if (this.currentUser.id === 'guest') {
                    this.showAuthModal();
                } else {
                    Navigation.switchMode('achievements');
                }
            });
        }

        // Dropdown links - Objetivos
        const objetivosLink = document.querySelector('.dropdown-menu a[data-mode="objetivos"]');
        if (objetivosLink) {
            objetivosLink.addEventListener('click', (e) => {
                e.preventDefault();
                if (this.currentUser.id === 'guest') {
                    this.showAuthModal();
                } else {
                    Navigation.switchMode('objetivos');
                }
            });
        }

        // Dropdown links - Erros
        const errosLink = document.querySelector('.dropdown-menu a[data-mode="erros"]');
        if (errosLink) {
            errosLink.addEventListener('click', (e) => {
                e.preventDefault();
                if (this.currentUser.id === 'guest') {
                    this.showAuthModal();
                } else {
                    Navigation.switchMode('erros');
                }
            });
        }
    },

    saveProfile() {
        const name = document.getElementById('edit-name')?.value;
        const bio = document.getElementById('edit-bio')?.value;
        
        if (name) {
            this.currentUser.nome = name;
            this.currentUser.bio = bio;
            
            localStorage.setItem('codemaster_user', JSON.stringify(this.currentUser));
            this.updateUI();
            this.showNotification('Perfil atualizado!', 'success');
        }
    },

    switchAuthTab(tabId) {
        document.querySelectorAll('.auth-tab').forEach(tab => {
            tab.classList.toggle('active', tab.dataset.tab === tabId);
        });
        document.querySelectorAll('.auth-form').forEach(form => {
            form.classList.toggle('active', form.id === `${tabId}-form`);
        });
    },

    showAuthModal() {
        const modal = document.getElementById('auth-modal');
        if (modal) {
            modal.classList.add('active');
            document.getElementById('login-form')?.reset();
            document.getElementById('register-form')?.reset();
            this.switchAuthTab('login');
        }
    },

    hideAuthModal() {
        const modal = document.getElementById('auth-modal');
        if (modal) modal.classList.remove('active');
    },

    toggleTheme() {
        const html = document.documentElement;
        const current = html.getAttribute('data-theme') || 'dark';
        const next = current === 'dark' ? 'light' : 'dark';
        
        html.setAttribute('data-theme', next);
        localStorage.setItem('codemaster_theme', next);
        
        const sunIcon = document.querySelector('.theme-btn .bx-sun');
        const moonIcon = document.querySelector('.theme-btn .bx-moon');
        
        if (sunIcon && moonIcon) {
            sunIcon.style.display = next === 'light' ? 'inline-block' : 'none';
            moonIcon.style.display = next === 'dark' ? 'inline-block' : 'none';
        }
    },

    loadTheme() {
        const saved = localStorage.getItem('codemaster_theme') || 'dark';
        document.documentElement.setAttribute('data-theme', saved);
        
        const sunIcon = document.querySelector('.theme-btn .bx-sun');
        const moonIcon = document.querySelector('.theme-btn .bx-moon');
        
        if (sunIcon && moonIcon) {
            sunIcon.style.display = saved === 'light' ? 'inline-block' : 'none';
            moonIcon.style.display = saved === 'dark' ? 'inline-block' : 'none';
        }
    },

    showNotification(message, type = 'info') {
        const toast = document.getElementById('achievement-toast');
        const msgEl = document.getElementById('achievement-message');
        if (toast && msgEl) {
            msgEl.textContent = message;
            toast.style.background = type === 'success' ? 'linear-gradient(135deg, #50fa7b, #10b981)' :
                                   type === 'error' ? 'linear-gradient(135deg, #ff5555, #dc2626)' :
                                   type === 'achievement' ? 'linear-gradient(135deg, #bd93f9, #8b5cf6)' :
                                   'linear-gradient(135deg, #bd93f9, #8b5cf6)';
            toast.classList.add('show');
            setTimeout(() => toast.classList.remove('show'), 3000);
        }
    }
};

// ===========================================
// SISTEMA DE QUIZ
// ===========================================
const QuizSystem = {
    currentQuiz: [],
    currentIndex: 0,
    score: 0,
    answers: [],
    timer: null,
    timeLeft: 60,
    mode: 'normal',

    init() {
        this.setupEventListeners();
    },

    setupEventListeners() {
        // Modos de quiz
        document.querySelectorAll('.quiz-mode-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                this.setMode(btn.dataset.mode);
            });
        });

        // Iniciar quiz
        document.getElementById('start-quiz')?.addEventListener('click', () => {
            this.start();
        });

        // Navegação
        document.getElementById('next-btn')?.addEventListener('click', () => this.next());
        document.getElementById('prev-btn')?.addEventListener('click', () => this.prev());
        document.getElementById('submit-btn')?.addEventListener('click', () => this.finish());

        // Reiniciar
        document.getElementById('restart-btn')?.addEventListener('click', () => this.restart());

        // Desafios
        document.querySelectorAll('.challenge-start').forEach(btn => {
            btn.addEventListener('click', () => {
                this.startChallenge(btn.dataset.type);
            });
        });
    },

    setMode(mode) {
        this.mode = mode;
        document.querySelectorAll('.quiz-mode-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.mode === mode);
        });
        
        const timerDisplay = document.getElementById('timer-display');
        if (timerDisplay) {
            timerDisplay.style.display = mode === 'timed' ? 'flex' : 'none';
        }
    },

    start() {
        const language = document.getElementById('language-select').value;
        const difficulty = document.getElementById('difficulty-select').value;
        const count = parseInt(document.getElementById('question-count').value);

        const allQuestions = QUESTIONS[language]?.[difficulty] || [];
        if (allQuestions.length === 0) {
            UserSystem.showNotification('Nenhuma pergunta disponível', 'error');
            return;
        }

        // Selecionar perguntas aleatórias
        this.currentQuiz = [...allQuestions].sort(() => 0.5 - Math.random()).slice(0, Math.min(count, allQuestions.length));
        this.currentIndex = 0;
        this.score = 0;
        this.answers = new Array(this.currentQuiz.length).fill(null);
        this.timeLeft = 60;

        // UI
        document.getElementById('total-questions').textContent = this.currentQuiz.length;
        document.getElementById('current-score').textContent = this.score;
        document.getElementById('timer').textContent = this.timeLeft;

        document.querySelector('.quiz-setup').style.display = 'none';
        document.getElementById('quiz-container').style.display = 'block';
        document.getElementById('results').style.display = 'none';

        if (this.mode === 'timed') {
            this.startTimer();
        }

        this.loadQuestion();
    },

    startTimer() {
        if (this.timer) clearInterval(this.timer);
        this.timer = setInterval(() => {
            this.timeLeft--;
            document.getElementById('timer').textContent = this.timeLeft;
            if (this.timeLeft <= 0) this.finish();
        }, 1000);
    },

    loadQuestion() {
        const question = this.currentQuiz[this.currentIndex];
        
        document.getElementById('current-question').textContent = this.currentIndex + 1;
        document.getElementById('question-text').textContent = question.question;
        
        const difficulty = document.getElementById('difficulty-select').value;
        const difficultyBadge = document.getElementById('difficulty-badge');
        difficultyBadge.textContent = difficulty === 'easy' ? 'Fácil' : difficulty === 'medium' ? 'Médio' : 'Difícil';
        difficultyBadge.className = `difficulty-badge ${difficulty}`;
        
        document.getElementById('points-badge').textContent = `${question.points} pts`;

        const progress = ((this.currentIndex + 1) / this.currentQuiz.length) * 100;
        document.getElementById('progress-fill').style.width = `${progress}%`;

        const optionsContainer = document.getElementById('options-container');
        optionsContainer.innerHTML = '';

        question.options.forEach((option, index) => {
            const optionEl = document.createElement('div');
            optionEl.className = 'option';
            if (this.answers[this.currentIndex] === index) {
                optionEl.classList.add('selected');
            }
            optionEl.textContent = option;
            optionEl.dataset.index = index;
            optionEl.addEventListener('click', (e) => this.selectOption(e));
            optionsContainer.appendChild(optionEl);
        });

        document.getElementById('prev-btn').disabled = this.currentIndex === 0;
        
        const nextBtn = document.getElementById('next-btn');
        const submitBtn = document.getElementById('submit-btn');
        
        if (this.currentIndex === this.currentQuiz.length - 1) {
            nextBtn.style.display = 'none';
            submitBtn.style.display = 'flex';
        } else {
            nextBtn.style.display = 'flex';
            submitBtn.style.display = 'none';
        }
    },

    selectOption(e) {
        const index = parseInt(e.target.dataset.index);
        this.answers[this.currentIndex] = index;
        
        document.querySelectorAll('.option').forEach(opt => opt.classList.remove('selected'));
        e.target.classList.add('selected');
    },

    next() {
        if (this.currentIndex < this.currentQuiz.length - 1) {
            this.currentIndex++;
            this.loadQuestion();
        }
    },

    prev() {
        if (this.currentIndex > 0) {
            this.currentIndex--;
            this.loadQuestion();
        }
    },

    finish() {
        if (this.timer) clearInterval(this.timer);

        let correct = 0;
        const errors = [];

        this.currentQuiz.forEach((question, index) => {
            if (this.answers[index] === question.correct) {
                correct++;
                this.score += question.points;
            } else {
                errors.push({
                    pergunta: question.question,
                    respostaUsuario: question.options[this.answers[index]] || 'Não respondida',
                    respostaCorreta: question.options[question.correct]
                });
            }
        });

        // Bônus por tempo
        if (this.mode === 'timed' && this.timeLeft > 0) {
            this.score += this.timeLeft * 2;
        }

        const percentage = Math.round((correct / this.currentQuiz.length) * 100);
        const maxScore = this.currentQuiz.reduce((sum, q) => sum + q.points, 0);

        // UI de resultados
        document.getElementById('final-score').textContent = this.score;
        document.getElementById('correct-answers').textContent = correct;
        document.getElementById('total-questions-result').textContent = this.currentQuiz.length;
        document.getElementById('percentage').textContent = `${percentage}%`;

        const feedback = document.getElementById('feedback');
        const scorePercentage = (this.score / maxScore) * 100;
        
        if (scorePercentage >= 80) {
            feedback.textContent = '🎉 Excelente! Você domina este assunto!';
            feedback.className = 'feedback good';
        } else if (scorePercentage >= 50) {
            feedback.textContent = '👍 Bom trabalho! Continue praticando!';
            feedback.className = 'feedback average';
        } else {
            feedback.textContent = '💡 Estude um pouco mais este tópico!';
            feedback.className = 'feedback poor';
        }

        // Mostrar erros se houver
        const errosList = document.getElementById('erros-list');
        const errosContainer = document.querySelector('.erros-container');
        
        if (errors.length > 0) {
            errosList.style.display = 'block';
            errosContainer.innerHTML = errors.map(error => `
                <div class="erro-item">
                    <div class="erro-pergunta">${error.pergunta}</div>
                    <div class="erro-respostas">
                        <span class="erro-resposta-usuario">Sua resposta: ${error.respostaUsuario}</span>
                        <span class="erro-resposta-correta">Correta: ${error.respostaCorreta}</span>
                    </div>
                </div>
            `).join('');
        } else {
            errosList.style.display = 'none';
        }

        document.getElementById('quiz-container').style.display = 'none';
        document.getElementById('results').style.display = 'block';

        // Salvar resultado
        UserSystem.saveQuizResult({
            language: document.getElementById('language-select').value,
            difficulty: document.getElementById('difficulty-select').value,
            score: this.score,
            totalQuestions: this.currentQuiz.length,
            correctAnswers: correct,
            percentage: percentage,
            mode: this.mode,
            timeLeft: this.timeLeft,
            errors: errors
        });
    },

    restart() {
        document.querySelector('.quiz-setup').style.display = 'block';
        document.getElementById('quiz-container').style.display = 'none';
        document.getElementById('results').style.display = 'none';
    },

    startChallenge(type) {
        const config = {
            'speed': { mode: 'timed', count: 10, difficulty: 'medium' },
            'marathon': { mode: 'normal', count: 15, difficulty: 'hard' },
            'survival': { mode: 'normal', count: 5, difficulty: 'medium' }
        };

        const c = config[type];
        if (c) {
            this.setMode(c.mode);
            document.getElementById('question-count').value = c.count;
            document.getElementById('difficulty-select').value = c.difficulty;
            this.start();
        } else {
            UserSystem.showNotification('Modo em desenvolvimento', 'info');
        }
    }
};

// ===========================================
// SISTEMA DE NAVEGAÇÃO
// ===========================================
const Navigation = {
    currentMode: 'study',

    init() {
        this.setupEventListeners();
        this.loadSavedMode();
    },

    setupEventListeners() {
        // Botões de modo na página principal
        document.querySelectorAll('.mode-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                const mode = btn.dataset.mode;
                if (mode) this.switchMode(mode);
            });
        });

        // Links de navegação no header
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const mode = link.dataset.mode;
                if (mode) this.switchMode(mode);
            });
        });

        // Links do dropdown do perfil
        document.querySelectorAll('.dropdown-menu a').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const mode = link.dataset.mode;
                if (mode) this.switchMode(mode);
            });
        });

        // Links do footer
        document.querySelectorAll('.footer-links a').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const mode = link.dataset.mode;
                if (mode) this.switchMode(mode);
            });
        });
    },

    switchMode(mode) {
        this.currentMode = mode;
        
        // Atualizar botões de modo
        document.querySelectorAll('.mode-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.mode === mode);
        });

        // Esconder todos os modos
        const modes = ['study', 'quiz', 'practice', 'dashboard', 'challenge', 'profile', 'achievements', 'objetivos', 'erros', 'mentor-chat'];
        modes.forEach(m => {
            const element = document.querySelector(`.${m}-mode`);
            if (element) element.classList.remove('active');
        });

        // Mostrar modo atual
        const currentElement = document.querySelector(`.${mode}-mode`);
        if (currentElement) {
            currentElement.classList.add('active');
            
            // Ações específicas para cada modo
            switch(mode) {
                case 'study':
                    loadResources('html');
                    break;
                case 'dashboard':
                    UserSystem.updateDashboard();
                    break;
                case 'profile':
                    UserSystem.updateProfilePage();
                    break;
                case 'achievements':
                    UserSystem.updateAchievementsPage();
                    break;
                case 'objetivos':
                    this.loadObjetivosPage();
                    break;
                case 'erros':
                    this.loadErrosPage();
                    break;
            }
        }

        localStorage.setItem('codemaster_current_mode', mode);
        window.scrollTo({ top: 0, behavior: 'smooth' });
    },

    loadSavedMode() {
        const saved = localStorage.getItem('codemaster_current_mode');
        if (saved) {
            this.switchMode(saved);
        }
    },

    loadObjetivosPage() {
        const container = document.getElementById('objetivos-grid');
        if (!container) return;

        container.innerHTML = `
            <div style="text-align: center; padding: 3rem; grid-column: 1/-1;">
                <i class='bx bx-target-lock' style="font-size: 4rem; color: var(--primary); margin-bottom: 1rem;"></i>
                <h3>Funcionalidade de Objetivos em Desenvolvimento</h3>
                <p style="color: var(--gray-light); margin-top: 1rem;">Em breve você poderá criar seus próprios objetivos de estudo!</p>
            </div>
        `;
    },

    loadErrosPage() {
        const container = document.getElementById('erros-cards');
        if (!container) return;

        if (UserSystem.currentUser.id === 'guest') {
            container.innerHTML = `
                <div style="text-align: center; padding: 3rem;">
                    <i class='bx bx-error-circle' style="font-size: 4rem; color: var(--gray); margin-bottom: 1rem;"></i>
                    <h3>Faça login para ver seus erros</h3>
                    <button class="btn-primary" style="margin-top: 1rem;" onclick="UserSystem.showAuthModal()">Fazer Login</button>
                </div>
            `;
            return;
        }

        container.innerHTML = `
            <div style="text-align: center; padding: 3rem; grid-column: 1/-1;">
                <i class='bx bx-check-circle' style="font-size: 4rem; color: var(--success); margin-bottom: 1rem;"></i>
                <h3>Nenhum erro registrado ainda</h3>
                <p style="color: var(--gray-light); margin-top: 1rem;">Continue praticando! Seus erros aparecerão aqui.</p>
            </div>
        `;
    }
};

// ===========================================
// FUNÇÕES DE RECURSOS DE ESTUDO
// ===========================================
function loadResources(language) {
    const selected = document.getElementById('selected-language');
    const list = document.getElementById('resource-list');
    const count = document.getElementById('resources-count');
    
    if (!selected || !list) return;
    
    selected.textContent = language.toUpperCase();
    
    const langResources = RESOURCES[language] || [];
    if (count) count.textContent = `${langResources.length} recursos disponíveis`;
    
    list.innerHTML = langResources.map(r => `
        <div class="resource-item">
            <h3>${r.title}</h3>
            <a href="${r.url}" target="_blank" rel="noopener noreferrer">
                <i class='bx bx-link-external'></i> Acessar recurso
            </a>
        </div>
    `).join('');
}

function setupLanguageCards() {
    document.querySelectorAll('.language-card').forEach(card => {
        card.addEventListener('click', () => {
            loadResources(card.dataset.lang);
            card.style.transform = 'scale(0.95)';
            setTimeout(() => card.style.transform = 'scale(1)', 150);
        });
    });
}

// ===========================================
// EDITOR DE CÓDIGO
// ===========================================
let codeEditor = null;

function setupCodeEditor() {
    const textarea = document.getElementById('code-editor');
    if (!textarea || typeof CodeMirror === 'undefined') return;

    const savedTheme = localStorage.getItem('codemaster_theme') || 'dark';
    const editorTheme = savedTheme === 'light' ? 'eclipse' : 'dracula';

    codeEditor = CodeMirror.fromTextArea(textarea, {
        lineNumbers: true,
        mode: 'htmlmixed',
        theme: editorTheme,
        autoCloseBrackets: true,
        matchBrackets: true,
        indentUnit: 4,
        tabSize: 4,
        lineWrapping: true
    });

    // Botões do editor
    document.getElementById('run-code')?.addEventListener('click', runCode);
    document.getElementById('save-code')?.addEventListener('click', saveCode);
    document.getElementById('reset-code')?.addEventListener('click', resetCode);
    document.getElementById('clear-output')?.addEventListener('click', clearOutput);
    
    document.getElementById('editor-language')?.addEventListener('change', (e) => {
        const mode = {
            'html': 'htmlmixed',
            'css': 'css',
            'javascript': 'javascript'
        }[e.target.value] || 'htmlmixed';
        codeEditor.setOption('mode', mode);
    });

    document.getElementById('theme-toggle-editor')?.addEventListener('click', () => {
        const current = codeEditor.getOption('theme');
        const next = current === 'dracula' ? 'eclipse' : 'dracula';
        codeEditor.setOption('theme', next);
    });

    // Desafios
    document.querySelectorAll('.challenge-start-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const challenge = btn.closest('.challenge-card')?.dataset.challenge;
            loadChallenge(challenge);
        });
    });
}

function runCode() {
    if (!codeEditor) return;
    
    const code = codeEditor.getValue();
    const language = document.getElementById('editor-language').value;
    const output = document.getElementById('code-output');
    if (!output) return;

    let content = code;
    if (language === 'css') {
        content = `
            <!DOCTYPE html>
            <html>
            <head><style>${code}</style></head>
            <body>
                <div style="padding:20px; font-family:Arial;">
                    <h1>Preview CSS</h1>
                    <p>Seu CSS foi aplicado a este conteúdo de exemplo.</p>
                    <div class="box" style="padding:20px; background:#f0f0f0; border-radius:8px;">Caixa de exemplo</div>
                </div>
            </body>
            </html>
        `;
    } else if (language === 'javascript') {
        content = `
            <!DOCTYPE html>
            <html>
            <head>
                <style>body{font-family:Arial;padding:20px;}</style>
            </head>
            <body>
                <h2>Output JavaScript</h2>
                <div id="output" style="background:#f5f5f5; padding:15px; border-radius:8px;"></div>
                <script>
                    const outputDiv = document.getElementById('output');
                    const originalLog = console.log;
                    console.log = (...args) => {
                        outputDiv.innerHTML += args.join(' ') + '<br>';
                        originalLog.apply(console, args);
                    };
                    try {
                        ${code}
                    } catch(e) {
                        outputDiv.innerHTML = '<span style="color:red;">Erro: ' + e.message + '</span>';
                    }
                <\/script>
            </body>
            </html>
        `;
    }

    output.srcdoc = content;
    UserSystem.showNotification('Código executado!', 'success');
}

function saveCode() {
    if (!codeEditor) return;
    
    const code = codeEditor.getValue();
    const language = document.getElementById('editor-language').value;
    const ext = { 'html': 'html', 'css': 'css', 'javascript': 'js' }[language] || 'txt';
    const filename = `codemaster_${Date.now()}.${ext}`;

    const blob = new Blob([code], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);

    UserSystem.showNotification('Código salvo!', 'success');
}

function resetCode() {
    if (!codeEditor) return;
    codeEditor.setValue('');
    UserSystem.showNotification('Editor limpo!', 'info');
}

function clearOutput() {
    const output = document.getElementById('code-output');
    if (output) output.srcdoc = '';
    UserSystem.showNotification('Saída limpa!', 'info');
}

function loadChallenge(challengeId) {
    const challenges = {
        '1': {
            title: 'Calculadora',
            code: `<!DOCTYPE html>
<html>
<head>
    <title>Calculadora</title>
    <style>
        .calculator {
            max-width: 300px;
            margin: 50px auto;
            padding: 20px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            border-radius: 15px;
            box-shadow: 0 10px 20px rgba(0,0,0,0.2);
        }
        .display {
            background: white;
            padding: 15px;
            text-align: right;
            font-size: 2rem;
            margin-bottom: 15px;
            border-radius: 8px;
        }
        .buttons {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 10px;
        }
        button {
            padding: 15px;
            font-size: 1.2rem;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            background: white;
            transition: 0.2s;
        }
        button:hover { transform: scale(1.05); }
        .operator { background: #ffb347; }
        .equals { background: #4caf50; color: white; }
        .clear { background: #f44336; color: white; }
    </style>
</head>
<body>
    <div class="calculator">
        <div class="display" id="display">0</div>
        <div class="buttons">
            <button onclick="append('7')">7</button>
            <button onclick="append('8')">8</button>
            <button onclick="append('9')">9</button>
            <button class="operator" onclick="append('/')">/</button>
            <button onclick="append('4')">4</button>
            <button onclick="append('5')">5</button>
            <button onclick="append('6')">6</button>
            <button class="operator" onclick="append('*')">*</button>
            <button onclick="append('1')">1</button>
            <button onclick="append('2')">2</button>
            <button onclick="append('3')">3</button>
            <button class="operator" onclick="append('-')">-</button>
            <button class="clear" onclick="clearDisplay()">C</button>
            <button onclick="append('0')">0</button>
            <button class="equals" onclick="calculate()">=</button>
            <button class="operator" onclick="append('+')">+</button>
        </div>
    </div>

    <script>
        let display = document.getElementById('display');
        function append(value) {
            display.textContent = display.textContent === '0' ? value : display.textContent + value;
        }
        function clearDisplay() {
            display.textContent = '0';
        }
        function calculate() {
            try {
                display.textContent = eval(display.textContent);
            } catch(e) {
                display.textContent = 'Erro';
            }
        }
    <\/script>
</body>
</html>`
        },
        '2': {
            title: 'Lista de Tarefas',
            code: `<!DOCTYPE html>
<html>
<head>
    <title>Lista de Tarefas</title>
    <style>
        body { font-family: Arial; max-width: 500px; margin: 50px auto; padding: 20px; }
        .container { background: linear-gradient(135deg, #667eea, #764ba2); padding: 20px; border-radius: 15px; }
        h1 { text-align: center; color: white; }
        .input-group { display: flex; gap: 10px; margin-bottom: 20px; }
        input { flex: 1; padding: 10px; border: none; border-radius: 5px; }
        button { padding: 10px 20px; background: #4caf50; color: white; border: none; border-radius: 5px; cursor: pointer; }
        button:hover { background: #45a049; }
        ul { list-style: none; padding: 0; }
        li { background: white; padding: 10px; margin-bottom: 5px; border-radius: 5px; display: flex; justify-content: space-between; }
        .delete { background: #f44336; color: white; border: none; padding: 5px 10px; border-radius: 3px; cursor: pointer; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Lista de Tarefas</h1>
        <div class="input-group">
            <input type="text" id="taskInput" placeholder="Nova tarefa...">
            <button onclick="addTask()">Adicionar</button>
        </div>
        <ul id="taskList"></ul>
    </div>

    <script>
        function addTask() {
            const input = document.getElementById('taskInput');
            const text = input.value.trim();
            if (text) {
                const li = document.createElement('li');
                li.innerHTML = \`<span>\${text}</span><button class="delete" onclick="this.parentElement.remove()">X</button>\`;
                document.getElementById('taskList').appendChild(li);
                input.value = '';
            }
        }
    <\/script>
</body>
</html>`
        }
    };

    const challenge = challenges[challengeId];
    if (challenge && codeEditor) {
        codeEditor.setValue(challenge.code);
        Navigation.switchMode('practice');
        UserSystem.showNotification(`Desafio: ${challenge.title}`, 'info');
    }
}

// ===========================================
// FUNÇÕES GLOBAIS
// ===========================================
window.continuarComoConvidado = () => {
    UserSystem.showAuthModal();
    UserSystem.showNotification('Faça login para salvar seu progresso!', 'info');
};

window.togglePasswordVisibility = (inputId, btn) => {
    const input = document.getElementById(inputId);
    if (input) {
        input.type = input.type === 'password' ? 'text' : 'password';
        btn.querySelector('i').className = input.type === 'password' ? 'bx bx-hide' : 'bx bx-show';
    }
};

window.mudarAvatar = () => {
    if (UserSystem.currentUser.id === 'guest') {
        UserSystem.showNotification('Faça login para alterar o avatar', 'warning');
        UserSystem.showAuthModal();
        return;
    }
    UserSystem.showNotification('Funcionalidade de avatar em breve!', 'info');
};

window.salvarPerfil = () => UserSystem.saveProfile();

window.showCriarObjetivo = () => {
    if (UserSystem.currentUser.id === 'guest') {
        UserSystem.showAuthModal();
        return;
    }
    UserSystem.showNotification('Funcionalidade de objetivos em breve!', 'info');
};

window.fecharModalObjetivo = () => {
    const modal = document.getElementById('objetivo-modal');
    if (modal) modal.classList.remove('active');
};

window.criarSalaMultiplayer = () => {
    if (UserSystem.currentUser.id === 'guest') {
        UserSystem.showAuthModal();
        return;
    }
    UserSystem.showNotification('Modo multiplayer em breve!', 'info');
};

window.entrarSalaMultiplayer = () => {
    if (UserSystem.currentUser.id === 'guest') {
        UserSystem.showAuthModal();
        return;
    }
    UserSystem.showNotification('Modo multiplayer em breve!', 'info');
};

window.enviarMensagem = () => {
    if (UserSystem.currentUser.id === 'guest') {
        UserSystem.showAuthModal();
        return;
    }
    UserSystem.showNotification('Chat em breve!', 'info');
};

// ===========================================
// INICIALIZAÇÃO PRINCIPAL
// ===========================================
document.addEventListener('DOMContentLoaded', async () => {
    // Inicializar sistemas
    await UserSystem.init();
    QuizSystem.init();
    Navigation.init();

    // Configurar funcionalidades
    setupLanguageCards();
    setupCodeEditor();
    loadResources('html');

    // Mostrar modal de login para convidados
    setTimeout(() => {
        if (UserSystem.currentUser.id === 'guest') {
            UserSystem.showAuthModal();
            UserSystem.showNotification('👋 Bem-vindo ao CodeMaster Pro!', 'info');
        }
    }, 1500);

    console.log('✅ CodeMaster Pro inicializado com sucesso!');
});