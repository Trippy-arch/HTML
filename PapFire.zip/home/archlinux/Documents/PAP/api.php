<?php
// api.php - Versão Corrigida com foco no login
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=utf-8");

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once 'conexao.php';

// Ativar relatório de erros para debug
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Log para debug
$log_file = 'debug.log';
function debug_log($message) {
    global $log_file;
    file_put_contents($log_file, date('[Y-m-d H:i:s] ') . $message . PHP_EOL, FILE_APPEND);
}

debug_log("API chamada - Método: " . $_SERVER['REQUEST_METHOD'] . ", Ação: " . ($_GET['acao'] ?? 'nenhuma'));

$acao = $_GET['acao'] ?? '';

switch($acao) {
    
    case 'login':
        debug_log("Processando login");
        
        // Pegar dados do POST
        $email = $_POST['email'] ?? '';
        $senha = $_POST['senha'] ?? '';
        
        debug_log("Email recebido: $email");
        debug_log("Senha recebida (raw): $senha");
        
        if (empty($email) || empty($senha)) {
            echo json_encode([
                'sucesso' => false, 
                'mensagem' => 'Email e senha são obrigatórios'
            ]);
            exit;
        }
        
        // Gerar hash MD5 da senha fornecida
        $senha_hash = md5($senha);
        debug_log("Hash gerado: $senha_hash");
        
        // Buscar usuário na base de dados
        $sql = "SELECT id, nome, email, pontos, tipo, bio, streak, ultimo_login, senha FROM usuarios WHERE email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $resultado = $stmt->get_result();
        
        debug_log("Resultados encontrados: " . $resultado->num_rows);
        
        if ($resultado->num_rows > 0) {
            $usuario = $resultado->fetch_assoc();
            
            debug_log("Hash no banco: " . $usuario['senha']);
            debug_log("Comparação: " . ($senha_hash === $usuario['senha'] ? 'IGUAIS' : 'DIFERENTES'));
            
            // Verificar a senha
            if ($senha_hash === $usuario['senha']) {
                // Remover senha do array antes de enviar
                unset($usuario['senha']);
                
                // Atualizar streak
                $hoje = date('Y-m-d');
                $ultimo_login = $usuario['ultimo_login'];
                
                if ($ultimo_login == $hoje) {
                    $novo_streak = $usuario['streak'];
                } elseif ($ultimo_login == date('Y-m-d', strtotime('-1 day'))) {
                    $novo_streak = ($usuario['streak'] ?? 0) + 1;
                } else {
                    $novo_streak = 1;
                }
                
                // Atualizar último login e streak
                $update_sql = "UPDATE usuarios SET ultimo_login = ?, streak = ? WHERE id = ?";
                $update_stmt = $conn->prepare($update_sql);
                $update_stmt->bind_param("sii", $hoje, $novo_streak, $usuario['id']);
                $update_stmt->execute();
                $update_stmt->close();
                
                $usuario['streak'] = $novo_streak;
                
                echo json_encode([
                    'sucesso' => true,
                    'mensagem' => 'Login bem-sucedido',
                    'dados' => $usuario
                ]);
            } else {
                echo json_encode([
                    'sucesso' => false,
                    'mensagem' => 'Senha incorreta'
                ]);
            }
        } else {
            echo json_encode([
                'sucesso' => false,
                'mensagem' => 'Email não encontrado'
            ]);
        }
        
        $stmt->close();
        break;
    
    case 'registar':
        debug_log("Processando registo");
        
        $nome = $_POST['nome'] ?? '';
        $email = $_POST['email'] ?? '';
        $senha = $_POST['senha'] ?? '';
        
        debug_log("Nome: $nome, Email: $email");
        
        if (empty($nome) || empty($email) || empty($senha)) {
            echo json_encode([
                'sucesso' => false, 
                'mensagem' => 'Todos os campos são obrigatórios'
            ]);
            exit;
        }
        
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo json_encode([
                'sucesso' => false, 
                'mensagem' => 'Email inválido'
            ]);
            exit;
        }
        
        // Verificar se email já existe
        $check_sql = "SELECT id FROM usuarios WHERE email = ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("s", $email);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();
        
        if ($check_result->num_rows > 0) {
            echo json_encode([
                'sucesso' => false, 
                'mensagem' => 'Este email já está registado'
            ]);
            $check_stmt->close();
            exit;
        }
        $check_stmt->close();
        
        // Gerar hash MD5 da senha
        $senha_hash = md5($senha);
        debug_log("Hash gerado para registro: $senha_hash");
        
        $sql = "INSERT INTO usuarios (nome, email, senha, pontos, data_criacao, ultimo_login) VALUES (?, ?, ?, 0, NOW(), ?)";
        $stmt = $conn->prepare($sql);
        $hoje = date('Y-m-d');
        $stmt->bind_param("ssss", $nome, $email, $senha_hash, $hoje);
        
        if ($stmt->execute()) {
            $novo_id = $stmt->insert_id;
            
            echo json_encode([
                'sucesso' => true,
                'mensagem' => 'Utilizador registado com sucesso',
                'dados' => [
                    'id' => $novo_id,
                    'nome' => $nome,
                    'email' => $email,
                    'pontos' => 0
                ]
            ]);
        } else {
            echo json_encode([
                'sucesso' => false,
                'mensagem' => 'Erro ao registar: ' . $conn->error
            ]);
        }
        
        $stmt->close();
        break;
    
    case 'leaderboard':
        $sql = "SELECT id, nome, pontos FROM usuarios ORDER BY pontos DESC LIMIT 10";
        $resultado = $conn->query($sql);
        
        $leaderboard = [];
        $posicao = 1;
        while ($row = $resultado->fetch_assoc()) {
            $row['posicao'] = $posicao++;
            $leaderboard[] = $row;
        }
        
        echo json_encode([
            'sucesso' => true,
            'dados' => $leaderboard
        ]);
        break;
    
    default:
        echo json_encode([
            'sucesso' => false,
            'mensagem' => 'Ação não encontrada: ' . $acao
        ]);
        break;
}

$conn->close();
?>