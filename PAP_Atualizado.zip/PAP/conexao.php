<?php
$servidor = "localhost";
$usuario = "root";
$senha = "";
$banco = "codemaster_db";

$conn = new mysqli($servidor, $usuario, $senha, $banco);

if ($conn->connect_error) {
    die(json_encode([
        'sucesso' => false,
        'mensagem' => 'Falha na ligação: ' . $conn->connect_error
    ]));
}

$conn->set_charset("utf8");
?>
