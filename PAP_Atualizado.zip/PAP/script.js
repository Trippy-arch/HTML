// Dados de recursos por linguagem
const resources = {
    html: [
        { title: "MDN Web Docs - HTML", url: "https://developer.mozilla.org/pt-BR/docs/Web/HTML" },
        { title: "W3Schools - HTML Tutorial", url: "https://www.w3schools.com/html/" },
        { title: "HTML.com Tutorial", url: "https://html.com/" },
        { title: "FreeCodeCamp - HTML", url: "https://www.freecodecamp.org/learn/responsive-web-design/#basic-html-and-html5" }
    ],
    css: [
        { title: "MDN Web Docs - CSS", url: "https://developer.mozilla.org/pt-BR/docs/Web/CSS" },
        { title: "W3Schools - CSS Tutorial", url: "https://www.w3schools.com/css/" },
        { title: "CSS-Tricks", url: "https://css-tricks.com/" },
        { title: "FreeCodeCamp - CSS", url: "https://www.freecodecamp.org/learn/responsive-web-design/#basic-css" }
    ],
    javascript: [
        { title: "MDN Web Docs - JavaScript", url: "https://developer.mozilla.org/pt-BR/docs/Web/JavaScript" },
        { title: "W3Schools - JavaScript Tutorial", url: "https://www.w3schools.com/js/" },
        { title: "JavaScript.info", url: "https://javascript.info/" },
        { title: "FreeCodeCamp - JavaScript", url: "https://www.freecodecamp.org/learn/javascript-algorithms-and-data-structures/" }
    ],
    python: [
        { title: "Python.org Documentation", url: "https://docs.python.org/3/" },
        { title: "W3Schools - Python Tutorial", url: "https://www.w3schools.com/python/" },
        { title: "Real Python", url: "https://realpython.com/" },
        { title: "FreeCodeCamp - Python", url: "https://www.freecodecamp.org/learn/scientific-computing-with-python/" }
    ],
    java: [
        { title: "Oracle Java Documentation", url: "https://docs.oracle.com/javase/tutorial/" },
        { title: "W3Schools - Java Tutorial", url: "https://www.w3schools.com/java/" },
        { title: "JavaTpoint", url: "https://www.javatpoint.com/java-tutorial" },
        { title: "GeeksforGeeks - Java", url: "https://www.geeksforgeeks.org/java/" }
    ]
};

// Dados de perguntas completas
const questions = {
    html: {
        easy: [
            {
                question: "O que significa HTML?",
                options: ["HyperText Markup Language", "HighTech Modern Language", "HyperTransfer Markup Language", "Home Tool Markup Language"],
                correct: 0, points: 10
            },
            {
                question: "Qual tag é usada para criar um link?",
                options: ["<link>", "<a>", "<href>", "<url>"],
                correct: 1, points: 10
            },
            {
                question: "Qual tag define o título principal da página?",
                options: ["<h1>", "<head>", "<title>", "<header>"],
                correct: 0, points: 10
            },
            {
                question: "Qual atributo é usado para imagens?",
                options: ["src", "href", "link", "url"],
                correct: 0, points: 10
            },
            {
                question: "Qual tag cria uma lista não ordenada?",
                options: ["<ul>", "<ol>", "<li>", "<list>"],
                correct: 0, points: 10
            }
        ],
        medium: [
            {
                question: "Qual atributo é usado para especificar uma classe CSS?",
                options: ["class", "css", "style", "id"],
                correct: 0, points: 20
            },
            {
                question: "Qual elemento HTML é usado para o conteúdo principal?",
                options: ["<main>", "<body>", "<content>", "<section>"],
                correct: 0, points: 20
            },
            {
                question: "Qual tag é semanticamente correta para navegação?",
                options: ["<nav>", "<menu>", "<navigation>", "<navbar>"],
                correct: 0, points: 20
            },
            {
                question: "Qual elemento é usado para rodapé?",
                options: ["<footer>", "<bottom>", "<end>", "<foot>"],
                correct: 0, points: 20
            },
            {
                question: "Qual meta tag é importante para responsividade?",
                options: ["viewport", "responsive", "mobile", "scale"],
                correct: 0, points: 20
            }
        ],
        hard: [
            {
                question: "Qual elemento HTML5 é usado para conteúdo independente?",
                options: ["<section>", "<article>", "<aside>", "<div>"],
                correct: 1, points: 30
            },
            {
                question: "Qual é a diferença entre <div> e <span>?",
                options: ["<div> é inline, <span> é block", "<div> é block, <span> é inline", "Ambos são block", "Ambos são inline"],
                correct: 1, points: 30
            },
            {
                question: "Qual atributo melhora a acessibilidade em imagens?",
                options: ["alt", "title", "description", "aria-label"],
                correct: 0, points: 30
            },
            {
                question: "O que é Web Semântica em HTML?",
                options: ["Usar elementos que descrevem seu significado", "Adicionar semântica CSS", "Usar JavaScript semântico", "Implementar SEO avançado"],
                correct: 0, points: 30
            },
            {
                question: "Qual elemento é melhor para conteúdo relacionado?",
                options: ["<aside>", "<section>", "<div>", "<related>"],
                correct: 0, points: 30
            }
        ]
    },
    css: {
        easy: [
            {
                question: "O que significa CSS?",
                options: ["Computer Style Sheets", "Creative Style System", "Cascading Style Sheets", "Colorful Style Sheets"],
                correct: 2, points: 10
            },
            {
                question: "Qual propriedade é usada para mudar a cor do texto?",
                options: ["text-color", "font-color", "color", "text-style"],
                correct: 2, points: 10
            },
            {
                question: "Como comentar em CSS?",
                options: ["// comentário", "/* comentário */", "<!-- comentário -->", "# comentário"],
                correct: 1, points: 10
            },
            {
                question: "Qual propriedade controla o fundo?",
                options: ["background", "bg-color", "color-background", "background-color"],
                correct: 3, points: 10
            },
            {
                question: "Como centralizar texto?",
                options: ["text-align: center;", "align: center;", "text-center: true;", "center: text;"],
                correct: 0, points: 10
            }
        ],
        medium: [
            {
                question: "Qual propriedade é usada para criar espaço entre elementos?",
                options: ["spacing", "margin", "padding", "gap"],
                correct: 1, points: 20
            },
            {
                question: "Como centralizar um elemento com CSS?",
                options: ["text-align: center;", "margin: 0 auto;", "align: center;", "position: center;"],
                correct: 1, points: 20
            },
            {
                question: "O que faz z-index?",
                options: ["Controla ordem de empilhamento", "Controla tamanho do elemento", "Controla transparência", "Controla rotação"],
                correct: 0, points: 20
            },
            {
                question: "Qual unidade é relativa ao elemento pai?",
                options: ["em", "rem", "px", "vw"],
                correct: 0, points: 20
            },
            {
                question: "Como criar um seletor para classe 'menu'?",
                options: [".menu", "#menu", "menu", "*menu"],
                correct: 0, points: 20
            }
        ],
        hard: [
            {
                question: "Qual é a diferença entre display: none e visibility: hidden?",
                options: ["Nenhuma diferença", "display: none remove o elemento do fluxo, visibility: hidden apenas o esconde", "visibility: hidden remove o elemento do fluxo, display: none apenas o esconde", "Ambos removem o elemento do fluxo"],
                correct: 1, points: 30
            },
            {
                question: "O que é Flexbox?",
                options: ["Um método de layout unidimensional", "Um método de layout bidimensional", "Um tipo de display para imagens", "Uma propriedade para flexibilidade"],
                correct: 0, points: 30
            },
            {
                question: "O que é CSS Grid?",
                options: ["Método de layout bidimensional", "Método para grades de imagens", "Sistema de templates", "Framework CSS"],
                correct: 0, points: 30
            },
            {
                question: "O que faz @media query?",
                options: ["Aplica estilos baseado em condições", "Importa media files", "Cria animações", "Define variáveis CSS"],
                correct: 0, points: 30
            },
            {
                question: "Qual pseudo-classe seleciona primeiro filho?",
                options: [":first-child", ":first", ":child-first", ":first-of-type"],
                correct: 0, points: 30
            }
        ]
    },
    javascript: {
        easy: [
            {
                question: "Como declarar uma variável em JavaScript?",
                options: ["variable x;", "var x;", "v x;", "declare x;"],
                correct: 1, points: 10
            },
            {
                question: "Qual método é usado para imprimir no console?",
                options: ["print()", "console.log()", "log()", "display()"],
                correct: 1, points: 10
            },
            {
                question: "Como criar uma função?",
                options: ["function myFunc() {}", "func myFunc() {}", "def myFunc() {}", "method myFunc() {}"],
                correct: 0, points: 10
            },
            {
                question: "Qual operador verifica igualdade?",
                options: ["=", "==", "===", "!="],
                correct: 1, points: 10
            },
            {
                question: "Como adicionar um elemento a um array?",
                options: ["push()", "add()", "append()", "insert()"],
                correct: 0, points: 10
            }
        ],
        medium: [
            {
                question: "O que é uma função de callback?",
                options: ["Uma função que é chamada quando um evento ocorre", "Uma função que retorna um valor", "Uma função que chama a si mesma", "Uma função anônima"],
                correct: 0, points: 20
            },
            {
                question: "Qual método adiciona um elemento ao final de um array?",
                options: ["push()", "append()", "add()", "insert()"],
                correct: 0, points: 20
            },
            {
                question: "O que é JSON?",
                options: ["JavaScript Object Notation", "JavaScript Online Network", "Java Standard Object Notation", "JavaScript Organized Nodes"],
                correct: 0, points: 20
            },
            {
                question: "Como converter string para número?",
                options: ["Number()", "parseInt()", "String.toNumber()", "Todas as anteriores"],
                correct: 3, points: 20
            },
            {
                question: "O que é DOM?",
                options: ["Document Object Model", "Data Object Management", "Digital Object Model", "Document Online Model"],
                correct: 0, points: 20
            }
        ],
        hard: [
            {
                question: "O que é hoisting em JavaScript?",
                options: ["Elevação de variáveis e funções para o topo do escopo", "Uma técnica de otimização", "Um tipo de loop", "Um método de ordenação"],
                correct: 0, points: 30
            },
            {
                question: "Qual a diferença entre == e ===?",
                options: ["Nenhuma diferença", "== compara valor, === compara valor e tipo", "=== compara valor, == compara valor e tipo", "== é mais rápido que ==="],
                correct: 1, points: 30
            },
            {
                question: "O que é closure?",
                options: ["Função que tem acesso ao escopo externo", "Método para fechar aplicação", "Tipo de loop", "Método de debug"],
                correct: 0, points: 30
            },
            {
                question: "O que é promise?",
                options: ["Objeto que representa conclusão futura", "Método de promessa de código", "Tipo de variável", "Função assíncrona"],
                correct: 0, points: 30
            },
            {
                question: "O que é async/await?",
                options: ["Sintaxe para trabalhar com promises", "Método para esperar carregamento", "Tipo de função síncrona", "Framework JavaScript"],
                correct: 0, points: 30
            }
        ]
    },
    python: {
        easy: [
            {
                question: "Como imprimir texto em Python?",
                options: ["console.log()", "print()", "echo()", "System.out.println()"],
                correct: 1, points: 10
            },
            {
                question: "Como declarar uma variável em Python?",
                options: ["var x = 5", "let x = 5", "x = 5", "int x = 5"],
                correct: 2, points: 10
            },
            {
                question: "Qual é o operador para potência em Python?",
                options: ["^", "**", "pow()", "//"],
                correct: 1, points: 10
            },
            {
                question: "Como criar uma lista em Python?",
                options: ["[]", "{}", "()", "<>"],
                correct: 0, points: 10
            },
            {
                question: "Como criar um comentário em Python?",
                options: ["// comentário", "# comentário", "/* comentário */", "<!-- comentário -->"],
                correct: 1, points: 10
            }
        ],
        medium: [
            {
                question: "O que é uma lista em Python?",
                options: ["Uma coleção ordenada e mutável", "Uma coleção não ordenada", "Uma coleção imutável", "Uma estrutura de dados chave-valor"],
                correct: 0, points: 20
            },
            {
                question: "Como iterar sobre uma lista?",
                options: ["for item in list:", "foreach item in list:", "while item in list:", "iterate item in list:"],
                correct: 0, points: 20
            },
            {
                question: "O que é um dicionário em Python?",
                options: ["Estrutura chave-valor", "Lista ordenada", "Conjunto não ordenado", "Array multidimensional"],
                correct: 0, points: 20
            },
            {
                question: "Como criar uma função em Python?",
                options: ["function nome():", "def nome():", "func nome():", "method nome():"],
                correct: 1, points: 20
            },
            {
                question: "Qual módulo é usado para datas?",
                options: ["datetime", "date", "time", "calendar"],
                correct: 0, points: 20
            }
        ],
        hard: [
            {
                question: "O que é um decorador em Python?",
                options: ["Uma função que modifica outra função", "Um tipo de loop", "Um método de formatação de strings", "Uma classe especial"],
                correct: 0, points: 30
            },
            {
                question: "O que são list comprehensions?",
                options: ["Forma concisa de criar listas", "Método de filtragem", "Tipo de loop otimizado", "Estrutura de dados"],
                correct: 0, points: 30
            },
            {
                question: "O que é o GIL em Python?",
                options: ["Global Interpreter Lock", "General Interface Layer", "Global Import Library", "General Input Loader"],
                correct: 0, points: 30
            },
            {
                question: "Como funciona herança em Python?",
                options: ["class Filho(Pai):", "class Filho extends Pai", "class Filho implements Pai", "class Filho inherits Pai"],
                correct: 0, points: 30
            },
            {
                question: "O que são generators?",
                options: ["Funções que produzem sequência de valores", "Classes especiais", "Módulos de performance", "Decoradores avançados"],
                correct: 0, points: 30
            }
        ]
    },
    java: {
        easy: [
            {
                question: "Como imprimir texto em Java?",
                options: ["print()", "System.out.println()", "console.log()", "echo()"],
                correct: 1, points: 10
            },
            {
                question: "Como declarar uma variável inteira em Java?",
                options: ["int x = 5;", "var x = 5;", "integer x = 5;", "x = 5;"],
                correct: 0, points: 10
            },
            {
                question: "Qual palavra-chave define uma classe?",
                options: ["class", "Class", "type", "struct"],
                correct: 0, points: 10
            },
            {
                question: "Como criar um método em Java?",
                options: ["function nome() {}", "def nome() {}", "void nome() {}", "method nome() {}"],
                correct: 2, points: 10
            },
            {
                question: "Como criar um loop for em Java?",
                options: ["for(int i=0; i<10; i++)", "for i in range(10)", "for i=0 to 10", "loop i from 0 to 10"],
                correct: 0, points: 10
            }
        ],
        medium: [
            {
                question: "O que é uma classe em Java?",
                options: ["Um modelo para criar objetos", "Um tipo de variável", "Um método especial", "Uma estrutura de dados"],
                correct: 0, points: 20
            },
            {
                question: "O que é herança em Java?",
                options: ["extends", "inherits", "implements", "derives"],
                correct: 0, points: 20
            },
            {
                question: "O que é um construtor?",
                options: ["Método que inicializa objetos", "Tipo de variável", "Classe abstrata", "Interface"],
                correct: 0, points: 20
            },
            {
                question: "O que é ArrayList?",
                options: ["Lista redimensionável", "Array fixo", "Conjunto ordenado", "Mapa chave-valor"],
                correct: 0, points: 20
            },
            {
                question: "O que é um package?",
                options: ["Agrupamento de classes relacionadas", "Método de compressão", "Tipo de arquivo", "Interface gráfica"],
                correct: 0, points: 20
            }
        ],
        hard: [
            {
                question: "O que é polimorfismo em Java?",
                options: ["Capacidade de um objeto assumir muitas formas", "Herança múltipla", "Encapsulamento de dados", "Sobrecarga de operadores"],
                correct: 0, points: 30
            },
            {
                question: "O que são interfaces?",
                options: ["Contratos que classes implementam", "Classes abstratas", "Métodos estáticos", "Construtores"],
                correct: 0, points: 30
            },
            {
                question: "O que é multithreading?",
                options: ["Execução simultânea de múltiplas threads", "Múltiplas heranças", "Vários construtores", "Múltiplos packages"],
                correct: 0, points: 30
            },
            {
                question: "O que são exceções?",
                options: ["Eventos anormais durante execução", "Erros de compilação", "Métodos privados", "Classes internas"],
                correct: 0, points: 30
            },
            {
                question: "O que são generics?",
                options: ["Tipos parametrizados", "Métodos genéricos", "Classes abstratas", "Interfaces funcionais"],
                correct: 0, points: 30
            }
        ]
    }
};

// Sistema de Usuários com Base de Dados MySQL
class UserSystem {
    constructor() {
        this.currentUser = null;
        this.codeMirrorEditor = null;
        this.baseUrl = window.location.origin + '/codemaster/'; // Ajusta conforme a pasta do teu projeto
        this.initialize();
    }

    async initialize() {
        await this.checkLoginStatus();
        this.updateUI();
        this.setupAuthListeners();
        this.setupThemeToggle();
        this.loadThemePreference();
    }

    // Verificar se já está logado
    async checkLoginStatus() {
        const usuarioSalvo = localStorage.getItem('codemaster_user');
        if (usuarioSalvo) {
            this.currentUser = JSON.parse(usuarioSalvo);
            this.updateUI();
        } else {
            this.currentUser = await this.createGuestUser();
        }
    }

    // Criar utilizador convidado
    async createGuestUser() {
        return {
            id: 'guest',
            name: 'Convidado',
            points: 0,
            quizzesCompleted: 0,
            studyTime: 0,
            streak: 0,
            progress: {
                html: 0,
                css: 0,
                javascript: 0,
                python: 0,
                java: 0
            },
            achievements: [],
            quizHistory: []
        };
    }

    // REGISTAR NOVO UTILIZADOR (vai para a base de dados!)
    async register(name, email, password) {
        try {
            // Validar email
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                return { success: false, message: 'Email inválido' };
            }

            // Enviar para a base de dados
            const formData = new FormData();
            formData.append('nome', name);
            formData.append('email', email);
            formData.append('senha', password);

            const resposta = await fetch('api.php?acao=registar', {
                method: 'POST',
                body: formData
            });

            const dados = await resposta.json();

            if (dados.sucesso) {
                // Se registou com sucesso, faz login automaticamente
                return await this.login(email, password);
            } else {
                return { success: false, message: dados.mensagem };
            }
        } catch (error) {
            console.error('Erro no registo:', error);
            return { success: false, message: 'Erro de ligação ao servidor' };
        }
    }

    // LOGIN (verifica na base de dados!)
    async login(email, password) {
        try {
            const formData = new FormData();
            formData.append('email', email);
            formData.append('senha', password);

            const resposta = await fetch('api.php?acao=login', {
                method: 'POST',
                body: formData
            });

            const dados = await resposta.json();

            if (dados.sucesso) {
                // Guardar utilizador na sessão
                this.currentUser = this.formatUserData(dados.usuario);
                localStorage.setItem('codemaster_user', JSON.stringify(this.currentUser));
                
                this.updateUI();
                this.showNotification('Login realizado com sucesso!', 'success');
                this.hideAuthModal();
                
                // Desbloquear conquista de primeiro login
                if (!this.currentUser.achievements.includes('first_login')) {
                    this.unlockAchievement('first_login');
                }
                
                return { success: true, user: this.currentUser };
            } else {
                return { success: false, message: dados.mensagem };
            }
        } catch (error) {
            console.error('Erro no login:', error);
            return { success: false, message: 'Erro de ligação ao servidor' };
        }
    }

    // Formatar dados do utilizador vindo da base de dados
    formatUserData(user) {
        return {
            id: user.id,
            name: user.nome,
            email: user.email,
            points: parseInt(user.pontos) || 0,
            quizzesCompleted: 0,
            studyTime: 0,
            streak: 1,
            progress: {
                html: 0,
                css: 0,
                javascript: 0,
                python: 0,
                java: 0
            },
            achievements: [],
            quizHistory: []
        };
    }

    // Logout
    logout() {
        this.currentUser = this.createGuestUser();
        localStorage.removeItem('codemaster_user');
        this.updateUI();
        this.showNotification('Logout realizado com sucesso', 'info');
    }

    // Atualizar progresso do utilizador
    async updateUserProgress(language, percentage, points = 0) {
        if (this.currentUser.id === 'guest') return;

        this.currentUser.progress[language] = Math.max(
            this.currentUser.progress[language] || 0,
            percentage
        );

        if (points > 0) {
            this.currentUser.points += points;
            
            // Atualizar pontos na base de dados
            await this.updateUserPoints(this.currentUser.id, this.currentUser.points);
            
            if (this.currentUser.points >= 100 && !this.currentUser.achievements.includes('100_points')) {
                this.unlockAchievement('100_points');
            }
        }

        this.currentUser.studyTime += 5;
        localStorage.setItem('codemaster_user', JSON.stringify(this.currentUser));
        this.updateUI();
    }

    // Atualizar pontos na base de dados
    async updateUserPoints(userId, points) {
        try {
            const formData = new FormData();
            formData.append('user_id', userId);
            formData.append('pontos', points);

            await fetch('api.php?acao=atualizar_pontos', {
                method: 'POST',
                body: formData
            });
        } catch (error) {
            console.error('Erro ao atualizar pontos:', error);
        }
    }

    // Adicionar resultado de quiz
    async addQuizResult(quizData) {
        if (this.currentUser.id === 'guest') return;

        this.currentUser.quizzesCompleted++;
        this.currentUser.quizHistory.unshift({
            ...quizData,
            date: new Date().toISOString()
        });

        // Salvar resultado na base de dados
        await this.saveQuizResult(this.currentUser.id, quizData);

        if (this.currentUser.quizzesCompleted >= 5 && !this.currentUser.achievements.includes('quiz_master')) {
            this.unlockAchievement('quiz_master');
        }

        if (this.currentUser.quizHistory.length > 10) {
            this.currentUser.quizHistory = this.currentUser.quizHistory.slice(0, 10);
        }

        localStorage.setItem('codemaster_user', JSON.stringify(this.currentUser));
        this.updateDashboard();
    }

    // Salvar resultado do quiz na base de dados
    async saveQuizResult(userId, quizData) {
        try {
            const formData = new FormData();
            formData.append('user_id', userId);
            formData.append('linguagem', quizData.language);
            formData.append('dificuldade', quizData.difficulty);
            formData.append('pontuacao', quizData.score);
            formData.append('total_perguntas', quizData.totalQuestions);

            await fetch('api.php?acao=salvar_resultado', {
                method: 'POST',
                body: formData
            });
        } catch (error) {
            console.error('Erro ao salvar resultado:', error);
        }
    }

    // Desbloquear conquista
    unlockAchievement(achievementId) {
        if (!this.currentUser.achievements.includes(achievementId)) {
            this.currentUser.achievements.push(achievementId);
            localStorage.setItem('codemaster_user', JSON.stringify(this.currentUser));
            
            const achievementName = this.getAchievementName(achievementId);
            this.showAchievementNotification(`Conquista desbloqueada: ${achievementName}`);
        }
    }

    getAchievementName(achievementId) {
        const achievements = {
            'first_login': 'Primeiro Login',
            '100_points': '100 Pontos',
            'quiz_master': 'Mestre do Quiz'
        };
        return achievements[achievementId] || achievementId;
    }

    // Atualizar interface
    updateUI() {
        const userNameElement = document.getElementById('user-name');
        const userPointsElement = document.getElementById('user-points');
        const totalPointsElement = document.getElementById('total-points');
        const quizzesCompletedElement = document.getElementById('quizzes-completed');
        const studyTimeElement = document.getElementById('study-time');
        
        if (userNameElement) userNameElement.textContent = this.currentUser?.name || 'Convidado';
        if (userPointsElement) userPointsElement.textContent = this.currentUser?.points || 0;
        if (totalPointsElement) totalPointsElement.textContent = this.currentUser?.points || 0;
        if (quizzesCompletedElement) quizzesCompletedElement.textContent = this.currentUser?.quizzesCompleted || 0;
        if (studyTimeElement) studyTimeElement.textContent = Math.floor(this.currentUser?.studyTime || 0);
        
        const avatar = document.getElementById('user-avatar');
        if (avatar) {
            if (this.currentUser?.id === 'guest') {
                avatar.innerHTML = '<i class="bx bx-user"></i>';
            } else {
                const initials = this.currentUser.name.split(' ').map(n => n[0]).join('').toUpperCase();
                avatar.textContent = initials.substring(0, 2);
            }
        }

        this.updateProgressBars();
    }

    updateProgressBars() {
        const languages = ['html', 'css', 'javascript', 'python', 'java'];
        languages.forEach(lang => {
            const progress = this.currentUser?.progress[lang] || 0;
            const fill = document.getElementById(`${lang}-progress`);
            const percent = document.getElementById(`${lang}-percent`);
            
            if (fill) fill.style.width = `${progress}%`;
            if (percent) percent.textContent = `${Math.round(progress)}%`;
        });
    }

    updateDashboard() {
        const totalPointsDash = document.getElementById('total-points-dash');
        const totalQuizzesDash = document.getElementById('total-quizzes-dash');
        const totalTimeDash = document.getElementById('total-time-dash');
        const streakDash = document.getElementById('streak-dash');
        
        if (totalPointsDash) totalPointsDash.textContent = this.currentUser?.points || 0;
        if (totalQuizzesDash) totalQuizzesDash.textContent = this.currentUser?.quizzesCompleted || 0;
        if (totalTimeDash) totalTimeDash.textContent = Math.floor(this.currentUser?.studyTime || 0);
        if (streakDash) streakDash.textContent = this.currentUser?.streak || 0;

        this.updateHistoryTable();
        this.updateAchievementsList();
    }

    updateHistoryTable() {
        const tbody = document.getElementById('history-body');
        if (!tbody) return;

        tbody.innerHTML = '';
        const recentHistory = this.currentUser?.quizHistory?.slice(0, 5) || [];

        recentHistory.forEach(quiz => {
            const row = document.createElement('tr');
            const date = new Date(quiz.date).toLocaleDateString('pt-BR');
            
            row.innerHTML = `
                <td>${date}</td>
                <td>${quiz.language?.toUpperCase() || 'N/A'}</td>
                <td><span class="difficulty-badge">${quiz.difficulty || 'Médio'}</span></td>
                <td>${quiz.score || 0}</td>
                <td>${quiz.percentage || 0}%</td>
            `;
            tbody.appendChild(row);
        });
    }

    updateAchievementsList() {
        const container = document.getElementById('achievements-list');
        if (!container) return;

        const achievements = [
            { id: 'first_login', icon: 'bx-log-in', title: 'Primeiro Login', description: 'Entre no sistema pela primeira vez' },
            { id: '100_points', icon: 'bx-star', title: '100 Pontos', description: 'Alcance 100 pontos' },
            { id: 'quiz_master', icon: 'bx-brain', title: 'Mestre do Quiz', description: 'Complete 5 quizzes' }
        ];

        container.innerHTML = '';
        achievements.forEach(achievement => {
            const achieved = this.currentUser?.achievements?.includes(achievement.id) || false;
            const div = document.createElement('div');
            div.className = `achievement-item ${achieved ? 'achieved' : 'locked'}`;
            
            div.innerHTML = `
                <div class="achievement-icon">
                    <i class='bx ${achievement.icon}'></i>
                </div>
                <div class="achievement-info">
                    <h4>${achievement.title}</h4>
                    <p>${achievement.description}</p>
                </div>
                <div class="achievement-status">
                    ${achieved ? '<i class="bx bx-check"></i>' : '<i class="bx bx-lock"></i>'}
                </div>
            `;
            
            container.appendChild(div);
        });
    }

    setupAuthListeners() {
        const loginForm = document.getElementById('login-form');
        const registerForm = document.getElementById('register-form');
        const logoutBtn = document.getElementById('logout-btn');
        const themeToggle = document.getElementById('theme-toggle');
        const themeToggleEditor = document.getElementById('theme-toggle-editor');

        if (loginForm) {
            loginForm.addEventListener('submit', async (e) => {
                e.preventDefault();
                const email = document.getElementById('login-email').value.trim();
                const password = document.getElementById('login-password').value;
                
                if (!email || !password) {
                    this.showNotification('Preencha todos os campos', 'error');
                    return;
                }
                
                const result = await this.login(email, password);
                if (!result.success) {
                    this.showNotification(result.message, 'error');
                }
            });
        }

        if (registerForm) {
            registerForm.addEventListener('submit', async (e) => {
                e.preventDefault();
                const name = document.getElementById('register-name').value.trim();
                const email = document.getElementById('register-email').value.trim();
                const password = document.getElementById('register-password').value;
                
                if (!name || !email || !password) {
                    this.showNotification('Preencha todos os campos', 'error');
                    return;
                }
                
                if (password.length < 6) {
                    this.showNotification('A senha deve ter pelo menos 6 caracteres', 'error');
                    return;
                }
                
                const result = await this.register(name, email, password);
                if (!result.success) {
                    this.showNotification(result.message, 'error');
                }
            });
        }

        if (logoutBtn) {
            logoutBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.logout();
            });
        }

        // Tabs de autenticação
        document.querySelectorAll('.auth-tab').forEach(tab => {
            tab.addEventListener('click', () => {
                const tabId = tab.dataset.tab;
                this.switchAuthTab(tabId);
            });
        });

        // Fechar modal
        document.querySelector('.close-modal')?.addEventListener('click', () => {
            this.hideAuthModal();
        });

        // Alternância de tema
        if (themeToggle) {
            themeToggle.addEventListener('click', () => {
                this.toggleTheme();
            });
        }

        if (themeToggleEditor) {
            themeToggleEditor.addEventListener('click', () => {
                this.toggleEditorTheme();
            });
        }
    }

    setupThemeToggle() {
        const savedTheme = localStorage.getItem('codemaster_theme') || 'dark';
        this.applyTheme(savedTheme);
    }

    loadThemePreference() {
        const savedTheme = localStorage.getItem('codemaster_theme') || 'dark';
        this.applyTheme(savedTheme);
    }

    toggleTheme() {
        const currentTheme = document.body.getAttribute('data-theme') || 'dark';
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        this.applyTheme(newTheme);
        localStorage.setItem('codemaster_theme', newTheme);
    }

    applyTheme(theme) {
        document.body.setAttribute('data-theme', theme);
        
        if (this.codeMirrorEditor) {
            this.codeMirrorEditor.setOption('theme', theme === 'light' ? 'eclipse' : 'dracula');
        }
    }

    toggleEditorTheme() {
        if (!this.codeMirrorEditor) return;
        
        const currentTheme = this.codeMirrorEditor.getOption('theme');
        const newTheme = currentTheme === 'dracula' ? 'eclipse' : 'dracula';
        this.codeMirrorEditor.setOption('theme', newTheme);
        
        const icon = document.querySelector('#theme-toggle-editor i');
        if (icon) {
            icon.className = newTheme === 'eclipse' ? 'bx bx-sun' : 'bx bx-moon';
        }
    }

    switchAuthTab(tabId) {
        document.querySelectorAll('.auth-tab').forEach(tab => {
            tab.classList.toggle('active', tab.dataset.tab === tabId);
        });

        document.querySelectorAll('.auth-form').forEach(form => {
            form.classList.toggle('active', form.id === `${tabId}-form`);
        });
    }

    showAuthModal() {
        const modal = document.getElementById('auth-modal');
        if (modal) modal.classList.add('active');
    }

    hideAuthModal() {
        const modal = document.getElementById('auth-modal');
        if (modal) modal.classList.remove('active');
    }

    showNotification(message, type = 'info') {
        // Criar notificação simples
        const toast = document.createElement('div');
        toast.className = 'achievement-toast show';
        toast.style.background = type === 'success' ? 'linear-gradient(135deg, #10b981, #059669)' :
                                type === 'error' ? 'linear-gradient(135deg, #ef4444, #dc2626)' :
                                'linear-gradient(135deg, #6366f1, #4f46e5)';
        toast.innerHTML = `
            <div class="achievement-icon">
                <i class='bx ${type === 'success' ? 'bx-check' : type === 'error' ? 'bx-x' : 'bx-info-circle'}'></i>
            </div>
            <div class="achievement-content">
                <h4>${type === 'success' ? 'Sucesso' : type === 'error' ? 'Erro' : 'Informação'}</h4>
                <p>${message}</p>
            </div>
        `;
        
        document.body.appendChild(toast);
        
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => {
                if (toast.parentNode) {
                    toast.parentNode.removeChild(toast);
                }
            }, 300);
        }, 3000);
    }

    showAchievementNotification(message) {
        const toast = document.getElementById('achievement-toast');
        if (toast) {
            const messageElement = toast.querySelector('#achievement-message');
            if (messageElement) {
                messageElement.textContent = message;
            }
            
            toast.classList.add('show');
            
            setTimeout(() => {
                toast.classList.remove('show');
            }, 5000);
        }
    }
}

// Sistema de Quiz Principal
class QuizSystem {
    constructor(userSystem) {
        this.userSystem = userSystem;
        this.currentQuiz = [];
        this.currentQuestionIndex = 0;
        this.score = 0;
        this.userAnswers = [];
        this.timer = null;
        this.timeLeft = 60;
        this.quizMode = 'normal';
        this.initialize();
    }

    initialize() {
        this.setupEventListeners();
    }

    setupEventListeners() {
        // Modos de quiz
        document.querySelectorAll('.quiz-mode-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                this.setQuizMode(e.currentTarget.dataset.mode);
            });
        });

        // Iniciar quiz
        const startQuizBtn = document.getElementById('start-quiz');
        if (startQuizBtn) {
            startQuizBtn.addEventListener('click', () => {
                this.startQuiz();
            });
        }

        // Navegação
        const nextBtn = document.getElementById('next-btn');
        const prevBtn = document.getElementById('prev-btn');
        const submitBtn = document.getElementById('submit-btn');
        
        if (nextBtn) nextBtn.addEventListener('click', () => this.nextQuestion());
        if (prevBtn) prevBtn.addEventListener('click', () => this.prevQuestion());
        if (submitBtn) submitBtn.addEventListener('click', () => this.finishQuiz());

        // Reiniciar
        const restartBtn = document.getElementById('restart-btn');
        if (restartBtn) restartBtn.addEventListener('click', () => this.restartQuiz());

        // Desafios
        document.querySelectorAll('.challenge-start').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const type = e.currentTarget.dataset.type;
                this.startChallenge(type);
            });
        });
    }

    setQuizMode(mode) {
        this.quizMode = mode;
        
        document.querySelectorAll('.quiz-mode-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.mode === mode);
        });
        
        const timerDisplay = document.getElementById('timer-display');
        if (timerDisplay) {
            timerDisplay.style.display = mode === 'timed' ? 'flex' : 'none';
        }
    }

    startQuiz() {
        try {
            const language = document.getElementById('language-select').value;
            const difficulty = document.getElementById('difficulty-select').value;
            const questionCount = parseInt(document.getElementById('question-count').value);
            
            const langQuestions = questions[language];
            if (!langQuestions || !langQuestions[difficulty]) {
                this.showNotification('Nenhuma pergunta disponível para esta combinação', 'error');
                return;
            }
            
            // Selecionar perguntas aleatórias
            const availableQuestions = [...langQuestions[difficulty]];
            this.currentQuiz = [];
            
            const maxQuestions = Math.min(questionCount, availableQuestions.length);
            for (let i = 0; i < maxQuestions; i++) {
                if (availableQuestions.length === 0) break;
                const randomIndex = Math.floor(Math.random() * availableQuestions.length);
                this.currentQuiz.push(availableQuestions[randomIndex]);
                availableQuestions.splice(randomIndex, 1);
            }
            
            if (this.currentQuiz.length === 0) {
                this.showNotification('Perguntas insuficientes para iniciar o quiz', 'error');
                return;
            }
            
            // Resetar estado
            this.currentQuestionIndex = 0;
            this.score = 0;
            this.userAnswers = new Array(this.currentQuiz.length).fill(null);
            this.timeLeft = 60;
            
            // Atualizar UI
            document.getElementById('total-questions').textContent = this.currentQuiz.length;
            document.getElementById('current-score').textContent = this.score;
            document.getElementById('timer').textContent = this.timeLeft;
            
            // Mostrar quiz
            document.querySelector('.quiz-setup').style.display = 'none';
            document.getElementById('quiz-container').style.display = 'block';
            document.getElementById('results').style.display = 'none';
            
            // Iniciar timer se for modo cronometrado
            if (this.quizMode === 'timed') {
                this.startTimer();
            }
            
            this.loadQuestion();
            
        } catch (error) {
            console.error('Erro ao iniciar quiz:', error);
            this.showNotification('Erro ao iniciar o quiz. Tente novamente.', 'error');
        }
    }

    startTimer() {
        if (this.timer) clearInterval(this.timer);
        
        this.timer = setInterval(() => {
            this.timeLeft--;
            const timerElement = document.getElementById('timer');
            if (timerElement) timerElement.textContent = this.timeLeft;
            
            if (this.timeLeft <= 0) {
                this.timeUp();
            }
        }, 1000);
    }

    timeUp() {
        clearInterval(this.timer);
        this.showNotification('Tempo esgotado!', 'error');
        this.finishQuiz();
    }

    loadQuestion() {
        try {
            const question = this.currentQuiz[this.currentQuestionIndex];
            if (!question) return;
            
            document.getElementById('current-question').textContent = this.currentQuestionIndex + 1;
            document.getElementById('question-text').textContent = question.question;
            
            // Atualizar badges
            const difficulty = document.getElementById('difficulty-select').value;
            const difficultyBadge = document.getElementById('difficulty-badge');
            if (difficultyBadge) {
                difficultyBadge.textContent = this.getDifficultyText(difficulty);
                difficultyBadge.className = `difficulty-badge ${difficulty}`;
            }
            
            document.getElementById('points-badge').textContent = `${question.points} pts`;
            
            // Atualizar barra de progresso
            this.updateProgressBar();
            
            // Limpar e adicionar opções
            const optionsContainer = document.getElementById('options-container');
            optionsContainer.innerHTML = '';
            
            question.options.forEach((option, index) => {
                const optionEl = document.createElement('div');
                optionEl.className = 'option';
                if (this.userAnswers[this.currentQuestionIndex] === index) {
                    optionEl.classList.add('selected');
                }
                optionEl.textContent = option;
                optionEl.dataset.index = index;
                optionEl.addEventListener('click', (e) => this.selectOption(e));
                optionsContainer.appendChild(optionEl);
            });
            
            // Atualizar botões de navegação
            document.getElementById('prev-btn').disabled = this.currentQuestionIndex === 0;
            document.getElementById('next-btn').style.display = 
                this.currentQuestionIndex < this.currentQuiz.length - 1 ? 'flex' : 'none';
            document.getElementById('submit-btn').style.display = 
                this.currentQuestionIndex === this.currentQuiz.length - 1 ? 'flex' : 'none';
                
        } catch (error) {
            console.error('Erro ao carregar pergunta:', error);
        }
    }

    updateProgressBar() {
        const progress = ((this.currentQuestionIndex + 1) / this.currentQuiz.length) * 100;
        const progressFill = document.getElementById('progress-fill');
        if (progressFill) {
            progressFill.style.width = `${progress}%`;
        }
    }

    selectOption(e) {
        const selectedIndex = parseInt(e.target.dataset.index);
        this.userAnswers[this.currentQuestionIndex] = selectedIndex;
        
        const options = document.querySelectorAll('.option');
        options.forEach(option => option.classList.remove('selected'));
        e.target.classList.add('selected');
    }

    nextQuestion() {
        if (this.currentQuestionIndex < this.currentQuiz.length - 1) {
            this.currentQuestionIndex++;
            this.loadQuestion();
        }
    }

    prevQuestion() {
        if (this.currentQuestionIndex > 0) {
            this.currentQuestionIndex--;
            this.loadQuestion();
        }
    }

    finishQuiz() {
        try {
            if (this.timer) {
                clearInterval(this.timer);
                this.timer = null;
            }
            
            // Calcular pontuação
            this.score = 0;
            let correctCount = 0;
            
            this.currentQuiz.forEach((question, index) => {
                if (this.userAnswers[index] === question.correct) {
                    this.score += question.points;
                    correctCount++;
                }
            });
            
            // Bônus por tempo restante
            if (this.quizMode === 'timed' && this.timeLeft > 0) {
                const timeBonus = this.timeLeft * 2;
                this.score += timeBonus;
            }
            
            // Atualizar UI de resultados
            document.getElementById('final-score').textContent = this.score;
            document.getElementById('correct-answers').textContent = correctCount;
            document.getElementById('total-questions-result').textContent = this.currentQuiz.length;
            
            const percentage = Math.round((correctCount / this.currentQuiz.length) * 100);
            document.getElementById('percentage').textContent = `${percentage}%`;
            
            // Feedback
            const feedback = document.getElementById('feedback');
            const maxScore = this.currentQuiz.reduce((total, q) => total + q.points, 0);
            const scorePercentage = (this.score / maxScore) * 100;
            
            if (scorePercentage >= 80) {
                feedback.textContent = '🎉 Excelente! Você domina este assunto!';
                feedback.className = 'feedback good';
            } else if (scorePercentage >= 50) {
                feedback.textContent = '👍 Bom trabalho! Continue praticando!';
                feedback.className = 'feedback average';
            } else {
                feedback.textContent = '💡 Estude um pouco mais este tópico!';
                feedback.className = 'feedback poor';
            }
            
            // Mostrar resultados
            document.getElementById('quiz-container').style.display = 'none';
            document.getElementById('results').style.display = 'block';
            
            // Salvar no histórico do usuário
            if (this.userSystem.currentUser.id !== 'guest') {
                const quizData = {
                    language: document.getElementById('language-select').value,
                    difficulty: document.getElementById('difficulty-select').value,
                    score: this.score,
                    percentage: percentage,
                    totalQuestions: this.currentQuiz.length,
                    correctAnswers: correctCount,
                    mode: this.quizMode
                };
                
                this.userSystem.addQuizResult(quizData);
                this.userSystem.updateUserProgress(
                    quizData.language, 
                    Math.min(100, percentage), 
                    this.score
                );
            }
            
        } catch (error) {
            console.error('Erro ao finalizar quiz:', error);
            this.showNotification('Erro ao processar resultados', 'error');
        }
    }

    restartQuiz() {
        document.querySelector('.quiz-setup').style.display = 'block';
        document.getElementById('quiz-container').style.display = 'none';
        document.getElementById('results').style.display = 'none';
    }

    startChallenge(type) {
        switch(type) {
            case 'speed':
                this.startSpeedChallenge();
                break;
            case 'survival':
                this.startSurvivalChallenge();
                break;
            case 'marathon':
                this.startMarathonChallenge();
                break;
            default:
                this.showNotification('Tipo de desafio não implementado', 'error');
        }
    }

    startSpeedChallenge() {
        this.quizMode = 'timed';
        this.timeLeft = 60;
        
        document.getElementById('question-count').value = '10';
        document.getElementById('difficulty-select').value = 'medium';
        
        this.startQuiz();
    }

    startSurvivalChallenge() {
        this.showNotification('Modo sobrevivência em breve!', 'info');
    }

    startMarathonChallenge() {
        this.quizMode = 'normal';
        document.getElementById('question-count').value = '15';
        document.getElementById('difficulty-select').value = 'hard';
        this.startQuiz();
    }

    getDifficultyText(difficulty) {
        const difficultyMap = {
            'easy': 'Fácil',
            'medium': 'Médio',
            'hard': 'Difícil'
        };
        return difficultyMap[difficulty] || difficulty;
    }

    showNotification(message, type = 'info') {
        this.userSystem.showNotification(message, type);
    }
}

// Sistema de Navegação
class NavigationSystem {
    constructor(userSystem, quizSystem) {
        this.userSystem = userSystem;
        this.quizSystem = quizSystem;
        this.currentMode = 'study';
        this.initialize();
    }

    initialize() {
        this.setupEventListeners();
        this.switchMode('study');
        this.loadSavedMode();
    }

    setupEventListeners() {
        // Botões de modo
        document.querySelectorAll('.mode-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                this.switchMode(e.currentTarget.dataset.mode);
            });
        });

        // Links de navegação
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                this.switchMode(e.currentTarget.dataset.mode);
            });
        });

        // Links do footer
        document.querySelectorAll('.footer-links a').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const mode = e.currentTarget.dataset.mode;
                if (mode) {
                    this.switchMode(mode);
                }
            });
        });

        // Avatar do usuário
        const userAvatar = document.getElementById('user-avatar');
        if (userAvatar) {
            userAvatar.addEventListener('click', () => {
                if (this.userSystem.currentUser.id === 'guest') {
                    this.userSystem.showAuthModal();
                }
            });
        }
    }

    switchMode(mode) {
        this.currentMode = mode;
        
        // Atualizar botões ativos
        document.querySelectorAll('.mode-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.mode === mode);
        });
        
        // Esconder todos os modos
        const modes = ['study', 'quiz', 'practice', 'dashboard', 'challenge'];
        modes.forEach(m => {
            const element = document.querySelector(`.${m}-mode`);
            if (element) {
                element.classList.remove('active');
            }
        });
        
        // Mostrar modo atual
        const currentModeElement = document.querySelector(`.${mode}-mode`);
        if (currentModeElement) {
            currentModeElement.classList.add('active');
            
            // Executar inicializações específicas do modo
            if (mode === 'dashboard') {
                this.userSystem.updateDashboard();
            }
        }
        
        // Salvar modo atual
        this.saveCurrentMode();
        
        // Scroll para o topo
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    saveCurrentMode() {
        localStorage.setItem('codemaster_current_mode', this.currentMode);
    }

    loadSavedMode() {
        const savedMode = localStorage.getItem('codemaster_current_mode');
        if (savedMode) {
            this.switchMode(savedMode);
        }
    }
}

// Funções principais do site
class MainApp {
    constructor() {
        this.userSystem = null;
        this.quizSystem = null;
        this.navigation = null;
        this.initialize();
    }

    async initialize() {
        // Inicializar sistemas
        this.userSystem = new UserSystem();
        await this.userSystem.checkLoginStatus();
        
        this.quizSystem = new QuizSystem(this.userSystem);
        this.navigation = new NavigationSystem(this.userSystem, this.quizSystem);
        
        // Carregar recursos iniciais
        this.loadResources('html');
        this.setupLanguageCards();
        this.setupPracticeMode();
        this.initializeCodeMirror();
        
        // Verificar se usuário está logado
        if (this.userSystem.currentUser.id === 'guest') {
            setTimeout(() => {
                this.userSystem.showAuthModal();
            }, 1000);
        }
        
        // Inicializar animações
        this.initializeAnimations();
    }

    loadResources(language) {
        const selectedLanguageEl = document.getElementById('selected-language');
        const resourceListEl = document.getElementById('resource-list');
        
        if (!selectedLanguageEl || !resourceListEl) return;
        
        selectedLanguageEl.textContent = language.toUpperCase();
        resourceListEl.innerHTML = '';
        
        const langResources = resources[language] || [];
        const resourcesCountEl = document.getElementById('resources-count');
        if (resourcesCountEl) {
            resourcesCountEl.textContent = `${langResources.length} recursos disponíveis`;
        }
        
        // Usar DocumentFragment para melhor performance
        const fragment = document.createDocumentFragment();
        
        langResources.forEach(resource => {
            const resourceItem = document.createElement('div');
            resourceItem.className = 'resource-item';
            resourceItem.innerHTML = `
                <h3>${resource.title}</h3>
                <a href="${resource.url}" target="_blank" rel="noopener noreferrer">
                    <i class='bx bx-link-external'></i>
                    Acessar recurso
                </a>
            `;
            fragment.appendChild(resourceItem);
        });
        
        resourceListEl.appendChild(fragment);
    }

    setupLanguageCards() {
        document.querySelectorAll('.language-card').forEach(card => {
            card.addEventListener('click', () => {
                const language = card.dataset.lang;
                this.loadResources(language);
                
                // Adicionar animação
                card.style.transform = 'scale(0.95)';
                setTimeout(() => {
                    card.style.transform = 'scale(1)';
                }, 150);
            });
        });
    }

    setupPracticeMode() {
        // Configurar botões do editor
        const runBtn = document.getElementById('run-code');
        const clearBtn = document.getElementById('clear-output');
        const resetBtn = document.getElementById('reset-code');
        const saveBtn = document.getElementById('save-code');
        
        if (runBtn) {
            runBtn.addEventListener('click', () => {
                this.executeCode();
            });
        }
        
        if (clearBtn) {
            clearBtn.addEventListener('click', () => {
                const output = document.getElementById('code-output');
                if (output) {
                    output.srcdoc = '';
                }
            });
        }
        
        if (resetBtn) {
            resetBtn.addEventListener('click', () => {
                this.resetEditor();
            });
        }
        
        if (saveBtn) {
            saveBtn.addEventListener('click', () => {
                this.saveCode();
            });
        }
        
        // Desafios
        document.querySelectorAll('.challenge-start-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const challengeId = e.target.closest('.challenge-card').dataset.challenge;
                this.loadChallenge(challengeId);
            });
        });
        
        // Mudança de linguagem no editor
        const editorLanguageSelect = document.getElementById('editor-language');
        if (editorLanguageSelect) {
            editorLanguageSelect.addEventListener('change', () => {
                this.changeEditorLanguage();
            });
        }
    }

    initializeCodeMirror() {
        const codeEditor = document.getElementById('code-editor');
        if (!codeEditor) return;
        
        // Inicializar CodeMirror
        const savedTheme = localStorage.getItem('codemaster_theme') || 'dark';
        const editorTheme = savedTheme === 'light' ? 'eclipse' : 'dracula';
        
        this.userSystem.codeMirrorEditor = CodeMirror(codeEditor, {
            value: `<!DOCTYPE html>
<html>
<head>
    <title>Meu Código</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        h1 {
            text-align: center;
        }
    </style>
</head>
<body>
    <h1>Olá Mundo!</h1>
    <p>Bem-vindo ao editor de código CodeMaster Pro!</p>
</body>
</html>`,
            mode: "htmlmixed",
            theme: editorTheme,
            lineNumbers: true,
            lineWrapping: true,
            autofocus: true,
            indentUnit: 2,
            tabSize: 2
        });
    }

    changeEditorLanguage() {
        if (!this.userSystem.codeMirrorEditor) return;
        
        const language = document.getElementById('editor-language').value;
        let mode;
        
        switch(language) {
            case 'html':
                mode = 'htmlmixed';
                break;
            case 'css':
                mode = 'css';
                break;
            case 'javascript':
                mode = 'javascript';
                break;
            default:
                mode = 'htmlmixed';
        }
        
        this.userSystem.codeMirrorEditor.setOption('mode', mode);
    }

    executeCode() {
        if (!this.userSystem.codeMirrorEditor) return;
        
        const language = document.getElementById('editor-language').value;
        const code = this.userSystem.codeMirrorEditor.getValue();
        const outputFrame = document.getElementById('code-output');
        
        if (!outputFrame) return;
        
        let content = '';
        
        switch(language) {
            case 'html':
                content = code;
                break;
            case 'css':
                content = `
                    <!DOCTYPE html>
                    <html>
                    <head>
                        <style>
                            ${code}
                        </style>
                    </head>
                    <body>
                        <div class="demo">
                            <h1>Preview do CSS</h1>
                            <p>Seu CSS foi aplicado a este conteúdo.</p>
                            <div class="box">Caixa de exemplo</div>
                        </div>
                    </body>
                    </html>
                `;
                break;
            case 'javascript':
                content = `
                    <!DOCTYPE html>
                    <html>
                    <head>
                        <style>
                            body {
                                font-family: Arial, sans-serif;
                                padding: 20px;
                                background: #f5f5f5;
                            }
                            #output {
                                margin-top: 20px;
                                padding: 20px;
                                background: white;
                                border-radius: 5px;
                                border: 1px solid #ddd;
                            }
                            button {
                                padding: 10px 20px;
                                background: #6366f1;
                                color: white;
                                border: none;
                                border-radius: 5px;
                                cursor: pointer;
                                margin: 5px;
                            }
                        </style>
                    </head>
                    <body>
                        <h1>Output do JavaScript</h1>
                        <div id="output"></div>
                        <button onclick="runUserCode()">Executar Código</button>
                        <script>
                            const outputDiv = document.getElementById('output');
                            
                            function runUserCode() {
                                outputDiv.innerHTML = '';
                                try {
                                    ${code}
                                } catch(error) {
                                    outputDiv.innerHTML = '<p style="color: red;">Erro: ' + error.message + '</p>';
                                }
                            }
                            
                            // Execução inicial
                            runUserCode();
                        </script>
                    </body>
                    </html>
                `;
                break;
        }
        
        outputFrame.srcdoc = content;
        
        // Registrar atividade
        if (this.userSystem.currentUser.id !== 'guest') {
            this.userSystem.updateUserProgress(language, 5, 10);
        }
    }

    resetEditor() {
        if (!this.userSystem.codeMirrorEditor) return;
        
        const language = document.getElementById('editor-language').value;
        let defaultCode = '';
        
        switch(language) {
            case 'html':
                defaultCode = `<!DOCTYPE html>
<html>
<head>
    <title>Meu Código</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
        }
        h1 {
            color: #333;
        }
    </style>
</head>
<body>
    <h1>Olá Mundo!</h1>
    <p>Comece a codificar aqui...</p>
</body>
</html>`;
                break;
            case 'css':
                defaultCode = `/* Seu CSS aqui */
body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 20px;
    background: #f0f0f0;
}

h1 {
    color: #333;
    text-align: center;
}

.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
    background: white;
    border-radius: 10px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}`;
                break;
            case 'javascript':
                defaultCode = `// Seu código JavaScript aqui
console.log('Olá Mundo!');

// Função de exemplo
function saudacao(nome) {
    return 'Olá, ' + nome + '!';
}

// Execução inicial
document.addEventListener('DOMContentLoaded', function() {
    console.log('Página carregada!');
    console.log(saudacao('Desenvolvedor'));
});`;
                break;
        }
        
        this.userSystem.codeMirrorEditor.setValue(defaultCode);
    }

    saveCode() {
        if (!this.userSystem.codeMirrorEditor) return;
        
        const code = this.userSystem.codeMirrorEditor.getValue();
        const language = document.getElementById('editor-language').value;
        
        // Salvar no localStorage
        localStorage.setItem(`codemaster_saved_code_${language}`, code);
        this.userSystem.showNotification('Código salvo localmente', 'success');
    }

    loadChallenge(challengeId) {
        const challenges = {
            1: {
                title: 'Calculadora Simples',
                description: 'Crie uma calculadora básica com HTML, CSS e JavaScript',
                html: `<div class="calculator">
  <h2>Calculadora</h2>
  <div class="display" id="display">0</div>
  <div class="buttons">
    <button class="btn">7</button>
    <button class="btn">8</button>
    <button class="btn">9</button>
    <button class="btn operator">+</button>
    <button class="btn">4</button>
    <button class="btn">5</button>
    <button class="btn">6</button>
    <button class="btn operator">-</button>
    <button class="btn">1</button>
    <button class="btn">2</button>
    <button class="btn">3</button>
    <button class="btn operator">*</button>
    <button class="btn clear">C</button>
    <button class="btn">0</button>
    <button class="btn equals">=</button>
    <button class="btn operator">/</button>
  </div>
</div>`,
                css: `.calculator {
  max-width: 300px;
  margin: 50px auto;
  padding: 20px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-radius: 20px;
  box-shadow: 0 10px 40px rgba(0,0,0,0.3);
}

.display {
  background: rgba(255,255,255,0.1);
  padding: 20px;
  text-align: right;
  font-size: 2rem;
  color: white;
  margin-bottom: 20px;
  border-radius: 10px;
  min-height: 60px;
  backdrop-filter: blur(10px);
}

.buttons {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 10px;
}

.btn {
  padding: 15px;
  font-size: 1.2rem;
  border: none;
  border-radius: 10px;
  cursor: pointer;
  background: rgba(255,255,255,0.1);
  color: white;
  transition: all 0.3s;
  backdrop-filter: blur(5px);
}

.btn:hover {
  background: rgba(255,255,255,0.2);
  transform: translateY(-2px);
}

.btn.operator {
  background: rgba(245, 158, 11, 0.3);
}

.btn.clear {
  background: rgba(239, 68, 68, 0.3);
}

.btn.equals {
  background: rgba(16, 185, 129, 0.3);
  grid-column: span 2;
}`,
                js: `// Código JavaScript para a calculadora
const display = document.getElementById('display');
let currentInput = '0';
let previousInput = '';
let operator = '';
let waitingForNewInput = false;

// Configurar event listeners
document.querySelectorAll('.btn').forEach(button => {
  button.addEventListener('click', (e) => {
    const value = e.target.textContent;
    
    if (button.classList.contains('clear')) {
      clear();
    } else if (button.classList.contains('operator')) {
      handleOperator(value);
    } else if (button.classList.contains('equals')) {
      calculate();
    } else {
      handleNumber(value);
    }
  });
});

function handleNumber(number) {
  if (waitingForNewInput) {
    currentInput = number;
    waitingForNewInput = false;
  } else {
    currentInput = currentInput === '0' ? number : currentInput + number;
  }
  updateDisplay();
}

function handleOperator(op) {
  if (previousInput && !waitingForNewInput) {
    calculate();
  }
  previousInput = currentInput;
  operator = op;
  waitingForNewInput = true;
}

function calculate() {
  let result;
  const prev = parseFloat(previousInput);
  const current = parseFloat(currentInput);
  
  if (isNaN(prev) || isNaN(current)) return;
  
  switch(operator) {
    case '+':
      result = prev + current;
      break;
    case '-':
      result = prev - current;
      break;
    case '*':
      result = prev * current;
      break;
    case '/':
      result = current !== 0 ? prev / current : 'Erro';
      break;
    default:
      return;
  }
  
  currentInput = result.toString();
  operator = '';
  previousInput = '';
  waitingForNewInput = true;
  updateDisplay();
}

function clear() {
  currentInput = '0';
  previousInput = '';
  operator = '';
  waitingForNewInput = false;
  updateDisplay();
}

function updateDisplay() {
  display.textContent = currentInput;
}`
            }
        };
        
        const challenge = challenges[challengeId];
        if (!challenge) {
            this.userSystem.showNotification('Desafio não encontrado', 'error');
            return;
        }
        
        // Mostrar informações do desafio
        this.userSystem.showNotification(`Desafio: ${challenge.title} - ${challenge.description}`, 'info');
        
        // Mudar para modo prática
        this.navigation.switchMode('practice');
        
        // Carregar código no editor
        if (this.userSystem.codeMirrorEditor) {
            this.userSystem.codeMirrorEditor.setValue(challenge.html);
        }
    }

    initializeAnimations() {
        // Animar cards de linguagem
        const cards = document.querySelectorAll('.language-card');
        cards.forEach((card, index) => {
            card.style.opacity = '0';
            card.style.transform = 'translateY(20px)';
            
            setTimeout(() => {
                card.style.transition = 'all 0.5s ease';
                card.style.opacity = '1';
                card.style.transform = 'translateY(0)';
            }, index * 100);
        });
    }
}

// Inicializar a aplicação quando o DOM estiver carregado
document.addEventListener('DOMContentLoaded', () => {
    try {
        window.app = new MainApp();
    } catch (error) {
        console.error('Erro ao inicializar aplicação:', error);
        
        // Mostrar mensagem de erro amigável
        const errorMessage = document.createElement('div');
        errorMessage.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            background: #ef4444;
            color: white;
            padding: 1rem;
            text-align: center;
            z-index: 9999;
        `;
        errorMessage.textContent = 'Erro ao carregar a aplicação. Por favor, recarregue a página.';
        document.body.appendChild(errorMessage);
    }
});