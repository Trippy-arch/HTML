<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=utf-8");

require_once 'conexao.php';

$acao = $_GET['acao'] ?? '';

switch($acao) {
    
    case 'registar':
        $nome = $_POST['nome'] ?? '';
        $email = $_POST['email'] ?? '';
        $senha = $_POST['senha'] ?? '';
        
        if (empty($nome) || empty($email) || empty($senha)) {
            echo json_encode([
                'sucesso' => false, 
                'mensagem' => 'Todos os campos são obrigatórios'
            ]);
            exit;
        }
        
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo json_encode([
                'sucesso' => false, 
                'mensagem' => 'Email inválido'
            ]);
            exit;
        }
        
        $check_sql = "SELECT id FROM usuarios WHERE email = ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("s", $email);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();
        
        if ($check_result->num_rows > 0) {
            echo json_encode([
                'sucesso' => false, 
                'mensagem' => 'Este email já está registado'
            ]);
            $check_stmt->close();
            exit;
        }
        $check_stmt->close();
        
        $senha_hash = md5($senha);
        
        $sql = "INSERT INTO usuarios (nome, email, senha, pontos) VALUES (?, ?, ?, 0)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sss", $nome, $email, $senha_hash);
        
        if ($stmt->execute()) {
            $novo_id = $stmt->insert_id;
            
            echo json_encode([
                'sucesso' => true,
                'mensagem' => 'Utilizador registado com sucesso',
                'usuario' => [
                    'id' => $novo_id,
                    'nome' => $nome,
                    'email' => $email,
                    'pontos' => 0
                ]
            ]);
        } else {
            echo json_encode([
                'sucesso' => false,
                'mensagem' => 'Erro ao registar: ' . $conn->error
            ]);
        }
        
        $stmt->close();
        break;
    
    case 'login':
        $email = $_POST['email'] ?? '';
        $senha = $_POST['senha'] ?? '';
        
        if (empty($email) || empty($senha)) {
            echo json_encode([
                'sucesso' => false, 
                'mensagem' => 'Email e senha são obrigatórios'
            ]);
            exit;
        }
        
        $senha_hash = md5($senha);
        
        $sql = "SELECT id, nome, email, pontos FROM usuarios WHERE email = ? AND senha = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $email, $senha_hash);
        $stmt->execute();
        $resultado = $stmt->get_result();
        
        if ($resultado->num_rows > 0) {
            $usuario = $resultado->fetch_assoc();
            
            echo json_encode([
                'sucesso' => true,
                'mensagem' => 'Login bem-sucedido',
                'usuario' => $usuario
            ]);
        } else {
            echo json_encode([
                'sucesso' => false,
                'mensagem' => 'Email ou senha incorretos'
            ]);
        }
        
        $stmt->close();
        break;
    
    case 'atualizar_pontos':
        $user_id = $_POST['user_id'] ?? 0;
        $pontos = $_POST['pontos'] ?? 0;
        
        if ($user_id == 0) {
            echo json_encode([
                'sucesso' => false,
                'mensagem' => 'ID de utilizador inválido'
            ]);
            exit;
        }
        
        $sql = "UPDATE usuarios SET pontos = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ii", $pontos, $user_id);
        
        if ($stmt->execute()) {
            echo json_encode([
                'sucesso' => true,
                'mensagem' => 'Pontos atualizados com sucesso'
            ]);
        } else {
            echo json_encode([
                'sucesso' => false,
                'mensagem' => 'Erro ao atualizar pontos: ' . $conn->error
            ]);
        }
        
        $stmt->close();
        break;
    
    case 'salvar_resultado':
        $user_id = $_POST['user_id'] ?? 0;
        $linguagem = $_POST['linguagem'] ?? '';
        $dificuldade = $_POST['dificuldade'] ?? '';
        $pontuacao = $_POST['pontuacao'] ?? 0;
        $total_perguntas = $_POST['total_perguntas'] ?? 0;
        
        if ($user_id == 0) {
            echo json_encode([
                'sucesso' => false,
                'mensagem' => 'ID de utilizador inválido'
            ]);
            exit;
        }
        
        $sql = "INSERT INTO quiz_resultados (usuario_id, linguagem, dificuldade, pontuacao, total_perguntas) 
                VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("issii", $user_id, $linguagem, $dificuldade, $pontuacao, $total_perguntas);
        
        if ($stmt->execute()) {
            echo json_encode([
                'sucesso' => true,
                'mensagem' => 'Resultado salvo com sucesso'
            ]);
        } else {
            echo json_encode([
                'sucesso' => false,
                'mensagem' => 'Erro ao salvar resultado: ' . $conn->error
            ]);
        }
        
        $stmt->close();
        break;
    
    case 'historico':
        $user_id = $_GET['user_id'] ?? 0;
        
        if ($user_id == 0) {
            echo json_encode([
                'sucesso' => false,
                'mensagem' => 'ID de utilizador inválido'
            ]);
            exit;
        }
        
        $sql = "SELECT * FROM quiz_resultados 
                WHERE usuario_id = ? 
                ORDER BY data DESC 
                LIMIT 10";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $resultado = $stmt->get_result();
        
        $historico = [];
        while ($row = $resultado->fetch_assoc()) {
            $historico[] = $row;
        }
        
        echo json_encode([
            'sucesso' => true,
            'historico' => $historico
        ]);
        
        $stmt->close();
        break;
    
    case 'progresso':
        $user_id = $_GET['user_id'] ?? 0;
        
        if ($user_id == 0) {
            echo json_encode([
                'sucesso' => false,
                'mensagem' => 'ID de utilizador inválido'
            ]);
            exit;
        }
        
        $sql = "SELECT * FROM progresso WHERE usuario_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $resultado = $stmt->get_result();
        
        $progresso = [];
        while ($row = $resultado->fetch_assoc()) {
            $progresso[$row['linguagem']] = $row['porcentagem'];
        }
        
        echo json_encode([
            'sucesso' => true,
            'progresso' => $progresso
        ]);
        
        $stmt->close();
        break;
    
    case 'atualizar_progresso':
        $user_id = $_POST['user_id'] ?? 0;
        $linguagem = $_POST['linguagem'] ?? '';
        $porcentagem = $_POST['porcentagem'] ?? 0;
        
        if ($user_id == 0 || empty($linguagem)) {
            echo json_encode([
                'sucesso' => false,
                'mensagem' => 'Dados inválidos'
            ]);
            exit;
        }
        
        $check_sql = "SELECT id FROM progresso WHERE usuario_id = ? AND linguagem = ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("is", $user_id, $linguagem);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();
        
        if ($check_result->num_rows > 0) {
            $sql = "UPDATE progresso SET porcentagem = ? WHERE usuario_id = ? AND linguagem = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("iis", $porcentagem, $user_id, $linguagem);
        } else {
            $sql = "INSERT INTO progresso (usuario_id, linguagem, porcentagem) VALUES (?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("isi", $user_id, $linguagem, $porcentagem);
        }
        
        if ($stmt->execute()) {
            echo json_encode([
                'sucesso' => true,
                'mensagem' => 'Progresso atualizado com sucesso'
            ]);
        } else {
            echo json_encode([
                'sucesso' => false,
                'mensagem' => 'Erro ao atualizar progresso: ' . $conn->error
            ]);
        }
        
        $stmt->close();
        $check_stmt->close();
        break;
    
    case 'leaderboard':
        $sql = "SELECT nome, pontos FROM usuarios ORDER BY pontos DESC LIMIT 10";
        $resultado = $conn->query($sql);
        
        $leaderboard = [];
        $posicao = 1;
        while ($row = $resultado->fetch_assoc()) {
            $row['posicao'] = $posicao++;
            $leaderboard[] = $row;
        }
        
        echo json_encode([
            'sucesso' => true,
            'leaderboard' => $leaderboard
        ]);
        break;
    
    default:
        echo json_encode([
            'sucesso' => false,
            'mensagem' => 'Ação não encontrada: ' . $acao
        ]);
        break;
}

$conn->close();
?>