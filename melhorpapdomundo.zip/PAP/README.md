# CodeMaster Pro - Modo Demo

Plataforma interativa de estudo de programação em **modo demonstração**. Sistema de usuários desabilitado - gerencie tudo via phpMyAdmin.

## ⚠️ Modo Demonstração

**Importante:** O sistema de autenticação está desabilitado. Para funcionalidades completas:

1. Use o phpMyAdmin para criar/gerenciar usuários
2. Usuário admin: `admin@codemaster.com` / `admin123`
3. Todas as operações de usuário devem ser feitas diretamente no banco de dados

## Funcionalidades Disponíveis

✅ **Recursos de Estudo** - Visualização de conteúdos  
✅ **Editor de Código** - Teste de programação  
✅ **Interface Completa** - Navegação e design  
❌ **Sistema de Usuários** - Desabilitado  
❌ **Conquistas** - Desabilitado  
❌ **Perfil** - Desabilitado

## Descrição

CodeMaster Pro é uma aplicação web completa para aprendizado de programação, oferecendo:

- **Modo Estudo**: Recursos educacionais organizados por linguagem
- **Modo Quiz**: Testes interativos com diferentes níveis de dificuldade
- **Editor de Código**: Ambiente online para prática de programação
- **Dashboard**: Acompanhamento de progresso e estatísticas
- **Modo Desafio**: Competições cronometradas
- **Sistema de Conquistas**: Gamificação para motivar o aprendizado

## Tecnologias Utilizadas

- **Frontend**: HTML5, CSS3, JavaScript (ES6+)
- **Backend**: PHP 7+
- **Banco de Dados**: MySQL
- **Bibliotecas**: CodeMirror (editor de código), BoxIcons (ícones)

## Estrutura do Projeto

```
/
├── public/                 # Arquivos públicos (frontend)
│   ├── index.html         # Página principal
│   ├── css/
│   │   └── style.css      # Estilos da aplicação
│   └── js/
│       └── script.js      # Lógica JavaScript
├── api/                   # API backend
│   └── api.php           # Pontos de extremidade da API
├── config/               # Configurações
│   └── conexao.php       # Conexão com banco de dados
├── docs/                 # Documentação
│   ├── Importante.txt    # Notas importantes do projeto
│   └── Gerenciamento-Usuarios.md # Como gerenciar usuários via phpMyAdmin
└── README.md             # Este arquivo
```

## Instalação e Configuração

### Pré-requisitos

- Servidor web (Apache/Nginx) com suporte a PHP 7+
- MySQL/MariaDB
- XAMPP ou similar para desenvolvimento local

### Passos de Instalação

1. **Configure o banco de dados**:
   - Execute o script `setup.sql` no phpMyAdmin
   - Criará tabelas e usuário admin automaticamente

2. **Acesse a aplicação**:
   - `http://localhost/codemaster/public/`
   - Modo demo ativado automaticamente

3. **Gerencie usuários via phpMyAdmin**:
   - Acesse `http://localhost/phpmyadmin`
   - Use a tabela `usuarios` para CRUD completo
   - Usuário admin já criado: `admin@codemaster.com`

### ⚠️ Sistema de Autenticação

**DESABILITADO** - Não use os formulários de login/registro da interface.  
**Use apenas o phpMyAdmin** para gerenciar usuários.

### Estrutura de Arquivos Adicionais

- `.env.example`: Exemplo de configuração de ambiente
- `setup.sql`: Script para criar tabelas e dados iniciais
- `.htaccess`: Configurações do Apache (segurança, cache, etc.)
- `testar.php`: Página de teste da conexão com banco de dados
- `package.json`: Metadados do projeto (compatibilidade com ferramentas)
- `Makefile`: Comandos úteis para desenvolvimento
- `docs/Gerenciamento-Usuarios.md`: **Guia completo para gerenciar usuários via phpMyAdmin**

## Funcionalidades

### ❌ Autenticação (Desabilitada)
- Sistema de login/logout desabilitado
- Gerencie usuários diretamente no phpMyAdmin

### ✅ Aprendizado
- Recursos organizados por linguagem (HTML, CSS, JavaScript, Python, Java)
- Editor de código online com CodeMirror
- Modo estudo com conteúdos educacionais
- Modo quiz (funciona em modo demo)
- Dashboard de progresso (limitado)

### ❌ Gamificação (Desabilitada)
- Sistema de conquistas desabilitado
- Sistema de pontos desabilitado
- Perfil de usuário desabilitado

## Desenvolvimento

Para contribuir ou modificar o projeto:

1. **Configuração inicial**: Execute `make setup` para ver instruções
2. **Faça alterações** nos arquivos apropriados
3. **Teste localmente** com XAMPP ou servidor similar
4. **Execute testes** acessando `testar.php`
5. **Gerencie usuários** via phpMyAdmin
6. **Atualize a documentação** se necessário

### ⚠️ Limitações do Modo Demo

- Sistema de autenticação desabilitado
- Funcionalidades de usuário não funcionam
- Use phpMyAdmin para todas as operações de usuário
- Interface mostra "Modo Demo" em todas as seções de usuário

## Autor

Projeto desenvolvido como PAP (Projeto de Aptidão Profissional).

## Licença

Este projeto é para fins educacionais.