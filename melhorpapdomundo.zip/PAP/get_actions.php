<?php

function handleGetAction($acao, $conn) {
    switch ($acao) {
        case 'teste':
            echo json_encode([
                'sucesso' => true,
                'mensagem' => 'API está a funcionar corretamente!',
                'php_version' => phpversion(),
                'server_time' => date('Y-m-d H:i:s'),
                'conexao_bd' => $conn ? 'OK' : 'Erro'
            ]);
            return true;

        case 'debug':
            echo json_encode([
                'conexao' => $conn ? 'OK' : 'Erro',
                'tabelas' => $conn
                    ? ($conn->query("SHOW TABLES LIKE 'usuarios'")->num_rows > 0
                        ? 'usuarios existe'
                        : 'usuarios NÃO existe')
                    : 'Sem conexão'
            ]);
            return true;

        case 'verificar_sessao':
            if (usuarioLogado()) {
                $user = getUsuarioAtual($conn);
                echo json_encode([
                    'sucesso' => true,
                    'logado' => true,
                    'dados' => $user
                ]);
            } else {
                echo json_encode([
                    'sucesso' => true,
                    'logado' => false
                ]);
            }
            return true;

        case 'leaderboard':
            $sql = "SELECT id, nome, pontos
                    FROM usuarios
                    ORDER BY pontos DESC
                    LIMIT 10";

            $res = $conn->query($sql);
            $data = [];

            if ($res) {
                while ($row = $res->fetch_assoc()) {
                    $data[] = $row;
                }
            }

            echo json_encode([
                'sucesso' => true,
                'dados' => $data
            ]);
            return true;

        case 'get_historico':
            if (!usuarioLogado()) {
                naoAutorizado();
            }

            $usuario_id = $_SESSION['usuario_id'];

            $sql = "SELECT *
                    FROM quiz_resultados
                    WHERE usuario_id = ?
                    ORDER BY data DESC
                    LIMIT 20";

            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $usuario_id);
            $stmt->execute();
            $res = $stmt->get_result();

            $data = [];
            if ($res) {
                while ($row = $res->fetch_assoc()) {
                    $data[] = $row;
                }
            }

            echo json_encode([
                'sucesso' => true,
                'dados' => $data
            ]);
            return true;

        case 'get_progresso':
            if (!usuarioLogado()) {
                naoAutorizado();
            }

            $usuario_id = $_SESSION['usuario_id'];
            $linguagens = ['html', 'css', 'javascript', 'python', 'java'];
            $progresso = [];

            foreach ($linguagens as $lang) {
                $progresso[$lang] = 0;
                $sql = "SELECT porcentagem
                        FROM progresso
                        WHERE usuario_id = ? AND linguagem = ?";

                $stmt = $conn->prepare($sql);
                $stmt->bind_param("is", $usuario_id, $lang);
                $stmt->execute();
                $res = $stmt->get_result();

                if ($row = $res->fetch_assoc()) {
                    $progresso[$lang] = $row['porcentagem'];
                }
            }

            echo json_encode([
                'sucesso' => true,
                'dados' => $progresso
            ]);
            return true;

        case 'perfil':
            $user = getUsuarioAtual($conn);
            echo json_encode([
                'sucesso' => true,
                'dados' => $user
            ]);
            return true;

        default:
            return false;
    }
}
