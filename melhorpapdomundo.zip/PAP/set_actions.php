<?php

function handleSetAction($acao, $conn) {
    switch ($acao) {
        case 'login':
            $email = trim($_POST['email'] ?? '');
            $senha = $_POST['senha'] ?? '';

            if (!$email || !$senha) {
                echo json_encode([
                    'sucesso' => false,
                    'mensagem' => 'Campos obrigatórios'
                ]);
                return true;
            }

            $sql = "SELECT id, nome, email, pontos, tipo, bio, streak, ultimo_login, senha
                    FROM usuarios
                    WHERE email = ?";

            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $res = $stmt->get_result();

            if ($res->num_rows === 0) {
                echo json_encode([
                    'sucesso' => false,
                    'mensagem' => 'Email ou senha incorretos'
                ]);
                return true;
            }

            $user = $res->fetch_assoc();
            $stored = $user['senha'] ?? '';

            $authenticated = false;
            if ($stored && password_verify($senha, $stored)) {
                $authenticated = true;
            } elseif ($stored && md5($senha) === $stored) {
                // Legacy MD5 hash detected — rehash to stronger algorithm
                $newHash = password_hash($senha, PASSWORD_DEFAULT);
                $update = $conn->prepare("UPDATE usuarios SET senha = ? WHERE id = ?");
                $update->bind_param("si", $newHash, $user['id']);
                $update->execute();
                $update->close();
                $authenticated = true;
            }

            if (!$authenticated) {
                echo json_encode([
                    'sucesso' => false,
                    'mensagem' => 'Email ou senha incorretos'
                ]);
                return true;
            }

            unset($user['senha']);
            $_SESSION['usuario_id'] = $user['id'];
            $_SESSION['usuario_nome'] = $user['nome'];

            echo json_encode([
                'sucesso' => true,
                'mensagem' => 'Login efetuado com sucesso!',
                'dados' => $user
            ]);
            $stmt->close();
            return true;

        case 'registar':
            $nome = trim($_POST['nome'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $senha = $_POST['senha'] ?? '';

            if (!$nome || !$email || !$senha) {
                echo json_encode([
                    'sucesso' => false,
                    'mensagem' => 'Preenche todos os campos'
                ]);
                return true;
            }

            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                echo json_encode([
                    'sucesso' => false,
                    'mensagem' => 'Email inválido'
                ]);
                return true;
            }

            if (strlen($senha) < 6) {
                echo json_encode([
                    'sucesso' => false,
                    'mensagem' => 'A senha deve ter pelo menos 6 caracteres'
                ]);
                return true;
            }

            $check = $conn->prepare("SELECT id FROM usuarios WHERE email = ?");
            $check->bind_param("s", $email);
            $check->execute();

            if ($check->get_result()->num_rows > 0) {
                echo json_encode([
                    'sucesso' => false,
                    'mensagem' => 'Este email já está registado'
                ]);
                return true;
            }

            $senha_hash = password_hash($senha, PASSWORD_DEFAULT);
            $sql = "INSERT INTO usuarios
                    (nome, email, senha, pontos, tipo, bio, streak, ultimo_login)
                    VALUES (?, ?, ?, 0, 'user', '', 1, CURDATE())";

            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sss", $nome, $email, $senha_hash);

            if ($stmt->execute()) {
                $_SESSION['usuario_id'] = $stmt->insert_id;
                $_SESSION['usuario_nome'] = $nome;
                echo json_encode([
                    'sucesso' => true,
                    'mensagem' => 'Conta criada com sucesso!',
                    'usuario_id' => $stmt->insert_id
                ]);
            } else {
                echo json_encode([
                    'sucesso' => false,
                    'mensagem' => 'Erro ao criar conta: ' . $conn->error
                ]);
            }
            $stmt->close();
            return true;

        case 'logout':
            session_unset();

            if (ini_get('session.use_cookies')) {
                $params = session_get_cookie_params();
                $path = $params['path'] ?: '/';
                setcookie(session_name(), '', time() - 42000,
                    $path, $params['domain'] ?? '',
                    $params['secure'] ?? false, $params['httponly'] ?? false
                );
            }

            session_destroy();
            echo json_encode([
                'sucesso' => true,
                'mensagem' => 'Sessão terminada'
            ]);
            return true;

        case 'salvar_quiz':
            if (!usuarioLogado()) {
                naoAutorizado();
            }

            $usuario_id = $_SESSION['usuario_id'];
            $linguagem = trim($_POST['linguagem'] ?? '');
            $dificuldade = trim($_POST['dificuldade'] ?? '');
            $pontuacao = intval($_POST['pontuacao'] ?? 0);
            $total_perguntas = intval($_POST['total_perguntas'] ?? 0);

            $sql = "INSERT INTO quiz_resultados
                    (usuario_id, linguagem, dificuldade, pontuacao, total_perguntas)
                    VALUES (?, ?, ?, ?, ?)";

            $stmt = $conn->prepare($sql);
            $stmt->bind_param(
                "issii",
                $usuario_id,
                $linguagem,
                $dificuldade,
                $pontuacao,
                $total_perguntas
            );

            if ($stmt->execute()) {
                $update = $conn->prepare(
                    "UPDATE usuarios
                     SET pontos = pontos + ?
                     WHERE id = ?"
                );
                $update->bind_param("ii", $pontuacao, $usuario_id);
                $update->execute();
                $update->close();

                echo json_encode([
                    'sucesso' => true,
                    'mensagem' => 'Quiz salvo!'
                ]);
            } else {
                echo json_encode([
                    'sucesso' => false,
                    'mensagem' => 'Erro: ' . $conn->error
                ]);
            }
            $stmt->close();
            return true;

        case 'atualizar_perfil':
            if (!usuarioLogado()) {
                naoAutorizado();
            }

            $usuario_id = $_SESSION['usuario_id'];
            $nome = trim($_POST['nome'] ?? '');
            $bio = trim($_POST['bio'] ?? '');

            $sql = "UPDATE usuarios
                    SET nome = ?, bio = ?
                    WHERE id = ?";

            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssi", $nome, $bio, $usuario_id);

            if ($stmt->execute()) {
                $_SESSION['usuario_nome'] = $nome;
                echo json_encode([
                    'sucesso' => true,
                    'mensagem' => 'Perfil atualizado!'
                ]);
            } else {
                echo json_encode([
                    'sucesso' => false,
                    'mensagem' => 'Erro: ' . $conn->error
                ]);
            }
            $stmt->close();
            return true;

        default:
            return false;
    }
}
