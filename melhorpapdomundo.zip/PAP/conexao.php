<?php
// conexao.php

$host = 'localhost';
$user = 'root';
$password = '';
$database = 'codemaster_db';

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode([
        'sucesso' => false,
        'mensagem' => 'Erro de conexão: ' . $conn->connect_error
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$conn->set_charset("utf8mb4");

// Sessão
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Verificar login
function usuarioLogado() {
    return isset($_SESSION['usuario_id']);
}

// Bloqueio
function naoAutorizado() {
    http_response_code(401);
    echo json_encode([
        'sucesso' => false,
        'mensagem' => 'Não autorizado'
    ]);
    exit;
}

// Utilizador atual
function getUsuarioAtual($conn) {
    if (!usuarioLogado()) return null;

    $id = $_SESSION['usuario_id'];

    $sql = "SELECT id, nome, email, pontos, tipo, bio, streak, ultimo_login 
            FROM usuarios WHERE id = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();

    $result = $stmt->get_result();
    return $result->fetch_assoc();
}
?>