<?php
// conexao.php
$host = 'localhost';
$user = 'root'; // Altere para seu usuário do MySQL
$password = ''; // Altere para sua senha do MySQL
$database = 'codemaster_db';

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die(json_encode([
        'sucesso' => false,
        'mensagem' => 'Erro de conexão: ' . $conn->connect_error
    ]));
}

// Garantir que a codificação está correta
$conn->set_charset("utf8mb4");

// Iniciar sessão para controle de login
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Função para verificar se o usuário está logado
function usuarioLogado() {
    return isset($_SESSION['usuario_id']) && !empty($_SESSION['usuario_id']);
}

// Função para retornar erro de não autorizado
function naoAutorizado() {
    http_response_code(401);
    echo json_encode([
        'sucesso' => false,
        'mensagem' => 'Não autorizado. Faça login primeiro.'
    ]);
    exit;
}

// Função para obter dados do usuário atual
function getUsuarioAtual($conn) {
    if (!usuarioLogado()) {
        return null;
    }
    
    $id = $_SESSION['usuario_id'];
    $sql = "SELECT id, nome, email, pontos, tipo, bio, streak, ultimo_login FROM usuarios WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        return $result->fetch_assoc();
    }
    
    return null;
}
?>