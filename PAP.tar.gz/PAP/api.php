<?php
// api.php - Versão com verificação de login
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=utf-8");

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once 'conexao.php';

// Ativar relatório de erros para debug
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Log para debug
$log_file = 'debug.log';
function debug_log($message) {
    global $log_file;
    file_put_contents($log_file, date('[Y-m-d H:i:s] ') . $message . PHP_EOL, FILE_APPEND);
}

debug_log("API chamada - Método: " . $_SERVER['REQUEST_METHOD'] . ", Ação: " . ($_GET['acao'] ?? 'nenhuma'));

$acao = $_GET['acao'] ?? '';

// Ações que não requerem login
$acoes_publicas = ['login', 'registar'];

// Verificar se a ação requer login
if (!in_array($acao, $acoes_publicas) && !usuarioLogado()) {
    debug_log("Tentativa de acesso não autorizado à ação: $acao");
    naoAutorizado();
}

switch($acao) {
    
    case 'login':
        debug_log("Processando login");
        
        // Pegar dados do POST
        $email = $_POST['email'] ?? '';
        $senha = $_POST['senha'] ?? '';
        
        debug_log("Email recebido: $email");
        
        if (empty($email) || empty($senha)) {
            echo json_encode([
                'sucesso' => false, 
                'mensagem' => 'Email e senha são obrigatórios'
            ]);
            exit;
        }
        
        // Gerar hash MD5 da senha fornecida
        $senha_hash = md5($senha);
        
        // Buscar usuário na base de dados
        $sql = "SELECT id, nome, email, pontos, tipo, bio, streak, ultimo_login, senha FROM usuarios WHERE email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $resultado = $stmt->get_result();
        
        if ($resultado->num_rows > 0) {
            $usuario = $resultado->fetch_assoc();
            
            // Verificar a senha
            if ($senha_hash === $usuario['senha']) {
                // Guardar na sessão
                $_SESSION['usuario_id'] = $usuario['id'];
                $_SESSION['usuario_nome'] = $usuario['nome'];
                $_SESSION['usuario_email'] = $usuario['email'];
                
                // Remover senha do array antes de enviar
                unset($usuario['senha']);
                
                // Atualizar streak
                $hoje = date('Y-m-d');
                $ultimo_login = $usuario['ultimo_login'];
                
                if ($ultimo_login == $hoje) {
                    $novo_streak = $usuario['streak'];
                } elseif ($ultimo_login == date('Y-m-d', strtotime('-1 day'))) {
                    $novo_streak = ($usuario['streak'] ?? 0) + 1;
                } else {
                    $novo_streak = 1;
                }
                
                // Atualizar último login e streak
                $update_sql = "UPDATE usuarios SET ultimo_login = ?, streak = ? WHERE id = ?";
                $update_stmt = $conn->prepare($update_sql);
                $update_stmt->bind_param("sii", $hoje, $novo_streak, $usuario['id']);
                $update_stmt->execute();
                $update_stmt->close();
                
                $usuario['streak'] = $novo_streak;
                
                echo json_encode([
                    'sucesso' => true,
                    'mensagem' => 'Login bem-sucedido',
                    'dados' => $usuario
                ]);
            } else {
                echo json_encode([
                    'sucesso' => false,
                    'mensagem' => 'Senha incorreta'
                ]);
            }
        } else {
            echo json_encode([
                'sucesso' => false,
                'mensagem' => 'Email não encontrado'
            ]);
        }
        
        $stmt->close();
        break;
    
    case 'registar':
        debug_log("Processando registo");
        
        $nome = $_POST['nome'] ?? '';
        $email = $_POST['email'] ?? '';
        $senha = $_POST['senha'] ?? '';
        
        debug_log("Nome: $nome, Email: $email");
        
        if (empty($nome) || empty($email) || empty($senha)) {
            echo json_encode([
                'sucesso' => false, 
                'mensagem' => 'Todos os campos são obrigatórios'
            ]);
            exit;
        }
        
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo json_encode([
                'sucesso' => false, 
                'mensagem' => 'Email inválido'
            ]);
            exit;
        }
        
        // Verificar se email já existe
        $check_sql = "SELECT id FROM usuarios WHERE email = ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("s", $email);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();
        
        if ($check_result->num_rows > 0) {
            echo json_encode([
                'sucesso' => false, 
                'mensagem' => 'Este email já está registado'
            ]);
            $check_stmt->close();
            exit;
        }
        $check_stmt->close();
        
        // Gerar hash MD5 da senha
        $senha_hash = md5($senha);
        
        $sql = "INSERT INTO usuarios (nome, email, senha, pontos, data_criacao, ultimo_login, tipo, streak) VALUES (?, ?, ?, 0, NOW(), ?, 'user', 1)";
        $stmt = $conn->prepare($sql);
        $hoje = date('Y-m-d');
        $stmt->bind_param("ssss", $nome, $email, $senha_hash, $hoje);
        
        if ($stmt->execute()) {
            $novo_id = $stmt->insert_id;
            
            // Fazer login automático após registro
            $_SESSION['usuario_id'] = $novo_id;
            $_SESSION['usuario_nome'] = $nome;
            $_SESSION['usuario_email'] = $email;
            
            echo json_encode([
                'sucesso' => true,
                'mensagem' => 'Utilizador registado com sucesso',
                'dados' => [
                    'id' => $novo_id,
                    'nome' => $nome,
                    'email' => $email,
                    'pontos' => 0,
                    'streak' => 1
                ]
            ]);
        } else {
            echo json_encode([
                'sucesso' => false,
                'mensagem' => 'Erro ao registar: ' . $conn->error
            ]);
        }
        
        $stmt->close();
        break;
    
    case 'logout':
        // Destruir a sessão
        $_SESSION = array();
        session_destroy();
        
        echo json_encode([
            'sucesso' => true,
            'mensagem' => 'Logout realizado com sucesso'
        ]);
        break;
    
    case 'verificar_sessao':
        // Verificar se o usuário está logado
        if (usuarioLogado()) {
            $usuario = getUsuarioAtual($conn);
            echo json_encode([
                'sucesso' => true,
                'logado' => true,
                'dados' => $usuario
            ]);
        } else {
            echo json_encode([
                'sucesso' => true,
                'logado' => false
            ]);
        }
        break;
    
    case 'leaderboard':
        $sql = "SELECT id, nome, pontos FROM usuarios ORDER BY pontos DESC LIMIT 10";
        $resultado = $conn->query($sql);
        
        $leaderboard = [];
        $posicao = 1;
        while ($row = $resultado->fetch_assoc()) {
            $row['posicao'] = $posicao++;
            $leaderboard[] = $row;
        }
        
        echo json_encode([
            'sucesso' => true,
            'dados' => $leaderboard
        ]);
        break;
    
    case 'salvar_progresso':
        // Verificar se usuário está logado (já verificado no início)
        $usuario_id = $_SESSION['usuario_id'];
        $linguagem = $_POST['linguagem'] ?? '';
        $porcentagem = $_POST['porcentagem'] ?? 0;
        
        if (empty($linguagem)) {
            echo json_encode([
                'sucesso' => false,
                'mensagem' => 'Linguagem é obrigatória'
            ]);
            exit;
        }
        
        // Inserir ou atualizar progresso
        $sql = "INSERT INTO progresso (usuario_id, linguagem, porcentagem) 
                VALUES (?, ?, ?) 
                ON DUPLICATE KEY UPDATE porcentagem = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("isii", $usuario_id, $linguagem, $porcentagem, $porcentagem);
        
        if ($stmt->execute()) {
            echo json_encode([
                'sucesso' => true,
                'mensagem' => 'Progresso salvo com sucesso'
            ]);
        } else {
            echo json_encode([
                'sucesso' => false,
                'mensagem' => 'Erro ao salvar progresso: ' . $conn->error
            ]);
        }
        $stmt->close();
        break;
    
    case 'get_progresso':
        $usuario_id = $_SESSION['usuario_id'];
        
        $sql = "SELECT linguagem, porcentagem FROM progresso WHERE usuario_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $usuario_id);
        $stmt->execute();
        $resultado = $stmt->get_result();
        
        $progresso = [];
        while ($row = $resultado->fetch_assoc()) {
            $progresso[$row['linguagem']] = $row['porcentagem'];
        }
        
        echo json_encode([
            'sucesso' => true,
            'dados' => $progresso
        ]);
        $stmt->close();
        break;
    
    case 'salvar_quiz':
        $usuario_id = $_SESSION['usuario_id'];
        $linguagem = $_POST['linguagem'] ?? '';
        $dificuldade = $_POST['dificuldade'] ?? '';
        $pontuacao = $_POST['pontuacao'] ?? 0;
        $total_perguntas = $_POST['total_perguntas'] ?? 0;
        
        // Inserir resultado do quiz
        $sql = "INSERT INTO quiz_resultados (usuario_id, linguagem, dificuldade, pontuacao, total_perguntas) 
                VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("issii", $usuario_id, $linguagem, $dificuldade, $pontuacao, $total_perguntas);
        $stmt->execute();
        $stmt->close();
        
        // Atualizar pontos do usuário
        $update_sql = "UPDATE usuarios SET pontos = pontos + ? WHERE id = ?";
        $update_stmt = $conn->prepare($update_sql);
        $update_stmt->bind_param("ii", $pontuacao, $usuario_id);
        $update_stmt->execute();
        $update_stmt->close();
        
        echo json_encode([
            'sucesso' => true,
            'mensagem' => 'Quiz salvo com sucesso'
        ]);
        break;
    
    case 'get_historico':
        $usuario_id = $_SESSION['usuario_id'];
        
        $sql = "SELECT * FROM quiz_resultados 
                WHERE usuario_id = ? 
                ORDER BY data DESC 
                LIMIT 20";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $usuario_id);
        $stmt->execute();
        $resultado = $stmt->get_result();
        
        $historico = [];
        while ($row = $resultado->fetch_assoc()) {
            $historico[] = $row;
        }
        
        echo json_encode([
            'sucesso' => true,
            'dados' => $historico
        ]);
        $stmt->close();
        break;
    
    case 'get_perfil':
        $usuario = getUsuarioAtual($conn);
        
        if ($usuario) {
            echo json_encode([
                'sucesso' => true,
                'dados' => $usuario
            ]);
        } else {
            echo json_encode([
                'sucesso' => false,
                'mensagem' => 'Usuário não encontrado'
            ]);
        }
        break;
    
    case 'atualizar_perfil':
        $usuario_id = $_SESSION['usuario_id'];
        $nome = $_POST['nome'] ?? '';
        $bio = $_POST['bio'] ?? '';
        
        $sql = "UPDATE usuarios SET nome = ?, bio = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssi", $nome, $bio, $usuario_id);
        
        if ($stmt->execute()) {
            $_SESSION['usuario_nome'] = $nome;
            
            echo json_encode([
                'sucesso' => true,
                'mensagem' => 'Perfil atualizado com sucesso'
            ]);
        } else {
            echo json_encode([
                'sucesso' => false,
                'mensagem' => 'Erro ao atualizar perfil: ' . $conn->error
            ]);
        }
        $stmt->close();
        break;
    
    default:
        echo json_encode([
            'sucesso' => false,
            'mensagem' => 'Ação não encontrada: ' . $acao
        ]);
        break;
}

$conn->close();
?>